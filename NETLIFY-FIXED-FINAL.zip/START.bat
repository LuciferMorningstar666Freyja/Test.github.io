@echo off
echo ========================================
echo   Love Website - Starting Server
echo ========================================
echo.
echo Installing dependencies...
call npm install
echo.
echo Starting development server...
echo.
echo The website will open at: http://localhost:5173
echo Press Ctrl+C to stop the server
echo.
call npm run dev
