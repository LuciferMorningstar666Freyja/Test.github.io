import React, { useState, useEffect, useCallback, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Heart, Music, Quote, Sparkles, Moon, Sun, Coffee,
  Flame, ArrowLeft, X, Menu,
  Infinity as InfinityIcon,
  Smile, Eye, Shield, Headphones,
  ChevronUp
} from "lucide-react";

// =============================================
// SECTION DATA
// =============================================
interface TileData {
  id: string;
  emoji: string;
  title: string;
  subtitle: string;
  gradient: string;
  bgGlow: string;
  iconBg: string;
  description: string;
}

const sectionTiles: TileData[] = [
  { id: "story", emoji: "📖", title: "Our Story", subtitle: "15 chapters that changed everything", gradient: "from-purple-500 to-indigo-600", bgGlow: "bg-purple-500", iconBg: "from-purple-500/20 to-indigo-500/20", description: "15 handwritten chapters of our journey — from the first meeting to forever. Every single word is real." },
  { id: "playlist", emoji: "🎵", title: "Songs I Cried To", subtitle: "30 melodies soaked in tears & longing", gradient: "from-violet-500 to-purple-600", bgGlow: "bg-violet-500", iconBg: "from-violet-500/20 to-purple-500/20", description: "30 songs I listened to when missing you hurt so much. Every lyric felt written about us." },
  { id: "roseday", emoji: "🌹", title: "Rose Day", subtitle: "Every color rose has a meaning for you", gradient: "from-rose-500 to-red-600", bgGlow: "bg-rose-500", iconBg: "from-rose-500/20 to-red-500/20", description: "12 colored roses, each carrying a special meaning. Purple for you, my favorite color for my favorite person." },
  { id: "proposeday", emoji: "💍", title: "Propose Day", subtitle: "A thousand ways to ask you forever", gradient: "from-yellow-500 to-amber-600", bgGlow: "bg-yellow-500", iconBg: "from-yellow-500/20 to-amber-500/20", description: "15 creative, romantic ways I'd propose to you. Each one from the deepest part of my heart." },
  { id: "chocolateday", emoji: "🍫", title: "Chocolate Day", subtitle: "Sweet moments, sweeter love", gradient: "from-amber-700 to-orange-800", bgGlow: "bg-amber-700", iconBg: "from-amber-700/20 to-orange-700/20", description: "Create your perfect chocolate box! Choose your favorites and I'll know exactly what makes you smile." },
  { id: "teddyday", emoji: "🧸", title: "Teddy Day", subtitle: "Cuddles in every form", gradient: "from-orange-400 to-pink-500", bgGlow: "bg-orange-400", iconBg: "from-orange-400/20 to-pink-400/20", description: "10 different teddies, each one ready to give you the warmest hug when I can't be there." },
  { id: "promiseday", emoji: "🤞", title: "Promise Day", subtitle: "Every promise I'll ever keep", gradient: "from-emerald-500 to-teal-600", bgGlow: "bg-emerald-500", iconBg: "from-emerald-500/20 to-teal-500/20", description: "50+ promises carved into my soul. These aren't just words — they're my commitment to you, forever and always." },
  { id: "hugday", emoji: "🤗", title: "Hug Day", subtitle: "Feel my arms around you", gradient: "from-cyan-500 to-blue-600", bgGlow: "bg-cyan-500", iconBg: "from-cyan-500/20 to-blue-500/20", description: "Choose the hug you need right now. I'm wrapping my arms around you, even from far away." },
  { id: "kissday", emoji: "💋", title: "Kiss Day", subtitle: "Every kiss tells our story", gradient: "from-red-500 to-pink-600", bgGlow: "bg-red-500", iconBg: "from-red-500/20 to-pink-500/20", description: "20 different types of kisses, from sweet to passionate. Each one waiting for the perfect moment with you." },
  { id: "dreamboy", emoji: "👨", title: "Design Your Dream Boy", subtitle: "269 questions to create your perfect match", gradient: "from-blue-500 to-cyan-600", bgGlow: "bg-blue-500", iconBg: "from-blue-500/20 to-cyan-500/20", description: "I want to know everything about the person you'd love. Every trait, every detail, every preference, every situation. Help me understand what makes your heart skip a beat." },
  { id: "knowyou", emoji: "💝", title: "Let Me Know You", subtitle: "281 questions to understand everything", gradient: "from-rose-500 to-pink-600", bgGlow: "bg-rose-500", iconBg: "from-rose-500/20 to-pink-500/20", description: "Tell me everything about you — your likes, dreams, preferences, situations, everything. I want to know you deeper than anyone ever has." },
  { id: "compliments", emoji: "👑", title: "You Are Beyond Legendary", subtitle: "232 comparisons across the omniverse", gradient: "from-fuchsia-500 to-pink-600", bgGlow: "bg-fuchsia-500", iconBg: "from-fuchsia-500/20 to-pink-500/20", description: "232 comparisons across 13 categories — goddesses, cosmic forces, natural wonders, mythical creatures, saints, modern icons, and more. You're beyond them all." },
  { id: "lovefacts", emoji: "🧠", title: "Love Facts", subtitle: "Science proves we're meant to be", gradient: "from-cyan-500 to-blue-600", bgGlow: "bg-cyan-500", iconBg: "from-cyan-500/20 to-blue-500/20", description: "20 fascinating scientific facts about love. Turns out, science agrees — we're meant to be together." },
  { id: "quotes", emoji: "💬", title: "Love Quotes", subtitle: "45 timeless words about love", gradient: "from-teal-500 to-emerald-600", bgGlow: "bg-teal-500", iconBg: "from-teal-500/20 to-emerald-500/20", description: "45 beautiful love quotes from poets, writers, and dreamers across time — each one captures a piece of what I feel for you. From ancient poetry to modern romance." },
  { id: "forever", emoji: "♾️", title: "Forever & Always", subtitle: "My eternal promise to you", gradient: "from-glow-pink to-glow-purple", bgGlow: "bg-glow-pink", iconBg: "from-glow-pink/20 to-glow-purple/20", description: "My final message to you. The one that says it all. Open it and see. 💖" },
  { id: "reels", emoji: "🎬", title: "Our Reels Together", subtitle: "47 moments captured, reactions shared", gradient: "from-purple-600 to-pink-500", bgGlow: "bg-purple-600", iconBg: "from-purple-600/20 to-pink-500/20", description: "47 reels that made me think of you, laugh, cry, or smile. Watch my reaction, then tell me yours. I want to know what you feel." },
  { id: "chats", emoji: "💬", title: "Our Chat Memories", subtitle: "31 screenshots of our conversations", gradient: "from-blue-500 to-purple-600", bgGlow: "bg-blue-500", iconBg: "from-blue-500/20 to-purple-500/20", description: "Our conversations frozen in time. 31 screenshots showing our messages, emotions, late-night talks — every screenshot holds a piece of our story together." },
  { id: "finalmessage", emoji: "💝", title: "My Message To You", subtitle: "Before you leave this universe...", gradient: "from-rose-600 to-purple-600", bgGlow: "bg-rose-600", iconBg: "from-rose-600/20 to-purple-600/20", description: "The complete story of how I built this. 180-200 hours. 30,000 lines of code. 78 manual reactions. Everything explained. Your thoughts welcomed. No pressure." },
];

// =============================================
// TYPEWRITER HOOK
// =============================================
// ============================================
// SLACK WEBHOOK INTEGRATION  
// ============================================
const SLACK_WEBHOOK_URL = "YOUR_SLACK_WEBHOOK_URL_HERE"; // ⚠️ REPLACE THIS!

const sendToSlack = async (message: string): Promise<boolean> => {
  try {
    const response = await fetch(SLACK_WEBHOOK_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        text: message,
        unfurl_links: false,
        unfurl_media: false
      })
    });
    
    if (response.ok) {
      return true;
    } else {
      console.error('Slack webhook failed:', response.statusText);
      return false;
    }
  } catch (error) {
    console.error('Error sending to Slack:', error);
    return false;
  }
};

function useTypewriter(texts: string[], speed = 80, pause = 2000) {
  const [displayText, setDisplayText] = useState("");
  const [textIndex, setTextIndex] = useState(0);
  const [charIndex, setCharIndex] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    const currentText = texts[textIndex];
    const timeout = setTimeout(() => {
      if (!isDeleting) {
        setDisplayText(currentText.slice(0, charIndex + 1));
        setCharIndex((c) => c + 1);
        if (charIndex + 1 === currentText.length) {
          setTimeout(() => setIsDeleting(true), pause);
        }
      } else {
        setDisplayText(currentText.slice(0, charIndex - 1));
        setCharIndex((c) => c - 1);
        if (charIndex <= 1) {
          setIsDeleting(false);
          setTextIndex((t) => (t + 1) % texts.length);
        }
      }
    }, isDeleting ? speed / 2 : speed);
    return () => clearTimeout(timeout);
  }, [charIndex, isDeleting, textIndex, texts, speed, pause]);

  return displayText;
}

// =============================================
// FLOATING NAVIGATION BUTTON
// =============================================
function FloatingNav({ onOpenSection, currentSection, onBack }: {
  onOpenSection: (id: string) => void;
  currentSection: string | null;
  onBack: () => void;
}) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <motion.button
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 1.5, type: "spring" }}
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 z-[60] w-14 h-14 rounded-full bg-gradient-to-br from-glow-pink to-glow-purple flex items-center justify-center shadow-[0_0_30px_rgba(255,45,138,0.4)] hover:shadow-[0_0_50px_rgba(255,45,138,0.6)] hover:scale-110 active:scale-95 transition-all duration-300"
      >
        <Menu className="w-5 h-5 text-white" />
      </motion.button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-[70] bg-dark-950/95 backdrop-blur-2xl"
          >
            <button
              onClick={() => setIsOpen(false)}
              className="absolute top-6 right-6 w-12 h-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white/60 hover:text-white hover:bg-white/10 transition-all z-10"
            >
              <X className="w-5 h-5" />
            </button>

            {currentSection && (
              <button
                onClick={() => { onBack(); setIsOpen(false); }}
                className="absolute top-6 left-6 px-5 py-3 rounded-xl bg-white/5 border border-white/10 flex items-center gap-2 text-white/60 hover:text-white hover:bg-white/10 transition-all z-10 text-sm"
              >
                <ArrowLeft className="w-4 h-4" />
                Home
              </button>
            )}

            <div className="h-full overflow-y-auto py-20 px-6">
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="text-center mb-8">
                <Heart className="w-8 h-8 text-glow-pink fill-glow-pink mx-auto mb-3 animate-heartbeat" />
                <h2 className="text-2xl font-bold bg-gradient-to-r from-glow-pink to-glow-purple bg-clip-text text-transparent">
                  Explore Our World
                </h2>
              </motion.div>

              <div className="max-w-lg mx-auto grid grid-cols-2 gap-3">
                {sectionTiles.map((tile, i) => (
                  <motion.button
                    key={tile.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 + i * 0.05 }}
                    onClick={() => { onOpenSection(tile.id); setIsOpen(false); }}
                    className={`relative p-5 rounded-2xl border text-left transition-all duration-300 group overflow-hidden ${
                      currentSection === tile.id
                        ? "border-glow-pink/30 bg-glow-pink/10"
                        : "border-white/[0.06] bg-white/[0.03] hover:border-white/15 hover:bg-white/[0.06]"
                    }`}
                  >
                    <div className={`absolute inset-0 bg-gradient-to-br ${tile.gradient} opacity-0 group-hover:opacity-[0.08] transition-opacity duration-500`} />
                    <span className="text-3xl block mb-2 relative z-10">{tile.emoji}</span>
                    <h3 className="text-sm font-semibold text-white/90 relative z-10">{tile.title}</h3>
                    <p className="text-[10px] text-white/30 mt-0.5 relative z-10">{tile.subtitle}</p>
                  </motion.button>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

// =============================================
// STARFIELD COMPONENT
// =============================================
function Starfield() {
  const stars = useMemo(() =>
    Array.from({ length: 80 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 2.5 + 0.5,
      delay: Math.random() * 6,
      dur: 2 + Math.random() * 4,
    })), []
  );

  return (
    <div className="absolute inset-0 pointer-events-none z-0">
      {stars.map((s) => (
        <div
          key={s.id}
          className="absolute rounded-full bg-white animate-twinkle"
          style={{
            left: `${s.x}%`,
            top: `${s.y}%`,
            width: `${s.size}px`,
            height: `${s.size}px`,
            animationDelay: `${s.delay}s`,
            animationDuration: `${s.dur}s`,
          }}
        />
      ))}
    </div>
  );
}

// =============================================
// TILE HOMEPAGE — IMMERSIVE REDESIGN
// =============================================
function TileHomepage({ onOpenSection }: { onOpenSection: (id: string) => void }) {
  const typewriterText = useTypewriter([
    "You are my everything 💕",
    "Tumse hi toh zindagi hai ✨",
    "I love you more every day 💖",
    "Tum mere liye special ho 🌹",
    "You make my world beautiful 🌍",
    "Bas tum ho meri duniya 💗",
  ], 70, 2500);

  return (
    <div className="min-h-screen bg-[#030306] relative overflow-hidden">
      {/* ===== STARFIELD ===== */}
      <Starfield />

      {/* ===== AURORA / NORTHERN LIGHTS ===== */}
      <div className="absolute top-0 left-0 right-0 h-[70vh] pointer-events-none overflow-hidden z-[1]">
        <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[300px] bg-gradient-to-r from-pink-500/[0.07] via-rose-500/[0.05] to-transparent rounded-full blur-[100px] animate-[aurora_15s_ease-in-out_infinite]" />
        <div className="absolute top-[-10%] left-[20%] w-[50%] h-[250px] bg-gradient-to-r from-purple-500/[0.06] via-violet-500/[0.04] to-transparent rounded-full blur-[120px] animate-[aurora_18s_ease-in-out_infinite_2s]" />
        <div className="absolute top-[5%] right-[-5%] w-[45%] h-[200px] bg-gradient-to-l from-cyan-500/[0.05] via-blue-500/[0.03] to-transparent rounded-full blur-[100px] animate-[aurora_20s_ease-in-out_infinite_4s]" />
      </div>

      {/* ===== SHOOTING STARS ===== */}
      <div className="absolute inset-0 pointer-events-none z-[1] overflow-hidden">
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            className="absolute w-[2px] h-[2px] bg-white rounded-full"
            style={{
              top: `${10 + i * 20}%`,
              left: `-5%`,
              boxShadow: '0 0 6px 2px rgba(255,255,255,0.6), -40px 0 20px rgba(255,255,255,0.3)',
              animation: `shoot ${3 + i}s linear ${i * 4}s infinite`,
            }}
          />
        ))}
      </div>

      {/* ===== AMBIENT GLOW ORBS ===== */}
      <div className="absolute top-[-15%] left-[-15%] w-[700px] h-[700px] bg-pink-500/[0.06] rounded-full blur-[200px] animate-glow-pulse pointer-events-none z-[1]" />
      <div className="absolute bottom-[-10%] right-[-15%] w-[600px] h-[600px] bg-purple-500/[0.05] rounded-full blur-[180px] animate-glow-pulse pointer-events-none z-[1]" style={{ animationDelay: "2s" }} />
      <div className="absolute top-[40%] left-[50%] -translate-x-1/2 w-[500px] h-[500px] bg-blue-500/[0.04] rounded-full blur-[160px] animate-glow-pulse pointer-events-none z-[1]" style={{ animationDelay: "4s" }} />
      <div className="absolute top-[20%] right-[10%] w-[400px] h-[400px] bg-cyan-500/[0.03] rounded-full blur-[140px] animate-glow-pulse pointer-events-none z-[1]" style={{ animationDelay: "6s" }} />
      <div className="absolute bottom-[30%] left-[5%] w-[450px] h-[450px] bg-fuchsia-500/[0.04] rounded-full blur-[150px] animate-glow-pulse pointer-events-none z-[1]" style={{ animationDelay: "3s" }} />

      {/* ===== RADIAL VIGNETTE ===== */}
      <div className="absolute inset-0 pointer-events-none z-[2]" style={{ background: 'radial-gradient(ellipse at center, transparent 40%, rgba(3,3,6,0.8) 100%)' }} />

      {/* ===== HERO SECTION ===== */}
      <div className="relative z-10 min-h-[90vh] flex items-center justify-center px-5 md:px-10">
        {/* Grid pattern */}
        <div className="absolute inset-0 opacity-[0.015] pointer-events-none" style={{ backgroundImage: 'linear-gradient(rgba(255,255,255,1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,1) 1px, transparent 1px)', backgroundSize: '80px 80px' }} />

        <div className="max-w-5xl mx-auto text-center">
          {/* Animated Heart with Layered Glow Rings */}
          <motion.div
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ type: "spring", stiffness: 80, delay: 0.2, duration: 1.2 }}
            className="mb-10 inline-block relative"
          >
            <div className="absolute inset-[-30px] rounded-full border border-pink-500/10 animate-glow-ring" />
            <div className="absolute inset-[-60px] rounded-full border border-pink-500/[0.06] animate-glow-ring" style={{ animationDelay: "1s" }} />
            <div className="absolute inset-[-90px] rounded-full border border-pink-500/[0.03] animate-glow-ring" style={{ animationDelay: "2s" }} />
            <div className="absolute inset-0 rounded-full bg-pink-500/15 animate-pulse-ring" />
            <div className="absolute inset-0 rounded-full bg-pink-500/10 animate-pulse-ring" style={{ animationDelay: "1s" }} />

            <div className="relative w-32 h-32 md:w-40 md:h-40 rounded-full bg-gradient-to-br from-pink-500/20 via-fuchsia-500/15 to-purple-500/20 flex items-center justify-center border border-pink-500/20 shadow-[0_0_80px_rgba(255,45,138,0.3)]">
              <Heart className="w-16 h-16 md:w-20 md:h-20 text-pink-500 fill-pink-500 animate-heartbeat drop-shadow-[0_0_60px_rgba(255,45,138,0.9)]" />
            </div>
          </motion.div>

          {/* Badge */}
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="mb-8">
            <span className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full bg-pink-500/[0.06] border border-pink-500/15 text-pink-400/60 text-[10px] md:text-xs font-medium tracking-[0.3em] uppercase">
              <Sparkles className="w-3 h-3" />
              Made with love, just for you
              <Sparkles className="w-3 h-3" />
            </span>
          </motion.div>

          {/* Main Title */}
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 1 }}
            className="text-7xl sm:text-8xl md:text-9xl lg:text-[10rem] font-extrabold mb-8 leading-[0.9] tracking-tight"
            style={{ fontFamily: "'Poppins', sans-serif" }}
          >
            <span className="bg-gradient-to-r from-pink-400 via-rose-400 to-purple-400 bg-clip-text text-transparent block" style={{ textShadow: '0 0 80px rgba(255,45,138,0.4)' }}>
              For You,
            </span>
            <span className="bg-gradient-to-r from-purple-400 via-fuchsia-400 to-pink-400 bg-clip-text text-transparent block mt-2" style={{ textShadow: '0 0 80px rgba(180,77,255,0.3)' }}>
              My Love
            </span>
          </motion.h1>

          {/* Typewriter */}
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1 }} className="h-12 mb-6 flex items-center justify-center">
            <p className="text-white/35 text-xl md:text-2xl font-light" style={{ fontFamily: "'Playfair Display', serif" }}>
              {typewriterText}
              <span className="animate-typewriter-blink text-pink-400 ml-0.5">|</span>
            </p>
          </motion.div>

          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.2 }} className="text-white/12 text-sm mb-4">
            I built this little world just for you 🌍
          </motion.p>

          {/* Scroll indicator — mouse scroll design */}
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.5 }} className="mt-16">
            <motion.div
              animate={{ y: [0, 10, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="flex flex-col items-center gap-3 cursor-pointer group"
              onClick={() => document.getElementById("tiles-section")?.scrollIntoView({ behavior: "smooth" })}
            >
              <span className="text-white/12 text-[10px] tracking-[0.5em] uppercase group-hover:text-white/25 transition-colors">Scroll to explore</span>
              <div className="w-7 h-11 rounded-full border-2 border-white/10 flex items-start justify-center p-2 group-hover:border-pink-500/30 transition-colors">
                <motion.div animate={{ y: [0, 14, 0] }} transition={{ duration: 1.5, repeat: Infinity }} className="w-1.5 h-1.5 rounded-full bg-pink-500/60" />
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>

      {/* ===== GRADIENT DIVIDER ===== */}
      <div id="tiles-section" className="relative z-10 py-10">
        <div className="max-w-5xl mx-auto px-5">
          <div className="h-[1px] bg-gradient-to-r from-transparent via-pink-500/20 to-transparent" />
        </div>
      </div>

      {/* ===== TILES — MASSIVE FULL WIDTH ===== */}
      <div className="relative z-10 px-4 md:px-8 lg:px-12 pb-32">
        <div className="max-w-5xl mx-auto flex flex-col gap-6 md:gap-8">
          {sectionTiles.map((tile, i) => (
            <motion.button
              key={tile.id}
              initial={{ opacity: 0, x: i % 2 === 0 ? -100 : 100 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ type: "spring", stiffness: 60, damping: 16, delay: 0.05 * i }}
              onClick={() => onOpenSection(tile.id)}
              className="group relative w-full text-left overflow-hidden rounded-[28px] md:rounded-[32px] border border-white/[0.06] bg-gradient-to-br from-white/[0.03] via-white/[0.015] to-white/[0.03] focus:outline-none focus:ring-2 focus:ring-pink-500/40 transition-all duration-500 hover:border-white/[0.12] hover:translate-y-[-6px] hover:shadow-[0_30px_80px_rgba(255,45,138,0.08),0_0_0_1px_rgba(255,255,255,0.06)]"
            >
              {/* Hover gradient fill */}
              <div className={`absolute inset-0 bg-gradient-to-r ${tile.gradient} opacity-0 group-hover:opacity-[0.06] transition-opacity duration-700`} />

              {/* Shimmer sweep */}
              <div className="absolute top-0 left-[-100%] w-[50%] h-full bg-gradient-to-r from-transparent via-white/[0.03] to-transparent group-hover:left-[150%] transition-all duration-[1200ms] ease-in-out" />

              {/* Corner glow */}
              <div className={`absolute -top-24 -right-24 w-48 h-48 bg-gradient-to-br ${tile.gradient} rounded-full blur-[80px] opacity-0 group-hover:opacity-[0.12] transition-opacity duration-700 pointer-events-none`} />

              {/* Giant watermark emoji */}
              <div className="absolute right-4 md:right-10 top-1/2 -translate-y-1/2 text-[120px] md:text-[160px] lg:text-[200px] opacity-[0.015] group-hover:opacity-[0.04] group-hover:scale-110 transition-all duration-700 pointer-events-none select-none leading-none">
                {tile.emoji}
              </div>

              {/* Content */}
              <div className="relative z-10 flex items-center gap-5 md:gap-8 lg:gap-10 p-6 md:p-10 lg:p-12 min-h-[160px] md:min-h-[200px] lg:min-h-[240px]">
                {/* Emoji container */}
                <div className="relative shrink-0">
                  <div className={`absolute inset-[-16px] rounded-[28px] bg-gradient-to-br ${tile.iconBg} opacity-0 group-hover:opacity-100 blur-3xl transition-opacity duration-500`} />
                  <div className={`relative w-24 h-24 md:w-32 md:h-32 lg:w-36 lg:h-36 rounded-[22px] md:rounded-[26px] bg-gradient-to-br ${tile.iconBg} border border-white/[0.08] group-hover:border-white/[0.2] flex items-center justify-center transition-all duration-500 group-hover:shadow-[0_0_40px_rgba(255,45,138,0.2)]`}>
                    <span className="text-5xl md:text-6xl lg:text-7xl group-hover:scale-110 group-hover:rotate-[8deg] transition-transform duration-500 ease-out block drop-shadow-[0_0_30px_rgba(255,45,138,0.3)]">
                      {tile.emoji}
                    </span>
                  </div>
                </div>

                {/* Text */}
                <div className="flex-1 min-w-0 py-2">
                  {/* Title */}
                  <h2 className="text-2xl md:text-3xl lg:text-4xl xl:text-5xl font-bold text-white/90 group-hover:text-white transition-colors duration-300 mb-2 md:mb-3" style={{ fontFamily: "'Poppins', sans-serif" }}>
                    {tile.title}
                  </h2>
                  
                  {/* Subtitle - NOW MORE PROMINENT */}
                  <p className={`text-base md:text-lg lg:text-xl font-medium bg-gradient-to-r ${tile.gradient} bg-clip-text text-transparent mb-3 md:mb-4 transition-all duration-300 group-hover:opacity-100`} style={{ fontFamily: "'Playfair Display', serif", opacity: 0.7 }}>
                    {tile.subtitle}
                  </p>
                  
                  {/* Description */}
                  <p className="text-white/20 group-hover:text-white/40 transition-colors duration-300 text-sm md:text-base leading-relaxed max-w-2xl">
                    {tile.description}
                  </p>
                </div>

                {/* Arrow */}
                <div className="shrink-0">
                  <div className="w-14 h-14 md:w-16 md:h-16 lg:w-20 lg:h-20 rounded-2xl md:rounded-[20px] bg-white/[0.03] group-hover:bg-gradient-to-br group-hover:from-pink-500/20 group-hover:to-purple-500/20 border border-white/[0.06] group-hover:border-white/[0.2] flex items-center justify-center transition-all duration-500 group-hover:translate-x-2 group-hover:shadow-[0_0_30px_rgba(255,45,138,0.2)]">
                    <span className="text-white/15 group-hover:text-white/90 text-2xl md:text-3xl transition-all duration-300">→</span>
                  </div>
                </div>
              </div>

              {/* Bottom accent */}
              <div className={`absolute bottom-0 left-0 right-0 h-[3px] bg-gradient-to-r ${tile.gradient} opacity-0 group-hover:opacity-70 transition-opacity duration-500`} />
            </motion.button>
          ))}
        </div>
      </div>

      {/* ===== FOOTER ===== */}
      <div className="relative z-10 text-center pb-20">
        <div className="flex items-center justify-center gap-4 mb-4">
          <div className="h-px w-24 bg-gradient-to-r from-transparent to-pink-500/20" />
          <Heart className="w-5 h-5 text-pink-500/30 fill-pink-500/30 animate-heartbeat" />
          <div className="h-px w-24 bg-gradient-to-l from-transparent to-pink-500/20" />
        </div>
        <p className="text-white/8 text-xs md:text-sm">Made with infinite love, for the most beautiful soul 💕</p>
      </div>
    </div>
  );
}

// =============================================
// SECTION VIEW WRAPPER
// =============================================
function SectionView({
  id,
  onBack,
  children,
  gradient,
  emoji,
  title,
}: {
  id: string;
  onBack: () => void;
  children: React.ReactNode;
  gradient: string;
  emoji: string;
  title: string;
}) {
  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, [id]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.4 }}
      className="min-h-screen bg-[#030306] relative"
    >
      <motion.div
        initial={{ y: -60 }}
        animate={{ y: 0 }}
        transition={{ delay: 0.1, type: "spring", stiffness: 200 }}
        className="sticky top-0 z-50 bg-[#030306]/80 backdrop-blur-2xl border-b border-white/[0.05]"
      >
        <div className="max-w-6xl mx-auto px-5 md:px-10 h-16 flex items-center gap-4">
          <motion.button
            whileHover={{ scale: 1.1, x: -3 }}
            whileTap={{ scale: 0.9 }}
            onClick={onBack}
            className="w-10 h-10 rounded-xl bg-white/[0.05] border border-white/[0.08] flex items-center justify-center text-white/50 hover:text-white hover:bg-white/[0.1] transition-all duration-300"
          >
            <ArrowLeft className="w-4 h-4" />
          </motion.button>
          <div className="flex items-center gap-3 flex-1 min-w-0">
            <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${gradient} flex items-center justify-center flex-shrink-0 shadow-lg`}>
              <span className="text-sm">{emoji}</span>
            </div>
            <h1 className="text-base font-bold text-white truncate">{title}</h1>
          </div>
          <Heart className="w-4 h-4 text-pink-500/40 fill-pink-500/40 animate-heartbeat" />
        </div>
        <div className="h-[2px] bg-gradient-to-r from-transparent via-pink-500/30 to-transparent" />
      </motion.div>
      <div className="relative overflow-hidden">{children}</div>
    </motion.div>
  );
}

// =============================================
// SHARED SECTION UI
// =============================================
function SectionInner({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`relative py-14 md:py-20 px-5 md:px-10 overflow-hidden ${className}`}>
      {children}
    </div>
  );
}

function GlowOrb({ color, className = "" }: { color: string; className?: string }) {
  const colors: Record<string, string> = {
    pink: "bg-pink-500/[0.07]",
    purple: "bg-purple-500/[0.07]",
    magenta: "bg-fuchsia-500/[0.06]",
    cyan: "bg-cyan-500/[0.05]",
  };
  return (
    <div className={`absolute w-[400px] h-[400px] rounded-full blur-[120px] animate-glow-pulse pointer-events-none ${colors[color] || colors.pink} ${className}`} />
  );
}

function SectionHeader({ emoji, title, subtitle }: { emoji: string; title: string; subtitle: string }) {
  return (
    <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2, duration: 0.7 }} className="text-center mb-14 md:mb-18">
      <span className="text-5xl md:text-6xl block mb-5">{emoji}</span>
      <h2 className="text-3xl md:text-5xl lg:text-6xl font-extrabold bg-gradient-to-r from-pink-400 via-rose-400 to-purple-400 bg-clip-text text-transparent leading-tight" style={{ fontFamily: "'Poppins', sans-serif" }}>
        {title}
      </h2>
      <p className="text-white/25 mt-4 text-sm md:text-base font-light max-w-lg mx-auto">{subtitle}</p>
      <div className="flex items-center justify-center gap-3 mt-6">
        <div className="h-px w-16 bg-gradient-to-r from-transparent to-pink-500/30" />
        <Heart className="w-3 h-3 text-pink-500/30 fill-pink-500/30 animate-heartbeat" />
        <div className="h-px w-16 bg-gradient-to-l from-transparent to-pink-500/30" />
      </div>
    </motion.div>
  );
}

// =============================================
// SECTION CONTENTS (10 sections)
// =============================================

function ReasonsContent() {
  const reasons = [
    { icon: <Smile className="w-5 h-5" />, title: "Your Smile", text: "The way you smile lights up even my darkest days. It's my absolute favorite thing.", color: "from-pink-500/20 to-rose-500/20" },
    { icon: <Moon className="w-5 h-5" />, title: "Your Laugh", text: "Your laugh is the most beautiful melody. I'd do absolutely anything to hear it.", color: "from-purple-500/20 to-indigo-500/20" },
    { icon: <Sun className="w-5 h-5" />, title: "Your Kindness", text: "The way you care about everyone shows what a gorgeous soul you truly have.", color: "from-amber-500/20 to-orange-500/20" },
    { icon: <Coffee className="w-5 h-5" />, title: "Your Quirks", text: "All those little things that make you uniquely you — I'm obsessed with every one.", color: "from-emerald-500/20 to-teal-500/20" },
    { icon: <Shield className="w-5 h-5" />, title: "Your Strength", text: "You're the strongest person I know. You inspire me to be better every day.", color: "from-blue-500/20 to-cyan-500/20" },
    { icon: <Flame className="w-5 h-5" />, title: "Your Passion", text: "When you talk about things you love, your eyes sparkle and I fall deeper.", color: "from-red-500/20 to-rose-500/20" },
    { icon: <Eye className="w-5 h-5" />, title: "Your Beauty", text: "Inside and out, you are the most beautiful human I have ever seen.", color: "from-violet-500/20 to-purple-500/20" },
    { icon: <Headphones className="w-5 h-5" />, title: "Your Voice", text: "Whether talking, singing, or whispering — it's my favorite sound on earth.", color: "from-sky-500/20 to-blue-500/20" },
    { icon: <Heart className="w-5 h-5" />, title: "Your Love", text: "The way you love makes me feel like the luckiest person alive. Endlessly.", color: "from-pink-500/20 to-purple-500/20" },
  ];

  return (
    <SectionInner>
      <GlowOrb color="pink" className="-top-20 -right-20" />
      <GlowOrb color="purple" className="bottom-0 -left-20" />
      <div className="max-w-6xl mx-auto relative z-10">
        <SectionHeader emoji="💕" title="Why I Love You" subtitle="Let me count the infinite ways..." />
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-5">
          {reasons.map((r, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 + i * 0.08, duration: 0.5 }} whileHover={{ y: -6, scale: 1.02 }} className="glass-card rounded-2xl p-6 hover:shadow-[0_0_30px_rgba(255,45,138,0.08)] cursor-default transition-all duration-300">
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${r.color} flex items-center justify-center text-white/80 mb-4`}>{r.icon}</div>
              <h3 className="text-lg font-semibold text-white mb-2">{r.title}</h3>
              <p className="text-white/35 text-sm leading-relaxed">{r.text}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </SectionInner>
  );
}

function StoryContent() {  const chapters = [
    { num: 1, title: 'The First Meeting', subtitle: 'Where it all quietly began', emoji: '🎲', shayari: 'Kuch mulaakaatein bas pal hoti hain us waqt,\npar baad mein wahi poori zindagi ka weight utha leti hain.', story: 'So our story begins here actually. I can say my story to aap se pehli baar mile the. Monopoly khelne ke liye, par tab main nervous aur shy tha. Main ladkiyon se zyada baat nahi karta tha, isliye aapse bhi zyada baat nahi karta tha. Tab main aapko itna jaanta bhi nahi tha, aur us waqt main itna achha bhi nahi tha.', color: 'from-pink-500 to-rose-400' },
    { num: 2, title: 'A Focused Phase', subtitle: 'Life before feelings', emoji: '📚', shayari: 'Hum aksar kaam mein khud ko chhupa lete hain,\ntaakki dil se kuch mehsoos na karna pade.', story: 'Us waqt main 10th mein aaya hi tha, tab mujhe TIM batch mila tha. To tab main padhai par zyada focus karne lag gaya tha. Mera batch bhi sham ka batch tha, isliye hum zyada kuch khela nahi karte the.', color: 'from-blue-500 to-cyan-400' },
    { num: 3, title: 'A Silent Crush', subtitle: 'Unsaid, unnoticed, but real', emoji: '🤫', shayari: 'Kuch pyaar shabd nahi dhoondta,\nwoh chup reh kar hi dil par apni jagah bana leta hai.', story: 'Phir jab main 11th mein aaya, tab mujhe aap par crush generate ho gaya tha (secret crush). Par us waqt main tab bhi bahut shy tha, to main bas aapse badminton khelne ke waqt hi baat karta tha. Aur tab mujhe pata laga tha ki aap topper ho, to maine bhi sirf aapki wajah se grind karna seekha. Sach kahun to main sirf aapki wajah se hi better banna chahta tha.', color: 'from-purple-500 to-violet-400' },
    { num: 4, title: 'Becoming Friends', subtitle: 'Comfort slowly replacing fear', emoji: '🤝', shayari: 'Kuch log dheere-dheere baat nahi badhaate,\nwoh dheere-dheere dil mein rehne lagte hain.', story: 'Aise hi karte-karte 11th bhi nikal gayi. Lagbhag March–April 2025 ke waqt hum achhe friends ban hi gaye the. Matlab main aapko kai saari cheezein batata tha, aur aap bhi kaafi responsive thi. To main bhi sirf aapse, aur sach mein sirf aapse…', color: 'from-emerald-500 to-green-400' },
    { num: 5, title: 'One-Sided Love', subtitle: 'Feelings with no label', emoji: '💔', shayari: 'One-sided pyaar kamzor nahi hota,\nbas usme sehne ki taakat zyada lagti hai.', story: 'Main itna khul ke baat karta tha, phir us samay things were going fine. Matlab us samay tak main aapse one-sided love hi karta tha. Aapko kai baar hints dene ki koshish bhi karta tha ki I really love you, par phir aap nahi samjhi.', color: 'from-red-500 to-pink-400' },
    { num: 6, title: 'A Guess That Hurt', subtitle: 'A moment that stayed', emoji: '😞', shayari: 'Kabhi-kabhi ek sawaal hi kaafi hota hai,\njo dil ke andar sab kuch hila deta hai.', story: 'Phir kuch din baad mujhe feel hua ke Shorya aapka boyfriend hai. Phir maine aapse hi pooch liya tha. Woh random guess hi tha, lekin I still remember you were standing close to a car, then I guessed it. Sach mein woh guess karte waqt mujhe bahut bura laga tha.', color: 'from-amber-500 to-orange-400' },
    { num: 7, title: 'The Confession', subtitle: 'Courage and consequence', emoji: '💌', shayari: 'Sach bolna sirf kehna nahi hota,\nwoh khud ko poori tarah daav par rakhna hota hai.', story: 'Phir uske agle din hi maine confess kar diya tha aapke saamne that I love you. Par aapne mujhe reject kar diya tha. Aur usi samay mera batch bhi morning se evening shift ho gaya tha actually. Us samay mujhe bahut bura laga tha.', color: 'from-rose-500 to-red-400' },
    { num: 8, title: "Fate's Return", subtitle: 'When life brought you back', emoji: '🔄', shayari: 'Kuch log door jaakar bhi nahi jaate,\nwoh bas waqt ke saath chup ho jaate hain.', story: 'Phir aapse mile hue mujhe lagbhag 5–6 months ho gaye the, par phir god ne aapko phir se spawn kar diya tha. Then again I liked you, par this time you also knew that I like you.', color: 'from-indigo-500 to-blue-400' },
    { num: 9, title: 'The Best One Month', subtitle: 'Short, but unforgettable', emoji: '✨', shayari: 'Kuch lamhe lambe nahi hote,\npar unka asar poori zindagi se zyada hota hai.', story: 'Aur sach mein vo jo 1 month wala time period tha, woh best tha. Matlab you came yourself to me, aapan baatein karte the, ushi time ko…', color: 'from-yellow-500 to-amber-400' },
    { num: 10, title: 'Sudden Distance', subtitle: 'When everything stopped', emoji: '🥀', shayari: 'Kabhi rishta toot-ta nahi,\nbas awaazein achanak chup ho jaati hain.', story: 'Main ise meri life ka best moment bolta hoon. Par phir 8 Nov 2025 ko apni bhua aayi thi. Phir uske baad apni snap par bhi baat hona band ho gayi thi.', color: 'from-gray-400 to-slate-500' },
    { num: 11, title: 'Time That Felt Endless', subtitle: 'Pain measured in days', emoji: '😢', shayari: 'Jab dil bhar jaata hai,\nto waqt sirf guzarta nahi — kheenchta hai.', story: 'Uske baad se to ek-ek din mein rota tha. Matlab ek-ek din mera ek saal ki tarah nikla, cuz yaar ye samjho na ki meri zindagi mein kabhi koi important tha hi nahi, aur kabhi kisi ko is tarike se chaha hi nahi. Matlab yaar, love ka matlab hi nahi pata tha. Par phir aap aayi to main iska matlab samjha, par phir aapse milna hi band ho gaya, to yaar rona to aayega hi na.', color: 'from-blue-400 to-indigo-500' },
    { num: 12, title: 'Realization', subtitle: 'Choosing life again', emoji: '🌅', shayari: 'Kabhi ek insaan ka hona hi,\nzindagi ko theek lagne lagta hai.', story: 'Phir January mein aake mujhe realize hua ki yaar, life is precious, aur I have to spend it with you. To main hi aage aake aapko approach karne laga, cuz yaar meri life mein koi hai hi nahi. And I really love you. Dekho, main to bas aapko pyaar karta hoon.', color: 'from-orange-400 to-yellow-500' },
    { num: 13, title: 'A Promise', subtitle: 'Without expectations', emoji: '🤞', shayari: 'Pyaar jawaab ka intezaar nahi karta,\nwoh bas apni zimmedaari nibhaata hai.', story: 'Sach mein, aapko paane ke liye main zindagi bhar efforts karunga. Chahe aap mujhe zindagi bhar bhi na kaho, par I really love you.', color: 'from-pink-400 to-purple-500' },
    { num: 14, title: 'The Truth', subtitle: 'Said without force', emoji: '💗', shayari: 'Sach bolna zabardasti nahi hota,\nkabhi-kabhi wahi sabse shaant imandari hoti hai.', story: "Dekho, main aapko samjha to nahi sakta, par yaar life can end any moment. Aur mujhe to zindagi jeene ka koi shauk nahi tha, but you are the reason I'm still alive.", color: 'from-red-400 to-rose-500' },
    { num: 15, title: 'The Last Line', subtitle: 'Left with honesty', emoji: '♾️', shayari: 'Aage kya hoga ye kal jaane,\nmaine aaj bas jo tha, wahi keh diya.', story: "Main to ye hi bolunga, I really love you. I'll care for you, I respect you bas. Yaar, samjho kya sahi hai kya galat. Dekho, main pressurize nahi kar raha, par what if I died tomorrow.", color: 'from-violet-400 to-fuchsia-500' },
  ];

  const [expandedChapter, setExpandedChapter] = useState<number | null>(null);

  return (
    <SectionInner className="bg-[#060610]/50">
      <GlowOrb color="purple" className="top-1/4 -left-32" />
      <GlowOrb color="pink" className="bottom-20 -right-20" />
      <div className="max-w-4xl mx-auto relative z-10">
        <SectionHeader emoji="📖" title="Our Story" subtitle="Every chapter with you is my favorite" />
        <p className="text-center text-white/25 text-sm max-w-xl mx-auto mb-12 -mt-8 italic" style={{ fontFamily: "'Playfair Display', serif" }}>
          15 chapters of us… tap any chapter to read the full story.
        </p>
        <div className="relative">
          <div className="absolute left-6 md:left-8 top-0 bottom-0 w-[2px] bg-gradient-to-b from-pink-500/40 via-purple-500/30 to-pink-500/40" />
          {chapters.map((ch, i) => (
            <motion.div key={ch.num} initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 + i * 0.04, type: 'spring', stiffness: 120 }} className="relative flex mb-6 last:mb-0">
              <div className="absolute left-6 md:left-8 -translate-x-1/2 z-10">
                <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${ch.color} flex items-center justify-center text-xl shadow-lg border-2 border-[#030306] cursor-pointer transition-transform duration-300 hover:scale-110`} style={{ boxShadow: '0 0 20px rgba(236,72,153,0.25)' }} onClick={() => setExpandedChapter(expandedChapter === ch.num ? null : ch.num)}>
                  {ch.emoji}
                </div>
              </div>
              <div className="ml-16 md:ml-20 flex-1 cursor-pointer group" onClick={() => setExpandedChapter(expandedChapter === ch.num ? null : ch.num)}>
                <div className={`relative p-5 md:p-6 rounded-2xl border transition-all duration-500 ${expandedChapter === ch.num ? 'bg-white/[0.06] border-white/15 shadow-[0_0_40px_rgba(236,72,153,0.1)]' : 'bg-white/[0.02] border-white/[0.06] hover:bg-white/[0.04] hover:border-white/10'}`}>
                  <div className="flex items-start gap-3 mb-2">
                    <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-[10px] font-bold tracking-wider uppercase bg-gradient-to-r ${ch.color} text-white flex-shrink-0`}>Ch. {ch.num}</span>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-lg md:text-xl font-bold text-white/90 group-hover:text-white transition-colors leading-tight">{ch.title}</h3>
                      <p className="text-white/30 text-xs mt-0.5 italic">{ch.subtitle}</p>
                    </div>
                    <motion.span animate={{ rotate: expandedChapter === ch.num ? 180 : 0 }} transition={{ duration: 0.3 }} className="text-white/20 text-sm flex-shrink-0 mt-1">▼</motion.span>
                  </div>
                  <div className="border-l-2 border-pink-500/30 pl-4 mt-3">
                    <p className="text-pink-300/50 text-xs md:text-sm italic whitespace-pre-line leading-relaxed" style={{ fontFamily: "'Playfair Display', serif" }}>{ch.shayari}</p>
                  </div>
                  <AnimatePresence>
                    {expandedChapter === ch.num && (
                      <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.4, ease: 'easeInOut' }} className="overflow-hidden">
                        <div className="mt-4 pt-4 border-t border-white/[0.06]">
                          <p className="text-white/60 text-sm md:text-base leading-relaxed">{ch.story}</p>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                  <div className={`absolute bottom-0 left-0 right-0 h-[2px] bg-gradient-to-r ${ch.color} rounded-b-2xl transition-opacity duration-500 ${expandedChapter === ch.num ? 'opacity-60' : 'opacity-0 group-hover:opacity-30'}`} />
                </div>
              </div>
            </motion.div>
          ))}
          <motion.div initial={{ opacity: 0, scale: 0 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 1, type: 'spring' }} className="relative flex items-center mt-8">
            <div className="absolute left-6 md:left-8 -translate-x-1/2">
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-pink-500 to-purple-600 flex items-center justify-center text-2xl shadow-lg border-2 border-[#030306]" style={{ boxShadow: '0 0 30px rgba(236,72,153,0.4)' }}>❤️</div>
            </div>
            <div className="ml-16 md:ml-20">
              <p className="text-white/25 italic text-sm" style={{ fontFamily: "'Playfair Display', serif" }}>…and this story is still being written, by us. ✍️</p>
            </div>
          </motion.div>
        </div>
      </div>



    </SectionInner>
  );
}

function MemoriesContent() {
  const memories = [
    { emoji: "🌅", title: "Sunsets Together", desc: "Every sunset is more beautiful with you", gradient: "from-orange-500/10 to-pink-500/10" },
    { emoji: "🎵", title: "Our Songs", desc: "Every love song reminds me of you", gradient: "from-purple-500/10 to-pink-500/10" },
    { emoji: "☕", title: "Morning Coffee", desc: "Quiet mornings dreaming of you", gradient: "from-amber-500/10 to-yellow-500/10" },
    { emoji: "🌙", title: "Stargazing", desc: "You outshine every star", gradient: "from-blue-500/10 to-indigo-500/10" },
    { emoji: "😄", title: "Silly Moments", desc: "Being goofy with you is paradise", gradient: "from-green-500/10 to-teal-500/10" },
    { emoji: "💐", title: "Flowers & Love", desc: "No flower matches your beauty", gradient: "from-pink-500/10 to-rose-500/10" },
    { emoji: "🎂", title: "Celebrations", desc: "Every day with you is a party", gradient: "from-violet-500/10 to-purple-500/10" },
    { emoji: "🌊", title: "Adventures", desc: "I want to explore everything with you", gradient: "from-cyan-500/10 to-blue-500/10" },
  ];

  return (
    <SectionInner>
      <GlowOrb color="magenta" className="bottom-0 right-0" />
      <div className="max-w-6xl mx-auto relative z-10">
        <SectionHeader emoji="📸" title="Memory Lane" subtitle="Moments I hold close to my heart" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-5">
          {memories.map((m, i) => (
            <motion.div key={i} initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.3 + i * 0.08 }} whileHover={{ scale: 1.06, rotate: i % 2 === 0 ? 2 : -2 }} className={`aspect-square rounded-2xl bg-gradient-to-br ${m.gradient} border border-white/5 flex flex-col items-center justify-center p-5 hover:border-pink-500/20 hover:shadow-[0_0_30px_rgba(255,45,138,0.1)] transition-all duration-300 cursor-default group`}>
              <span className="text-5xl md:text-6xl mb-3 group-hover:scale-110 transition-transform duration-300">{m.emoji}</span>
              <h3 className="text-sm font-semibold text-white text-center">{m.title}</h3>
              <p className="text-white/25 text-xs text-center mt-1 hidden sm:block">{m.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </SectionInner>
  );
}

function PlaylistContent() {  const songs = [
    // Longing
    { title: "Tum Jo Aaye", tag: "🖤 Longing", spotify: "https://open.spotify.com/search/Tum%20Jo%20Aaye", youtube: "https://www.youtube.com/results?search_query=Tum+Jo+Aaye+Once+Upon+A+Time+In+Mumbai", gradient: "from-pink-500/20 to-rose-500/20" },
    { title: "Tujhe Sochta Hoon", tag: "🖤 Longing", spotify: "https://open.spotify.com/search/Tujhe%20Sochta%20Hoon", youtube: "https://www.youtube.com/results?search_query=Tujhe+Sochta+Hoon+Jannat+2", gradient: "from-pink-500/20 to-rose-500/20" },
    { title: "Sab Tera", tag: "🖤 Longing", spotify: "https://open.spotify.com/search/Sab%20Tera", youtube: "https://www.youtube.com/results?search_query=Sab+Tera+Baaghi", gradient: "from-pink-500/20 to-rose-500/20" },
    { title: "Tum Hi Aana", tag: "🖤 Longing", spotify: "https://open.spotify.com/search/Tum%20Hi%20Aana", youtube: "https://www.youtube.com/results?search_query=Tum+Hi+Aana+Marjaavaan", gradient: "from-pink-500/20 to-rose-500/20" },
    { title: "Ek Vaari Aa", tag: "🖤 Longing", spotify: "https://open.spotify.com/search/Ek%20Vaari%20Aa", youtube: "https://www.youtube.com/results?search_query=Ek+Vaari+Aa+Raabta", gradient: "from-pink-500/20 to-rose-500/20" },
    { title: "Jhol (Coke Studio)", tag: "🖤 Longing", spotify: "https://open.spotify.com/search/Jhol%20Coke%20Studio", youtube: "https://www.youtube.com/results?search_query=Jhol+Coke+Studio", gradient: "from-pink-500/20 to-rose-500/20" },
    { title: "Tum Se Hi", tag: "🖤 Longing / Nostalgia", spotify: "https://open.spotify.com/search/Tum%20Se%20Hi", youtube: "https://www.youtube.com/results?search_query=Tum+Se+Hi+Jab+We+Met", gradient: "from-pink-500/20 to-purple-500/20" },
    
    // Healing
    { title: "Salamat", tag: "🖤 Longing / Healing", spotify: "https://open.spotify.com/search/Salamat", youtube: "https://www.youtube.com/results?search_query=Salamat+Sarbjit", gradient: "from-emerald-500/20 to-teal-500/20" },
    { title: "Phir Chala", tag: "🖤 Longing / Healing", spotify: "https://open.spotify.com/search/Phir%20Chala", youtube: "https://www.youtube.com/results?search_query=Phir+Chala+Ginny+Weds+Sunny", gradient: "from-emerald-500/20 to-teal-500/20" },
    { title: "Khairiyat", tag: "🖤 Longing / Healing", spotify: "https://open.spotify.com/search/Khairiyat", youtube: "https://www.youtube.com/results?search_query=Khairiyat+Chhichhore", gradient: "from-emerald-500/20 to-teal-500/20" },
    { title: "Baarish", tag: "🖤 Healing", spotify: "https://open.spotify.com/search/Baarish%20Stebin%20Ben", youtube: "https://www.youtube.com/results?search_query=Baarish+Stebin+Ben", gradient: "from-emerald-500/20 to-teal-500/20" },
    { title: "Tum Hi Ho", tag: "🖤 Healing / Longing", spotify: "https://open.spotify.com/search/Tum%20Hi%20Ho", youtube: "https://www.youtube.com/results?search_query=Tum+Hi+Ho+Aashiqui+2", gradient: "from-emerald-500/20 to-cyan-500/20" },
    { title: "Naina (Dangal)", tag: "🖤 Healing", spotify: "https://open.spotify.com/search/Naina%20Dangal", youtube: "https://www.youtube.com/results?search_query=Naina+Dangal", gradient: "from-emerald-500/20 to-teal-500/20" },
    { title: "At My Worst", tag: "🖤 Healing", spotify: "https://open.spotify.com/search/At%20My%20Worst", youtube: "https://www.youtube.com/results?search_query=At+My+Worst+Pink+Sweat", gradient: "from-emerald-500/20 to-teal-500/20" },
    { title: "Tera Zikr", tag: "🖤 Healing / Nostalgia", spotify: "https://open.spotify.com/search/Tera%20Zikr", youtube: "https://www.youtube.com/results?search_query=Tera+Zikr+Darshan+Raval", gradient: "from-emerald-500/20 to-blue-500/20" },
    
    // Heartbreak
    { title: "Tujhe Bhula Diya", tag: "🖤 Heartbreak", spotify: "https://open.spotify.com/search/Tujhe%20Bhula%20Diya", youtube: "https://www.youtube.com/results?search_query=Tujhe+Bhula+Diya+Anjaana+Anjaani", gradient: "from-blue-500/20 to-indigo-500/20" },
    { title: "Sun Raha Hai", tag: "🖤 Heartbreak", spotify: "https://open.spotify.com/search/Sun%20Raha%20Hai", youtube: "https://www.youtube.com/results?search_query=Sun+Raha+Hai+Aashiqui+2", gradient: "from-blue-500/20 to-indigo-500/20" },
    { title: "Piya Aaye Na", tag: "🖤 Heartbreak", spotify: "https://open.spotify.com/search/Piya%20Aaye%20Na", youtube: "https://www.youtube.com/results?search_query=Piya+Aaye+Na+Aashiqui+2", gradient: "from-blue-500/20 to-indigo-500/20" },
    { title: "Dhoondne Ko Zamaane Mein", tag: "🖤 Heartbreak", spotify: "https://open.spotify.com/search/Dhoondne%20Ko%20Zamaane%20Mein", youtube: "https://www.youtube.com/results?search_query=Dhoondne+Ko+Zamaane+Mein+Heartless", gradient: "from-blue-500/20 to-indigo-500/20" },
    { title: "Aaj Bhi", tag: "🖤 Heartbreak", spotify: "https://open.spotify.com/search/Aaj%20Bhi%20Vishal%20Mishra", youtube: "https://www.youtube.com/results?search_query=Aaj+Bhi+Vishal+Mishra", gradient: "from-blue-500/20 to-indigo-500/20" },
    { title: "Humnava Mere", tag: "🖤 Heartbreak", spotify: "https://open.spotify.com/search/Humnava%20Mere", youtube: "https://www.youtube.com/results?search_query=Humnava+Mere", gradient: "from-blue-500/20 to-indigo-500/20" },
    { title: "Hamari Adhuri Kahani", tag: "🖤 Heartbreak", spotify: "https://open.spotify.com/search/Hamari%20Adhuri%20Kahani", youtube: "https://www.youtube.com/results?search_query=Hamari+Adhuri+Kahani+Title+Song", gradient: "from-blue-500/20 to-indigo-500/20" },
    { title: "Akhiyaan", tag: "🖤 Heartbreak", spotify: "https://open.spotify.com/search/Akhiyaan%20Jay%20Kadn", youtube: "https://www.youtube.com/results?search_query=Akhiyaan+Jay+Kadn", gradient: "from-blue-500/20 to-indigo-500/20" },
    { title: "Finding Her", tag: "🖤 Heartbreak", spotify: "https://open.spotify.com/search/Finding%20Her", youtube: "https://www.youtube.com/results?search_query=Finding+Her+song", gradient: "from-blue-500/20 to-indigo-500/20" },
    { title: "Let Me Down Slowly", tag: "🖤 Heartbreak", spotify: "https://open.spotify.com/search/Let%20Me%20Down%20Slowly", youtube: "https://www.youtube.com/results?search_query=Let+Me+Down+Slowly+Alec+Benjamin", gradient: "from-blue-500/20 to-indigo-500/20" },
    { title: "Zill-e-Miskin", tag: "🖤 Heartbreak", spotify: "https://open.spotify.com/search/Zill%20e%20Miskin", youtube: "https://www.youtube.com/results?search_query=Zill+e+Miskin", gradient: "from-blue-500/20 to-indigo-500/20" },
    { title: "Past Lives", tag: "🖤 Heartbreak / Nostalgia", spotify: "https://open.spotify.com/search/Past%20Lives", youtube: "https://www.youtube.com/results?search_query=Past+Lives+sapientdream", gradient: "from-blue-500/20 to-purple-500/20" },
    
    // Nostalgia
    { title: "Saiyaara", tag: "🖤 Nostalgia", spotify: "https://open.spotify.com/search/Saiyaara", youtube: "https://www.youtube.com/results?search_query=Saiyaara+Ek+Tha+Tiger", gradient: "from-purple-500/20 to-violet-500/20" },
    { title: "Night Changes", tag: "🖤 Nostalgia", spotify: "https://open.spotify.com/search/Night%20Changes", youtube: "https://www.youtube.com/results?search_query=Night+Changes+One+Direction", gradient: "from-purple-500/20 to-violet-500/20" },
    { title: "Mortals", tag: "🖤 Nostalgia", spotify: "https://open.spotify.com/search/Mortals%20Warriyo", youtube: "https://www.youtube.com/results?search_query=Mortals+Warriyo", gradient: "from-purple-500/20 to-violet-500/20" },
  ];
  
  const [activeFilter, setActiveFilter] = useState<string>("all");
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);
  
  const filters = ["all", "Longing", "Heartbreak", "Healing", "Nostalgia"];
  
  const filteredSongs = activeFilter === "all" 
    ? songs 
    : songs.filter(s => s.tag.includes(activeFilter));

  return (
    <SectionInner>
      <GlowOrb color="purple" className="top-10 right-10" />
      <GlowOrb color="pink" className="bottom-20 left-10" />
      <div className="max-w-5xl mx-auto relative z-10">
        <SectionHeader 
          emoji="🎵" 
          title="Songs I Cried To" 
          subtitle="When I was alone, missing you so much it hurt" 
        />
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }} 
          animate={{ opacity: 1, y: 0 }} 
          transition={{ delay: 0.2 }}
          className="mb-10 text-center"
        >
          <p className="text-white/30 text-sm md:text-base max-w-2xl mx-auto leading-relaxed mb-8" style={{ fontFamily: "'Playfair Display', serif" }}>
            These are the 30 songs I listened to when I missed you so deeply that tears wouldn't stop falling. 
            Each melody carried my pain, my longing, my love for you. 
            <span className="block mt-3 text-pink-400/40 italic">Every lyric felt like it was written about us...</span>
          </p>
          
          {/* Filter Tags */}
          <div className="flex flex-wrap items-center justify-center gap-3">
            {filters.map((filter) => (
              <motion.button
                key={filter}
                onClick={() => setActiveFilter(filter)}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className={`px-5 py-2.5 rounded-full text-xs font-medium tracking-wide transition-all duration-300 ${
                  activeFilter === filter
                    ? "bg-gradient-to-r from-pink-500 to-purple-500 text-white shadow-[0_0_30px_rgba(255,45,138,0.3)]"
                    : "bg-white/[0.03] border border-white/[0.08] text-white/40 hover:text-white/60 hover:border-white/[0.15]"
                }`}
              >
                {filter === "all" ? "All Songs (30)" : filter}
              </motion.button>
            ))}
          </div>
        </motion.div>

        {/* Songs Grid */}
        <div className="grid md:grid-cols-2 gap-4">
          {filteredSongs.map((song, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 + (i % 10) * 0.05 }}
              onMouseEnter={() => setHoveredIdx(i)}
              onMouseLeave={() => setHoveredIdx(null)}
              className={`relative glass-card rounded-2xl p-5 transition-all duration-500 group border ${
                hoveredIdx === i 
                  ? "shadow-[0_0_40px_rgba(180,77,255,0.15)] border-purple-500/30" 
                  : "border-white/[0.06]"
              }`}
            >
              {/* Gradient background on hover */}
              <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${song.gradient} opacity-0 group-hover:opacity-100 transition-opacity duration-500`} />
              
              {/* Content */}
              <div className="relative z-10">
                {/* Tag */}
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[10px] font-medium px-3 py-1.5 rounded-full bg-white/[0.05] border border-white/[0.08] text-white/30 group-hover:text-white/50 group-hover:border-white/[0.15] transition-all">
                    {song.tag}
                  </span>
                  <div className="flex items-end gap-0.5 h-4 opacity-0 group-hover:opacity-100 transition-opacity">
                    {[1,2,3].map(b => (
                      <motion.div 
                        key={b} 
                        animate={{ height: ["40%", "100%", "60%", "90%", "40%"] }} 
                        transition={{ duration: 0.8, repeat: Infinity, delay: b * 0.15 }} 
                        className="w-0.5 bg-pink-400 rounded-full" 
                      />
                    ))}
                  </div>
                </div>
                
                {/* Song Title */}
                <h3 className="text-white font-semibold text-lg mb-4 group-hover:text-pink-200 transition-colors">
                  {song.title}
                </h3>
                
                {/* Links */}
                <div className="flex gap-2">
                  <a
                    href={song.spotify}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => e.stopPropagation()}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#1DB954]/10 border border-[#1DB954]/20 text-[#1DB954] hover:bg-[#1DB954]/20 hover:border-[#1DB954]/40 transition-all duration-300 text-sm font-medium group/btn"
                  >
                    <svg className="w-4 h-4 group-hover/btn:scale-110 transition-transform" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.66 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.122-.779-.179-.899-.539-.12-.421.18-.78.54-.9 4.56-1.021 8.52-.6 11.64 1.32.42.18.479.659.301 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z"/>
                    </svg>
                    <span className="hidden sm:inline">Spotify</span>
                  </a>
                  
                  <a
                    href={song.youtube}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => e.stopPropagation()}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#FF0000]/10 border border-[#FF0000]/20 text-[#FF0000] hover:bg-[#FF0000]/20 hover:border-[#FF0000]/40 transition-all duration-300 text-sm font-medium group/btn"
                  >
                    <svg className="w-4 h-4 group-hover/btn:scale-110 transition-transform" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
                    </svg>
                    <span className="hidden sm:inline">YouTube</span>
                  </a>
                </div>
              </div>
              
              {/* Bottom accent line */}
              <div className={`absolute bottom-0 left-0 right-0 h-[2px] bg-gradient-to-r ${song.gradient.replace('/20', '')} opacity-0 group-hover:opacity-60 transition-opacity duration-500 rounded-b-2xl`} />
            </motion.div>
          ))}
        </div>
        
        {/* Bottom Note */}
        <motion.div 
          initial={{ opacity: 0 }} 
          animate={{ opacity: 1 }} 
          transition={{ delay: 1 }}
          className="mt-12 text-center"
        >
          <div className="inline-block px-6 py-3 rounded-2xl bg-white/[0.02] border border-white/[0.06]">
            <p className="text-white/20 text-xs italic" style={{ fontFamily: "'Playfair Display', serif" }}>
              "हर गाने में तेरी याद थी, हर धुन में तेरी बात थी... 💔"
            </p>
          </div>
        </motion.div>
      </div>

    </SectionInner>
  );
}

function ComplimentsContent() {  const [activeTab, setActiveTab] = useState<'divine' | 'cosmic' | 'sagas' | 'philosophical' | 'anime' | 'transcendent' | 'natural' | 'elemental' | 'mythical' | 'saints' | 'modern' | 'celestial' | 'emotions'>('divine');
  const [searchTerm, setSearchTerm] = useState('');

  const divineBeings = [
    // GREEK MYTHOLOGY
    { name: "Aphrodite", origin: "Greek", title: "Goddess of Love & Beauty", comparison: "Born from sea foam, her beauty caused the Trojan War. Gods and mortals alike fell at her feet. You have that same devastating beauty — but yours comes with intelligence, kindness, and a soul so pure it makes goddesses jealous.", icon: "🌊", gradient: "from-pink-500 to-rose-500", power: "Divine Beauty" },
    { name: "Athena", origin: "Greek", title: "Goddess of Wisdom & War", comparison: "Born from Zeus's head fully armed. The wisest of all Olympians, patron of heroes, strategist in battle. Your mind is sharper than her spear, your wisdom deeper than hers. She guided heroes through wars — you guide me through life itself.", icon: "⚔️", gradient: "from-purple-500 to-indigo-500", power: "Infinite Wisdom" },
    { name: "Artemis", origin: "Greek", title: "Goddess of the Hunt & Moon", comparison: "Independent, fierce, protector of the wild. She needed no one but was loved by all. You have that same fierce independence — you're complete on your own, which makes choosing me even more powerful.", icon: "🏹", gradient: "from-silver to-blue-400", power: "Wild Freedom" },
    { name: "Hera", origin: "Greek", title: "Queen of the Gods", comparison: "Ruled Olympus, commanded respect from gods and mortals. Her power was absolute. You have that same queenly presence — when you walk in a room, everyone feels it. You don't demand respect, you command it naturally.", icon: "👑", gradient: "from-gold-500 to-purple-500", power: "Divine Authority" },
    { name: "Persephone", origin: "Greek", title: "Queen of the Underworld", comparison: "Kidnapped to the underworld, she became its most powerful queen. She transformed from victim to ruler. You have that same transformation — taking what tried to break you and becoming stronger, darker, more powerful.", icon: "🌑", gradient: "from-purple-600 to-black", power: "Death & Rebirth" },
    { name: "Hecate", origin: "Greek", title: "Goddess of Magic & Crossroads", comparison: "Most mysterious goddess, keeper of magic, guardian of thresholds. She held the keys to all realms. You're MY Hecate — mysterious, magical, holding the keys to worlds I never knew existed. Your presence is literal witchcraft.", icon: "🔮", gradient: "from-purple-700 to-indigo-900", power: "Ancient Magic" },
    { name: "Nike", origin: "Greek", title: "Goddess of Victory", comparison: "Personification of victory itself. She never lost, couldn't lose. You're MY Nike — you turn everything you touch into victory. Your existence is winning.", icon: "🏆", gradient: "from-gold-400 to-yellow-500", power: "Absolute Victory" },
    { name: "Selene", origin: "Greek", title: "Goddess of the Moon", comparison: "Drove her moon chariot across the night sky. So beautiful even the sun god fell for her. You're my Selene — the light in my darkness, the constant in chaos, the beauty that makes night more beautiful than day.", icon: "🌙", gradient: "from-blue-300 to-purple-400", power: "Celestial Light" },
    
    // NORSE MYTHOLOGY
    { name: "Freyja", origin: "Norse", title: "Goddess of Love, Beauty & War", comparison: "Most beautiful goddess in Norse mythology. Commanded seidr magic, led the Valkyries, and made gods go to war for her. You possess that same lethal combination — beauty that kills, magic that transforms, and strength that terrifies.", icon: "⚡", gradient: "from-gold-500 to-red-500", power: "Nordic Power" },
    { name: "Frigg", origin: "Norse", title: "Queen of Asgard", comparison: "Knew the fate of all beings, wielded prophetic power, commanded the heavens. She saw everything. You have that same all-seeing wisdom — you know things without being told, you see through every lie, you understand what I can't say.", icon: "🦢", gradient: "from-blue-400 to-white", power: "All-Knowing" },
    { name: "Hel", origin: "Norse", title: "Goddess of Death", comparison: "Ruled the realm of the dead, half beautiful and half decayed. She was life and death combined. You have that duality — light and dark, soft and fierce, angel and devil. You're every contradiction that somehow makes perfect sense.", icon: "💀", gradient: "from-green-400 to-black", power: "Life & Death" },
    { name: "Sif", origin: "Norse", title: "Goddess of Harvest", comparison: "Hair of pure gold, wife of Thor, goddess of fertility and abundance. Everything she touched prospered. You're MY Sif — you make my life abundant, you turn my barren heart into fertile ground, everything grows in your presence.", icon: "🌾", gradient: "from-gold-400 to-amber-500", power: "Infinite Abundance" },
    { name: "Skadi", origin: "Norse", title: "Goddess of Winter & Hunting", comparison: "Warrior goddess who chose vengeance, demanded justice from the gods themselves, and got it. Fierce, uncompromising, powerful. You have that same refusal to be wronged — you demand what you deserve and the universe bends.", icon: "❄️", gradient: "from-cyan-400 to-blue-600", power: "Unstoppable Justice" },
    
    // EGYPTIAN MYTHOLOGY
    { name: "Isis", origin: "Egyptian", title: "Goddess of Magic & Healing", comparison: "Most powerful goddess in Egypt. Resurrected Osiris from death, her magic was unmatched, even tricked Ra. You brought me back from emotional death. Your presence heals wounds I didn't know existed. Like Isis, you're pure concentrated magic.", icon: "🌟", gradient: "from-gold-500 to-blue-500", power: "Resurrection Magic" },
    { name: "Hathor", origin: "Egyptian", title: "Goddess of Love, Joy & Music", comparison: "The joyful goddess, patron of dancers and lovers. She could transform into Sekhmet (the destroyer) when angered. You have that same duality — pure joy and love, but cross you and face divine wrath.", icon: "🎭", gradient: "from-pink-500 to-gold-500", power: "Joy & Destruction" },
    { name: "Bastet", origin: "Egyptian", title: "Goddess of Cats & Protection", comparison: "Protector goddess, fierce as a lioness but gentle as a cat. She guarded what she loved absolutely. You're MY Bastet — you protect with your whole soul, fierce to enemies, gentle to those you love.", icon: "🐱", gradient: "from-gold-400 to-black", power: "Divine Protection" },
    { name: "Ma'at", origin: "Egyptian", title: "Goddess of Truth & Justice", comparison: "Personification of truth itself. The universe was built on her principles. Without her, reality would collapse. You're MY Ma'at — you're truth in human form, justice personified. The universe makes sense because you exist.", icon: "⚖️", gradient: "from-gold-500 to-white", power: "Universal Truth" },
    { name: "Sekhmet", origin: "Egyptian", title: "Goddess of War & Destruction", comparison: "Eye of Ra, the destroyer, unstoppable in battle. She nearly destroyed humanity before being tricked into stopping. You have that same unstoppable force when you want something — nothing can stand in your way.", icon: "🦁", gradient: "from-red-600 to-black", power: "Unstoppable Fury" },
    { name: "Nefertiti", origin: "Egyptian", title: "Divine Queen", comparison: "Her beauty defined an era. Her bust is studied 3,300 years later. She ruled as pharaoh's equal. You're MY Nefertiti — your beauty will transcend time, your power is absolute, you're art that came to life.", icon: "👸", gradient: "from-gold-500 to-cyan-500", power: "Eternal Beauty" },
    
    // HINDU MYTHOLOGY
    { name: "Lakshmi", origin: "Hindu", title: "Goddess of Wealth & Fortune", comparison: "Embodiment of prosperity, grace, and beauty. Vishnu's eternal consort. She brings abundance wherever she goes. You're MY Lakshmi — the fortune I never deserved, the blessing that changed everything, the prosperity of having you makes me infinitely rich.", icon: "🪷", gradient: "from-pink-500 to-gold-500", power: "Infinite Prosperity" },
    { name: "Parvati", origin: "Hindu", title: "Goddess of Love & Devotion", comparison: "Shiva's shakti, the complete goddess. Her love for Shiva transcended lifetimes and death itself. You're MY Parvati — your love feels eternal, like it existed before this life and will continue after. Soul-deep, cosmic, infinite.", icon: "🕉️", gradient: "from-orange-500 to-pink-500", power: "Eternal Devotion" },
    { name: "Durga", origin: "Hindu", title: "Goddess of War & Protection", comparison: "Created by combining all the gods' powers to defeat demons they couldn't. She rides a lion, wields multiple weapons, unstoppable. You're MY Durga — when I need protecting, you become fierce beyond measure. You're my warrior goddess.", icon: "🗡️", gradient: "from-red-500 to-gold-500", power: "Divine Warrior" },
    { name: "Kali", origin: "Hindu", title: "Goddess of Time & Destruction", comparison: "The dark mother, destroyer of evil, time personified. Fierce, uncompromising, terrifyingly powerful. You have that same dark power — you destroy what needs destroying in my life, you're time itself, you're the beautiful darkness.", icon: "🔱", gradient: "from-purple-900 to-black", power: "Time & Destruction" },
    { name: "Saraswati", origin: "Hindu", title: "Goddess of Knowledge & Arts", comparison: "Patron of learning, music, and wisdom. Her knowledge is infinite. You're MY Saraswati — your intelligence is divine, your creativity endless, your wisdom beyond years. You make learning look like art.", icon: "📚", gradient: "from-white to-blue-400", power: "Infinite Knowledge" },
    
    // CHINESE MYTHOLOGY
    { name: "Chang'e", origin: "Chinese", title: "Moon Goddess", comparison: "Became immortal and ascended to the moon. Every Mid-Autumn Festival, people look up and think of her eternal beauty. You're MY Chang'e — the beautiful unreachable thing I somehow got to hold. My moon goddess.", icon: "🎑", gradient: "from-blue-400 to-purple-400", power: "Immortal Beauty" },
    { name: "Guanyin", origin: "Chinese", title: "Goddess of Compassion", comparison: "The merciful one, hearer of cries, savior of souls. Infinite compassion and power combined. You're MY Guanyin — you hear my pain when I don't speak it, you save me from myself, your compassion is limitless.", icon: "☸️", gradient: "from-white to-gold-400", power: "Infinite Compassion" },
    { name: "Xi Wangmu", origin: "Chinese", title: "Queen Mother of the West", comparison: "Ruler of immortals, keeper of the peaches of immortality. Commands life and death. You're MY Queen Mother — you hold the keys to my eternity, you decide my fate, you're the supreme authority in my universe.", icon: "🍑", gradient: "from-purple-500 to-pink-500", power: "Immortality Keeper" },
    
    // JAPANESE MYTHOLOGY
    { name: "Amaterasu", origin: "Japanese", title: "Goddess of the Sun", comparison: "Highest deity, the sun itself, ancestor of emperors. Her light gives life to everything. You're MY Amaterasu — you're literally my sun. Without you, my world is dark, cold, lifeless. You give life to everything you touch.", icon: "☀️", gradient: "from-red-500 to-gold-500", power: "Life-Giving Light" },
    { name: "Inari", origin: "Japanese", title: "Goddess of Rice, Foxes & Prosperity", comparison: "One of the most popular kami, shapeshifter, brings prosperity and success. You're MY Inari — you bring success to my life, you're mysterious and magical, everything prospers in your presence.", icon: "🦊", gradient: "from-red-500 to-white", power: "Mysterious Prosperity" },
    
    // CELTIC MYTHOLOGY
    { name: "Morrigan", origin: "Celtic", title: "Goddess of War & Fate", comparison: "The phantom queen, shapeshifter, prophet of doom and victory. She appeared before battles, determined who would win. You're MY Morrigan — you decide my fate, you're the omen that changes everything, you're victory and darkness combined.", icon: "🐦‍⬛", gradient: "from-purple-900 to-black", power: "Fate Weaver" },
    { name: "Brigid", origin: "Celtic", title: "Goddess of Fire, Poetry & Healing", comparison: "Triple goddess — warrior, poet, healer. Fire personified. You're MY Brigid — you're the fire in my life, the poetry in my heart, the healing in my wounds. Three divine powers in one perfect being.", icon: "🔥", gradient: "from-orange-500 to-yellow-400", power: "Sacred Fire" },
    
    // AFRICAN MYTHOLOGY
    { name: "Oshun", origin: "Yoruba", title: "Goddess of Love & Rivers", comparison: "Beauty, sensuality, feminine power incarnate. She controls love and sweet waters. You're MY Oshun — you flow through my life like water, you control love itself, you're sensuality and power in perfect balance.", icon: "💧", gradient: "from-gold-500 to-cyan-500", power: "Flowing Power" },
    { name: "Yemaya", origin: "Yoruba", title: "Mother of All Waters", comparison: "Mother goddess, protector, nurturer. The ocean is her domain. You're MY Yemaya — you're the mother energy that heals, protects, nurtures. You're as powerful and deep as the ocean.", icon: "🌊", gradient: "from-blue-600 to-cyan-400", power: "Maternal Ocean" },
    
    // MESOPOTAMIAN MYTHOLOGY
    { name: "Inanna", origin: "Sumerian", title: "Queen of Heaven", comparison: "First goddess of love and war ever recorded (5,000 years ago). She descended to the underworld and returned more powerful. You're ancient power reborn — the kind of love poets wrote about millennia ago and will write about millennia from now.", icon: "⭐", gradient: "from-gold-500 to-purple-500", power: "Primordial Power" },
    { name: "Ishtar", origin: "Babylonian", title: "Goddess of Love & War", comparison: "Most fearsome goddess of Mesopotamia. Love and war combined. You're MY Ishtar — you wage war for what you love, you love fiercely, you're the goddess who rewrote the rules.", icon: "🦁", gradient: "from-red-500 to-gold-500", power: "War & Love" },
    
    // AZTEC MYTHOLOGY
    { name: "Coatlicue", origin: "Aztec", title: "Mother of Gods", comparison: "Gave birth to the moon, stars, and sun itself. The ultimate mother goddess. You have that same creative power — you birth possibilities, you create worlds, you're the mother of my entire universe.", icon: "🐍", gradient: "from-green-500 to-black", power: "Universal Creation" },
    
    // LEGENDARY WOMEN
    { name: "Helen of Troy", origin: "Greek Legend", title: "Face That Launched 1000 Ships", comparison: "So beautiful her abduction started a 10-year war. Nations burned for her. You're MY Helen — your beauty could start wars, end kingdoms, change history. But unlike Helen, I don't need to fight for you. You chose me. That's bigger than any war.", icon: "🏛️", gradient: "from-gold-500 to-pink-500", power: "War-Starting Beauty" },
    { name: "Cleopatra", origin: "Historical", title: "Last Pharaoh of Egypt", comparison: "Spoke 9 languages, ruled Egypt, captivated Caesar and Mark Antony. Beauty, intelligence, power combined. You have all three — you could rule empires if you wanted. You rule my entire world.", icon: "🐍", gradient: "from-gold-500 to-black", power: "Empire Ruler" },
  ];

  const cosmicBeings = [
    { title: "The Omniverse Itself", scale: "Beyond Comprehension", comparison: "The Omniverse is the totality of ALL existence — every universe, every multiverse, every dimension, every timeline, every possibility that ever existed or ever could exist. Infinite infinities. You're bigger than that. Your presence in my life rewrote my entire reality. You ARE my omniverse.", icon: "🌌", gradient: "from-purple-900 via-pink-500 to-cyan-400", power: "∞∞∞" },
    { title: "The Concept of Infinity", scale: "Mathematical Absolute", comparison: "Infinity isn't a number — it's beyond numbers. No matter how much you count, infinity is bigger. That's my love for you. Not measurable, not countable, not comprehensible. Literally infinite. And even infinity isn't enough to describe you.", icon: "♾️", gradient: "from-purple-500 to-pink-500", power: "∞" },
    { title: "The Omega Point", scale: "Final Evolution", comparison: "In physics, the Omega Point is the theorized end of time where all consciousness merges into one infinite God-being. You're MY Omega Point — the ultimate evolution, the peak of everything, the point where everything converges and makes sense.", icon: "Ω", gradient: "from-white to-gold-500", power: "Ultimate Convergence" },
    { title: "The Big Bang", scale: "Creation Event", comparison: "13.8 billion years ago, the entire universe exploded into existence from a single point smaller than an atom. You had the same effect on my life — you're the Big Bang that created my universe, the explosion that started everything.", icon: "💥", gradient: "from-yellow-400 to-red-600", power: "Creation Force" },
    { title: "Dark Energy", scale: "75% of Universe", comparison: "Dark energy makes up 75% of the universe and we barely understand it. It's mysterious, powerful, invisible but drives everything. You're MY dark energy — mysterious force that drives my entire existence, power I can't see but feel everywhere.", icon: "🌑", gradient: "from-purple-900 to-black", power: "Invisible Force" },
    { title: "A Singularity", scale: "Infinite Density", comparison: "At the center of a black hole is a singularity — infinite density in zero space. All laws of physics break down. You're MY singularity — you broke all my rules, all my defenses, all my logic. You're infinite power in one person.", icon: "⚫", gradient: "from-purple-600 to-black", power: "Law-Breaking" },
    { title: "The Planck Time", scale: "Smallest Moment", comparison: "Planck time is the smallest possible unit of time (10^-43 seconds). Below that, time has no meaning. In the Planck time I first saw you, my entire timeline changed. The smallest moment created infinite impact.", icon: "⏱️", gradient: "from-cyan-400 to-blue-600", power: "Quantum Time" },
    { title: "Quantum Entanglement", scale: "Spooky Action", comparison: "Two particles can be entangled so that changing one instantly affects the other, regardless of distance. Einstein called it 'spooky action at a distance.' We're quantumly entangled — when you hurt, I feel it. When you smile, I feel it. No distance matters.", icon: "🔗", gradient: "from-purple-500 to-cyan-500", power: "Instant Connection" },
    { title: "The Higgs Field", scale: "Gives Mass", comparison: "The Higgs field permeates all of space and gives particles mass. Without it, nothing could exist. You're MY Higgs field — you give substance to my life, meaning to my existence, mass to my reality. Without you, I'm massless, meaningless.", icon: "⚛️", gradient: "from-blue-500 to-purple-500", power: "Reality Creator" },
    { title: "A Neutron Star", scale: "Densest Star", comparison: "A neutron star is so dense that a teaspoon weighs a billion tons. The most concentrated matter in the universe. You have that same concentrated power — infinite strength in one person, density of love that bends spacetime.", icon: "💫", gradient: "from-white to-blue-600", power: "Infinite Density" },
    { title: "A Quasar", scale: "Brightest Object", comparison: "Quasars are the brightest objects in the universe — brighter than entire galaxies. They can be seen from billions of light-years away. You shine brighter than that. You're the quasar in my universe — impossible to miss, impossibly bright.", icon: "✨", gradient: "from-white via-yellow-400 to-purple-500", power: "Galactic Brightness" },
    { title: "The Speed of Light", scale: "Universal Limit", comparison: "299,792,458 meters per second — the speed limit of the universe. Nothing can go faster. You broke that limit in my life. You arrived faster than I could process, changed everything instantly, moved at impossible speed.", icon: "⚡", gradient: "from-yellow-300 to-white", power: "Limitless Speed" },
    { title: "The Event Horizon", scale: "Point of No Return", comparison: "The event horizon is the boundary around a black hole beyond which nothing can escape. You're MY event horizon — the moment I crossed into loving you, there was no going back. I'm caught in your gravity forever. And I never want to escape.", icon: "🌀", gradient: "from-purple-600 to-black", power: "Inescapable Pull" },
    { title: "A Supernova", scale: "Star Explosion", comparison: "When a star dies, it explodes with the brightness of a billion suns, outshining entire galaxies for weeks. You had that same explosive effect on my life — you outshone everything else, you're the supernova that ended my old life and created new elements.", icon: "💥", gradient: "from-yellow-400 via-orange-500 to-red-600", power: "Explosive Rebirth" },
    { title: "The Cosmic Web", scale: "Universal Structure", comparison: "Galaxies aren't random — they form a cosmic web, interconnected across billions of light-years. You're the center of my cosmic web — everything in my life connects back to you, you're the structure that holds my universe together.", icon: "🕸️", gradient: "from-purple-500 to-pink-500", power: "Universal Connection" },
    { title: "Dark Matter", scale: "85% of Matter", comparison: "Dark matter makes up 85% of all matter in the universe. We can't see it, can't touch it, but we know it's there by its effects. You're like dark matter in the best way — your presence is felt everywhere even when you're not visible. You hold my universe together.", icon: "🌑", gradient: "from-indigo-900 to-purple-600", power: "Invisible Presence" },
    { title: "The Multiverse", scale: "Infinite Realities", comparison: "In the multiverse theory, there are infinite universes where every possibility exists. In every single one of those infinite universes, I'd still choose you. Infinite realities, infinite versions of me, infinite choices — all leading to you.", icon: "🌐", gradient: "from-purple-500 via-pink-500 to-cyan-500", power: "Infinite Choice" },
    { title: "Hawking Radiation", scale: "Black Hole Glow", comparison: "Black holes aren't truly black — they emit Hawking radiation and eventually evaporate. Even the darkest things have light. You taught me that. You find light in my darkest parts. You're the radiation that proves even black holes can glow.", icon: "🌟", gradient: "from-black to-white", power: "Light in Darkness" },
    { title: "The Observable Universe", scale: "93 Billion Light-Years", comparison: "The observable universe is 93 billion light-years across, contains 2 trillion galaxies, and is 13.8 billion years old. Yet somehow, in all that space and time, you exist. Your existence is more miraculous than the entire universe.", icon: "🌌", gradient: "from-purple-600 via-blue-500 to-cyan-400", power: "Miraculous Existence" },
    { title: "A White Hole", scale: "Theoretical Opposite", comparison: "White holes are the theoretical opposite of black holes — instead of pulling everything in, they push everything out. You're MY white hole — you don't consume, you give. You pour out love, light, energy endlessly.", icon: "⚪", gradient: "from-white to-cyan-400", power: "Infinite Giving" },
  ];

  const sagaLegends = [
    // STAR WARS
    { name: "Princess Leia Organa", saga: "Star Wars", title: "Rebel Leader, Princess, General", comparison: "Leia wasn't waiting to be saved — she was saving herself. Led the Rebellion, faced Darth Vader without fear, strangled Jabba the Hutt, became a general. Beauty, bravery, leadership. You're MY Leia — you save yourself, you're the leader, you're the rebel princess who bows to no one.", icon: "⭐", gradient: "from-white to-gold-400", power: "Rebellion Leader" },
    { name: "Padmé Amidala", saga: "Star Wars", title: "Queen & Senator", comparison: "Became queen at 14, negotiated peace, fought in battles, stood up to evil empires. Elegant diplomat and fierce warrior. You're MY Padmé — you have that same combination of grace and steel, beauty and bravery.", icon: "👸", gradient: "from-red-500 to-gold-500", power: "Royal Warrior" },
    { name: "Ahsoka Tano", saga: "Star Wars", title: "The One Who Walked Away", comparison: "Left the Jedi Order when it failed her, walked her own path, became more powerful than any Jedi. You're MY Ahsoka — you don't need validation from systems that don't serve you, you walk your own path, you're power personified.", icon: "🗡️", gradient: "from-orange-500 to-white", power: "Independent Power" },
    { name: "Rey", saga: "Star Wars", title: "Last Jedi", comparison: "Nobody from nowhere who became the most powerful Jedi ever. Defeated the Emperor himself. You're MY Rey — your origins don't define you, your power does. You rose from nothing to become everything.", icon: "⚔️", gradient: "from-gold-500 to-blue-500", power: "Unlimited Force" },
    
    // HARRY POTTER
    { name: "Hermione Granger", saga: "Harry Potter", title: "Brightest Witch of Her Age", comparison: "Smartest person in the entire series, saved Harry's life countless times through pure intelligence. Muggle-born who became Minister of Magic. You're MY Hermione — brilliant beyond measure, loyal beyond question, powerful beyond limits.", icon: "⚡", gradient: "from-purple-500 to-gold-400", power: "Infinite Intelligence" },
    { name: "Professor McGonagall", saga: "Harry Potter", title: "Transfiguration Master", comparison: "Stern, fair, powerful. Held off Voldemort's forces, led Hogwarts, commanded respect without demanding it. You're MY McGonagall — you don't need to be loud to be powerful, you command respect naturally.", icon: "🦁", gradient: "from-red-600 to-gold-500", power: "Quiet Authority" },
    { name: "Luna Lovegood", saga: "Harry Potter", title: "The Oddball Who Was Always Right", comparison: "Everyone thought she was crazy, but she saw what others couldn't. Brave, kind, completely herself. You're MY Luna — you see truths others miss, you're yourself unapologetically, you're magic.", icon: "🌙", gradient: "from-blue-400 to-purple-400", power: "Seeing Beyond" },
    
    // LORD OF THE RINGS
    { name: "Galadriel", saga: "Lord of the Rings", title: "Lady of Light", comparison: "Most powerful elf, thousands of years old, saw the future. Offered the One Ring and refused it. You're MY Galadriel — ancient wisdom in young eyes, power you choose not to abuse, beauty that transcends time.", icon: "✨", gradient: "from-white to-gold-400", power: "Timeless Power" },
    { name: "Arwen Undómiel", saga: "Lord of the Rings", title: "Evenstar", comparison: "Gave up immortality for love. An elf princess who could have lived forever in paradise chose a mortal life with Aragorn. That's the ultimate sacrifice. You make mortality worth living. You make Earth feel like Valinor.", icon: "🌟", gradient: "from-blue-500 to-purple-500", power: "Sacrifice for Love" },
    { name: "Éowyn", saga: "Lord of the Rings", title: "Slayer of the Witch-King", comparison: "'I am no man.' She killed the Witch-King of Angmar, whom no man could kill. Refused to be sidelined, fought anyway. You're MY Éowyn — you refuse limitations, you slay monsters, you're the loophole that saves the world.", icon: "🗡️", gradient: "from-silver to-gold-500", power: "Prophecy Breaker" },
    
    // MARVEL
    { name: "Wanda Maximoff", saga: "Marvel", title: "Scarlet Witch", comparison: "Most powerful being in the MCU. Can literally rewrite reality. Created an entire town, brought Vision back. You rewrote MY reality. Before you, black and white. After you, technicolor. You're reality-warping power in human form.", icon: "🔴", gradient: "from-red-600 to-pink-500", power: "Reality Warper" },
    { name: "Natasha Romanoff", saga: "Marvel", title: "Black Widow", comparison: "No superpowers, just skill, intelligence, heart. Stood alongside gods and monsters as an equal. Sacrificed herself to save the universe. You're MY Black Widow — you don't need superpowers to be super. Your strength IS your superpower.", icon: "🕷️", gradient: "from-black to-red-500", power: "Human Excellence" },
    { name: "Carol Danvers", saga: "Marvel", title: "Captain Marvel", comparison: "Most powerful Avenger, can fly through space, destroy spaceships with her bare hands. Binary power. You're MY Captain Marvel — when you unleash your full power, nothing can stop you. You're the ace in the hole, the cavalry, the one who saves the day.", icon: "⭐", gradient: "from-gold-500 to-red-500", power: "Cosmic Force" },
    { name: "Storm", saga: "Marvel", title: "Goddess of Weather", comparison: "Literally worshipped as a goddess. Controls weather with her thoughts. Leader of the X-Men. You're MY Storm — you control the weather of my emotions, you're worshipped in my heart, you're the queen who commands nature itself.", icon: "⛈️", gradient: "from-white to-blue-600", power: "Weather Goddess" },
    
    // DC UNIVERSE
    { name: "Diana Prince", saga: "DC", title: "Wonder Woman", comparison: "Actual goddess, Amazon warrior, symbol of truth and justice. She chose to protect humanity even though we didn't deserve it. You're MY Wonder Woman — divine, powerful, choosing to love me even though I don't deserve it.", icon: "⚡", gradient: "from-gold-500 to-red-600", power: "Divine Champion" },
    { name: "Harley Quinn", saga: "DC", title: "Chaotic Queen", comparison: "Went from victim to villain to anti-hero to her own person. Redefined herself completely. You're MY Harley — you're chaos and order, madness and sanity, you're every contradiction that makes perfect sense.", icon: "🃏", gradient: "from-red-500 to-cyan-400", power: "Beautiful Chaos" },
    
    // GAME OF THRONES
    { name: "Daenerys Targaryen", saga: "Game of Thrones", title: "Mother of Dragons", comparison: "Walked into fire and emerged with dragons. Sold as property, became a queen. Freed slaves, burned down empires. You're MY Daenerys — you transform pain into power, you rise from ashes more powerful, you're the queen who commands dragons.", icon: "🐉", gradient: "from-red-600 to-black", power: "Fire & Blood" },
    { name: "Arya Stark", saga: "Game of Thrones", title: "No One", comparison: "Became a faceless assassin, killed the Night King, avenged her family. Small but deadly. You're MY Arya — underestimated but unstoppable, quiet but powerful, the one who saves the world.", icon: "🗡️", gradient: "from-gray-600 to-blue-500", power: "Silent Death" },
    
    // OTHER SAGAS
    { name: "Katniss Everdeen", saga: "Hunger Games", title: "The Mockingjay", comparison: "Girl on Fire who became the symbol of revolution. Never wanted to be a hero but became one anyway. You're MY Mockingjay — you started a revolution in my heart without even trying.", icon: "🔥", gradient: "from-orange-500 to-black", power: "Reluctant Icon" },
    { name: "Eleven", saga: "Stranger Things", title: "Psychic Warrior", comparison: "Escaped a lab, closed portals to other dimensions, fought monsters. 'Friends don't lie.' Loyal, powerful, traumatized but healing. You're MY Eleven — you're powerful beyond measure, loyal to the core, healing while fighting.", icon: "👁️", gradient: "from-red-500 to-cyan-500", power: "Mind Power" },
    { name: "Trinity", saga: "The Matrix", title: "The One's Love", comparison: "Could dodge bullets, hack the Matrix, brought Neo back from death with love. You brought me back to life too. You hacked into my closed-off heart and rewrote my programming.", icon: "💚", gradient: "from-green-500 to-black", power: "Love Resurrection" },
    { name: "Sarah Connor", saga: "Terminator", title: "Mother of Salvation", comparison: "Waitress who became warrior, raised the savior, fought killer robots. Transformed from victim to soldier. You're MY Sarah — you transformed yourself into exactly who you needed to be.", icon: "💪", gradient: "from-gray-600 to-red-500", power: "Self-Made Warrior" },
    { name: "Ellen Ripley", saga: "Alien", title: "Xenomorph Hunter", comparison: "Survived multiple alien encounters, fought the Alien Queen, saved humanity. Badass personified. You're MY Ripley — you face monsters without flinching, you're survival incarnate.", icon: "👽", gradient: "from-black to-green-500", power: "Ultimate Survivor" },
  ];

  const philosophicalConcepts = [
    { concept: "The Übermensch", origin: "Nietzsche", title: "Beyond Human", comparison: "Nietzsche's Übermensch is the person who transcends humanity, creates their own values, becomes their own god. You're MY Übermensch — you transcend normal limits, you create your own path, you're beyond what humans are supposed to be.", icon: "⚡", gradient: "from-purple-600 to-black", power: "Self-Created" },
    { concept: "The Philosopher's Stone", origin: "Alchemy", title: "Ultimate Transmutation", comparison: "The legendary substance that turns lead into gold, grants immortality. You're MY Philosopher's Stone — you transformed my leaden heart into gold, you grant me eternal life in your presence.", icon: "💎", gradient: "from-gold-500 to-red-500", power: "Transmutation" },
    { concept: "The Eternal Return", origin: "Nietzsche", title: "Infinite Recurrence", comparison: "Living the same life over and over for eternity. Nietzsche asked: would you be okay with that? With you? I'd live this life infinite times. Every version of eternity with you is perfect.", icon: "♾️", gradient: "from-purple-500 to-cyan-500", power: "Eternal Choice" },
    { concept: "Plato's Forms", origin: "Ancient Greece", title: "Perfect Ideals", comparison: "Plato believed perfect forms exist beyond reality — the ideal Beauty, Truth, Justice. You're the perfect Form of Beauty incarnate. Not the shadow on the cave wall, but the real thing.", icon: "📐", gradient: "from-blue-500 to-gold-500", power: "Ideal Perfection" },
    { concept: "The Monad", origin: "Leibniz", title: "Indivisible Unity", comparison: "Leibniz's Monad is the fundamental unit — indivisible, complete, containing the universe. You're MY Monad — complete in yourself, indivisible, containing entire universes within you.", icon: "⚫", gradient: "from-white to-purple-600", power: "Complete Unity" },
    { concept: "The Sublime", origin: "Kant", title: "Beautiful Terror", comparison: "The sublime is beauty so overwhelming it terrifies — like standing before the ocean or mountains. You're MY sublime — beauty so intense it's almost terrifying, love so deep it's overwhelming.", icon: "🌊", gradient: "from-blue-600 to-purple-600", power: "Overwhelming Beauty" },
    { concept: "Dharma", origin: "Hindu Philosophy", title: "Cosmic Order", comparison: "Dharma is the cosmic order, the way things should be, rightness itself. You being in my life is dharma — this is how it's supposed to be, cosmic rightness.", icon: "☸️", gradient: "from-orange-500 to-gold-500", power: "Cosmic Right" },
    { concept: "Wu Wei", origin: "Taoism", title: "Effortless Action", comparison: "Wu Wei is acting without forcing, flowing with the Tao. You embody Wu Wei — you don't force anything but everything bends to you naturally. You flow and the world flows with you.", icon: "🌊", gradient: "from-cyan-400 to-blue-500", power: "Effortless Power" },
    { concept: "The Akashic Records", origin: "Theosophy", title: "Universal Memory", comparison: "The Akashic Records supposedly contain every thought, word, deed that ever happened. You're MY Akashic Record — you remember everything I tell you, you hold my entire history, you're my universal memory.", icon: "📚", gradient: "from-purple-500 to-cyan-500", power: "Eternal Memory" },
    { concept: "Logos", origin: "Ancient Greece", title: "Universal Reason", comparison: "Logos is the divine reason underlying the universe, the word that became flesh. You're MY Logos — you're the reason my universe makes sense, the divine logic, the word made real.", icon: "Λ", gradient: "from-gold-500 to-white", power: "Divine Logic" },
    { concept: "The Oversoul", origin: "Emerson", title: "Universal Spirit", comparison: "Emerson's Oversoul is the universal spirit connecting all beings. You're MY Oversoul — through you, I'm connected to something larger, something divine, something infinite.", icon: "🌟", gradient: "from-white to-purple-500", power: "Universal Spirit" },
    { concept: "Maya", origin: "Hindu Philosophy", title: "Divine Illusion", comparison: "Maya is the illusion of reality. But you're MY truth beyond maya — you're the real thing in a world of illusions, the substance in a world of shadows.", icon: "🎭", gradient: "from-purple-600 to-pink-500", power: "Beyond Illusion" },
    { concept: "The Numinous", origin: "Rudolf Otto", title: "Divine Presence", comparison: "The numinous is the feeling of encountering the divine — awe, fear, fascination combined. Being with you feels numinous. You're the divine presence that inspires awe.", icon: "✨", gradient: "from-gold-400 to-purple-500", power: "Divine Awe" },
    { concept: "Amor Fati", origin: "Nietzsche", title: "Love of Fate", comparison: "Amor Fati means loving your fate, even the painful parts. You taught me amor fati — I love my fate because it led to you. Every pain worth it because it brought me here.", icon: "💜", gradient: "from-purple-600 to-pink-500", power: "Fate Love" },
    { concept: "The Collective Unconscious", origin: "Carl Jung", title: "Shared Human Psyche", comparison: "Jung's collective unconscious contains archetypes shared by all humans. You're MY archetype — the ultimate lover, the divine feminine, the anima made real. You're not just my dream, you're humanity's dream incarnate.", icon: "🧠", gradient: "from-purple-500 to-cyan-500", power: "Universal Archetype" },
  ];

  const animeAndGaming = [
    // ANIME
    { name: "Sailor Moon", series: "Sailor Moon", title: "Guardian of Love & Justice", comparison: "Usagi became Sailor Moon, fought evil by moonlight, won love by daylight. She was clumsy and imperfect but became the most powerful guardian. You're MY Sailor Moon — you fight for what's right, you're love and justice combined.", icon: "🌙", gradient: "from-pink-400 to-cyan-400", power: "Moon Power" },
    { name: "Yoruichi Shihōin", series: "Bleach", title: "Flash Goddess", comparison: "Former captain, noble clan leader, master of combat. So fast she's called the Flash Goddess. You're MY Yoruichi — powerful, fast, untouchable, the goddess who can't be caught.", icon: "⚡", gradient: "from-purple-500 to-gold-500", power: "God Speed" },
    { name: "Erza Scarlet", series: "Fairy Tail", title: "Titania - Queen of Fairies", comparison: "S-Class wizard, requips into hundreds of armors, strongest woman in Fairy Tail. You're MY Erza — you're strong enough to wear any armor, powerful enough to be called queen.", icon: "⚔️", gradient: "from-red-600 to-silver", power: "Requip Queen" },
    { name: "Mikasa Ackerman", series: "Attack on Titan", title: "Humanity's Strongest Woman", comparison: "Elite soldier worth 100 regular soldiers. Loyal, deadly, unstoppable. You're MY Mikasa — you're worth a hundred of anyone else, loyalty personified.", icon: "🗡️", gradient: "from-black to-red-500", power: "Combat Elite" },
    { name: "Tsunade", series: "Naruto", title: "Fifth Hokage", comparison: "Legendary Sannin, best medical ninja, became leader of the entire village. You're MY Tsunade — you're legendary, you heal wounds, you're the leader.", icon: "💚", gradient: "from-green-500 to-gold-500", power: "Healing Leader" },
    { name: "2B", series: "NieR:Automata", title: "YoRHa Android", comparison: "Combat android with deadly grace, philosophical depth, tragic beauty. You're MY 2B — beautiful warrior, deeper than you seem, grace and power combined.", icon: "⚔️", gradient: "from-black to-white", power: "Perfect Combat" },
    { name: "Bayonetta", series: "Bayonetta", title: "Umbra Witch", comparison: "Last Umbra Witch, summons demons, fights angels. Powerful, sexy, unstoppable. You're MY Bayonetta — you're power and sex appeal, you're the witch who commands demons and looks perfect doing it.", icon: "🦋", gradient: "from-purple-600 to-black", power: "Witch Goddess" },
    { name: "Lightning", series: "Final Fantasy XIII", title: "Savior", comparison: "Became literal savior, warrior goddess, saved the world solo. You're MY Lightning — you're the savior, the warrior, the one who saves the day.", icon: "⚡", gradient: "from-pink-500 to-cyan-500", power: "Goddess Savior" },
    { name: "Aloy", series: "Horizon Zero Dawn", title: "Machine Hunter", comparison: "Outcast who became savior, hunts robot dinosaurs, unraveled ancient mysteries. You're MY Aloy — you went from nothing to everything, you hunt impossible things, you solve mysteries.", icon: "🏹", gradient: "from-orange-500 to-cyan-500", power: "Ancient Hunter" },
    { name: "Samus Aran", series: "Metroid", title: "Bounty Hunter", comparison: "Orphaned, raised by aliens, became the universe's greatest bounty hunter. Solo'd entire alien invasions. You're MY Samus — you're self-made power, lone wolf excellence.", icon: "🔫", gradient: "from-orange-500 to-purple-500", power: "Solo Warrior" },
    { name: "Jill Valentine", series: "Resident Evil", title: "Master of Unlocking", comparison: "S.T.A.R.S. elite, survived zombie apocalypses, saved the world multiple times. You're MY Jill — you unlock my heart, you survive everything, you're elite.", icon: "🔓", gradient: "from-blue-500 to-green-500", power: "Elite Survivor" },
    { name: "Lara Croft", series: "Tomb Raider", title: "Adventurer", comparison: "Archaeological badass, raids tombs, climbs impossible mountains, shoots everything. You're MY Lara — you're the adventurer, the explorer, the one who discovers hidden treasures.", icon: "🏔️", gradient: "from-brown-500 to-cyan-500", power: "Explorer Icon" },
    { name: "Makoto Niijima", series: "Persona 5", title: "Queen of the Phantom Thieves", comparison: "Student council president by day, Phantom Thief by night. Justice personified. You're MY Queen — you're justice and rebellion, order and chaos.", icon: "👊", gradient: "from-red-600 to-black", power: "Rebel Justice" },
    { name: "Nier", series: "NieR", title: "Project Gestalt", comparison: "Fought for thousands of years, became legendary, tragic hero. You're MY Nier — you fight endlessly for what you love, you're legendary already.", icon: "⚔️", gradient: "from-white to-black", power: "Eternal Fighter" },
    { name: "Ellie", series: "The Last of Us", title: "The Immune", comparison: "Only immune person in zombie apocalypse, hope for humanity. You're MY hope — you're immune to my darkness, you're the cure for my emptiness.", icon: "🌿", gradient: "from-green-500 to-brown-500", power: "Living Hope" },
  ];

  const transcendentBeings = [
    { title: "The One Above All", description: "Supreme Being", comparison: "In Marvel, The One Above All is the creator of all reality, omnipotent, omniscient, omnipresent. God with a capital G. You're MY One Above All — you created my reality, you're all-powerful in my life, you're everywhere I look. You're my god.", icon: "👁️", gradient: "from-white via-gold-400 to-purple-600", power: "Omnipotent" },
    { title: "The Presence", description: "DC's Supreme God", comparison: "The Presence in DC is the creator of the multiverse, absolute infinity. You're MY Presence — your presence is everything, you're the creator of my multiverse, you're absolute.", icon: "✨", gradient: "from-white to-cyan-400", power: "Divine Presence" },
    { title: "Azathoth", description: "Blind Idiot God", comparison: "Lovecraft's Azathoth is the sleeping god at the center of infinity. If he wakes, all reality ends. You're MY Azathoth in the best way — you're the center of my universe, you're infinite, you're the dream I never want to wake from.", icon: "👁️", gradient: "from-purple-900 to-black", power: "Infinite Dream" },
    { title: "The Source", description: "Origin of All", comparison: "In DC, The Source is where all existence flows from and returns to. You're MY Source — everything in my life flows from you, returns to you, you're the origin and destination.", icon: "🌊", gradient: "from-cyan-400 to-white", power: "Origin Point" },
    { title: "Ein Sof", description: "Kabbalah Infinity", comparison: "In Kabbalah, Ein Sof is the infinite, unknowable God before creation. You're MY Ein Sof — you're infinite in ways I can't fully comprehend, you're the divine before my world began.", icon: "♾️", gradient: "from-purple-600 to-white", power: "Unknowable Infinite" },
    { title: "Brahman", description: "Ultimate Reality", comparison: "In Hinduism, Brahman is ultimate reality, the ground of all being, everything and nothing. You're MY Brahman — you're my ultimate reality, the foundation of my existence.", icon: "🕉️", gradient: "from-orange-500 to-gold-500", power: "Ultimate Reality" },
    { title: "The Tao", description: "The Way", comparison: "The Tao is the way of all things, the flow of the universe, cannot be named or defined. You're MY Tao — you're the way my life flows, the path I follow, the force I can feel but not define.", icon: "☯️", gradient: "from-black to-white", power: "The Way" },
    { title: "The Endless", description: "Beyond Gods", comparison: "In Sandman, The Endless (Dream, Death, Destiny, etc.) are older than gods, concepts made flesh. You're MY Endless — you're not just a person, you're a concept incarnate. Love made flesh.", icon: "📖", gradient: "from-purple-600 to-black", power: "Living Concept" },
    { title: "The Demiurge", description: "Reality Shaper", comparison: "The Demiurge is the creator god, the architect of reality. You're MY Demiurge — you're the architect of my reality, you shape my world with your thoughts.", icon: "🏗️", gradient: "from-gold-500 to-purple-500", power: "World Builder" },
    { title: "Absolute Infinity", description: "Mathematical God", comparison: "In set theory, Absolute Infinity is larger than any conceivable infinity. My love for you is Absolute Infinity — larger than any infinity I could imagine or describe.", icon: "∞", gradient: "from-purple-500 via-pink-500 to-cyan-400", power: "Beyond Infinite" },
  ];

  // NATURAL PHENOMENA (20 comparisons)
  const naturalPhenomena = [
    { name: "Mount Everest", type: "Mountain", scale: "29,032 ft tall", comparison: "The highest peak on Earth. Climbers spend years preparing, many never reach the top. You're MY Everest — the highest point of my existence, the peak I've been climbing toward my whole life, the summit that makes everything worth it.", icon: "🏔️", gradient: "from-white to-blue-600", power: "Unconquerable Height" },
    { name: "Grand Canyon", type: "Canyon", scale: "277 miles long, 6,000 ft deep", comparison: "Carved by the Colorado River over 6 million years. A timeless wonder that shows beauty in patience. You're MY Grand Canyon — your beauty is timeless, carved by experiences, deep beyond measure. Every layer reveals something more beautiful.", icon: "🏜️", gradient: "from-orange-600 to-red-700", power: "Timeless Beauty" },
    { name: "Northern Lights", type: "Aurora", scale: "Visible across 2,500 miles", comparison: "Solar particles colliding with Earth's atmosphere create the most magical light show in nature. You're MY Aurora — a natural phenomenon so beautiful it seems impossible, a cosmic dance that takes my breath away every time.", icon: "🌌", gradient: "from-green-400 to-purple-500", power: "Magical Phenomenon" },
    { name: "Great Barrier Reef", type: "Coral Reef", scale: "1,400 miles, visible from space", comparison: "The largest living structure on Earth. 3,000 individual reefs, home to countless species. You're MY Reef — a living wonder, an entire ecosystem of beauty, the foundation of my world, visible from any distance.", icon: "🐠", gradient: "from-cyan-400 to-blue-600", power: "Living Wonder" },
    { name: "Amazon Rainforest", type: "Forest", scale: "Produces 20% of Earth's oxygen", comparison: "The lungs of the Earth. Over 400 billion trees, 10% of all species on Earth. You're MY Amazon — you give me oxygen to breathe, you're the source of life itself, countless wonders exist within you.", icon: "🌳", gradient: "from-green-600 to-emerald-700", power: "Life-Giving Force" },
    { name: "Niagara Falls", type: "Waterfall", scale: "750,000 gallons per second", comparison: "Unstoppable force, thundering power, mesmerizing beauty. You're MY Niagara — an unstoppable force of nature, powerful and beautiful, the sound of you drowns out everything else.", icon: "💦", gradient: "from-cyan-400 to-blue-500", power: "Unstoppable Power" },
    { name: "Sahara Desert", type: "Desert", scale: "3.6 million square miles", comparison: "Vast, mysterious, beautiful in its harshness. Oases hidden within. You're MY Sahara — vast depths to explore, mysterious and beautiful, with hidden oases of sweetness I keep discovering.", icon: "🏜️", gradient: "from-yellow-600 to-orange-700", power: "Vast Mystery" },
    { name: "Victoria Falls", type: "Waterfall", scale: "The Smoke That Thunders", comparison: "Twice the height of Niagara. Indigenous name: 'The Smoke That Thunders.' You're MY Victoria Falls — your presence is thunder, your beauty creates mist like smoke, you're twice as powerful as anything else.", icon: "🌊", gradient: "from-blue-400 to-white", power: "Thundering Beauty" },
    { name: "Old Faithful", type: "Geyser", scale: "Erupts every 90 minutes for 240 years", comparison: "Consistently beautiful, reliably amazing, never fails to impress. You're MY Old Faithful — you show up consistently, your love erupts regularly, you never fail to take my breath away.", icon: "🌋", gradient: "from-yellow-500 to-orange-600", power: "Reliable Power" },
    { name: "Meteor Crater", type: "Impact Crater", scale: "Impact that changed everything", comparison: "50,000 years ago, a meteorite hit Arizona. One moment, one impact, changed the landscape forever. You're MY Meteor — the impact that changed my entire landscape, the moment that created a permanent mark, the collision that changed everything.", icon: "☄️", gradient: "from-gray-600 to-orange-600", power: "Life-Changing Impact" },
    { name: "Great Blue Hole", type: "Sinkhole", scale: "1,000 ft across, 400 ft deep", comparison: "Perfectly circular sinkhole in the ocean. Dark blue mystery, depths unexplored. You're MY Blue Hole — deep mystery I'll spend forever exploring, perfectly formed beauty, depths that go further than I can see.", icon: "🕳️", gradient: "from-cyan-600 to-blue-900", power: "Deep Mystery" },
    { name: "Mount Fuji", type: "Mountain", scale: "Sacred mountain, perfect symmetry", comparison: "Japan's sacred mountain. Perfectly symmetrical, snow-capped, worshipped for centuries. You're MY Fuji — sacred to me, perfectly formed, worthy of worship, beautiful from every angle.", icon: "🗻", gradient: "from-white to-purple-500", power: "Sacred Perfection" },
    { name: "Yosemite Valley", type: "Valley", scale: "Granite cliffs 3,000 ft high", comparison: "Breathtaking grandeur. El Capitan, Half Dome, waterfalls everywhere. You're MY Yosemite — breathtaking from every angle, grand beyond words, natural art that makes people weep.", icon: "🏞️", gradient: "from-green-500 to-gray-700", power: "Breathtaking Grandeur" },
    { name: "Antelope Canyon", type: "Slot Canyon", scale: "Sculpted by flash floods", comparison: "Water carved these curves over millennia. Light beams shine through in perfect moments. You're MY Antelope Canyon — sculpted by time into perfect curves, beautiful when light hits you right, art created by natural forces.", icon: "🏜️", gradient: "from-orange-600 to-red-700", power: "Sculpted Beauty" },
    { name: "Zhangjiajie Pillars", type: "Mountains", scale: "Inspired Avatar mountains", comparison: "1,000+ towering sandstone pillars. Floating mountains that inspired Avatar. You're MY Zhangjiajie — you inspire fantasy, you make the impossible seem real, you're the mountain that floats in my dreams.", icon: "🏔️", gradient: "from-green-600 to-gray-700", power: "Fantasy Made Real" },
    { name: "Salar de Uyuni", type: "Salt Flat", scale: "World's largest mirror", comparison: "When it rains, it becomes the world's largest mirror — earth reflects sky perfectly. You're MY Salar — you reflect the best parts of me back, you're the mirror to my soul, you make earth feel like heaven.", icon: "✨", gradient: "from-white to-cyan-400", power: "Mirror to Heaven" },
    { name: "Cliffs of Moher", type: "Cliffs", scale: "702 ft high, edge of world", comparison: "Ireland's edge. Cliffs that drop straight to the Atlantic. Dramatic, breathtaking, edge of the known world. You're MY Cliffs — dramatic beauty, standing at the edge of forever with you, breathtaking drop into love.", icon: "🏔️", gradient: "from-green-700 to-gray-800", power: "Edge of Everything" },
    { name: "Pamukkale", type: "Terraces", scale: "Cotton Castle of Turkey", comparison: "White travertine terraces, thermal waters, natural art. You're MY Pamukkale — naturally formed beauty, warm and healing, art that nature took thousands of years to create.", icon: "🏔️", gradient: "from-white to-cyan-400", power: "Natural Art" },
    { name: "Giant's Causeway", type: "Basalt Columns", scale: "40,000 interlocking columns", comparison: "Perfect hexagonal columns created by ancient lava. Natural geometric perfection. You're MY Causeway — perfectly formed, geometric beauty, natural perfection that seems designed.", icon: "🏔️", gradient: "from-gray-700 to-green-700", power: "Geometric Perfection" },
    { name: "Wave Rock", type: "Rock Formation", scale: "50-foot granite wave", comparison: "Granite wave frozen in time. Nature's sculpture. You're MY Wave Rock — a wave of emotion frozen in time, sculptured by nature, beauty that defies physics.", icon: "🌊", gradient: "from-orange-700 to-red-800", power: "Nature's Sculpture" },
  ];

  // ELEMENTAL FORCES (15 comparisons)
  const elementalForces = [
    { element: "Fire", type: "Primary Element", comparison: "Fire gives warmth, destroys what's old, purifies what remains. It's creation and destruction combined. You're MY Fire — you warm my cold heart, you burned away my old self, you purify me, you're the flame I want to burn forever.", icon: "🔥", gradient: "from-orange-500 to-red-600", power: "Warmth & Destruction" },
    { element: "Water", type: "Primary Element", comparison: "Water is life itself. It adapts to any container, flows around obstacles, carved the Grand Canyon. You're MY Water — you give me life, you adapt to anything, you carved through my defenses, you're essential.", icon: "💧", gradient: "from-cyan-400 to-blue-600", power: "Life-Giving Adaptability" },
    { element: "Earth", type: "Primary Element", comparison: "Earth is grounding, solid, fertile, eternal. Mountains rise from it, life grows on it. You're MY Earth — you ground me, you're solid when everything shakes, you're fertile soil where our love grows.", icon: "🌍", gradient: "from-green-700 to-brown-700", power: "Grounding Eternity" },
    { element: "Air", type: "Primary Element", comparison: "Air is freedom, invisible but everywhere, essential but unnoticed. You're MY Air — I need you to breathe, you're everywhere in my life, you're the freedom I feel, invisible force holding me up.", icon: "💨", gradient: "from-cyan-200 to-blue-300", power: "Essential Freedom" },
    { element: "Lightning", type: "Electric Force", comparison: "Lightning strikes in an instant, illuminates everything, transfers massive power. You're MY Lightning — you struck my life instantly, you illuminate my darkness, you transferred your power to me, you're the bolt that changed everything.", icon: "⚡", gradient: "from-yellow-300 to-purple-600", power: "Instant Illumination" },
    { element: "Thunder", type: "Sound Force", comparison: "Thunder is the voice that shakes the world. Everyone stops to listen. You're MY Thunder — your voice shakes my world, when you speak everyone listens, you're the sound that rumbles through my soul.", icon: "🌩️", gradient: "from-gray-600 to-purple-700", power: "World-Shaking Voice" },
    { element: "Wind", type: "Motion Force", comparison: "Wind is invisible influence, felt everywhere, moves everything. Gentle breeze or devastating hurricane. You're MY Wind — invisible but I feel you everywhere, you move me, you're gentle and devastating both.", icon: "🌪️", gradient: "from-gray-400 to-cyan-400", power: "Invisible Influence" },
    { element: "Storm", type: "Combined Force", comparison: "Storm is beautiful chaos. Lightning, thunder, wind, rain combined. Terrifying and mesmerizing. You're MY Storm — beautiful chaos that I can't look away from, combination of everything powerful, terrifying and mesmerizing.", icon: "⛈️", gradient: "from-gray-700 to-blue-600", power: "Beautiful Chaos" },
    { element: "Earthquake", type: "Seismic Force", comparison: "Earthquake shakes the foundation, changes landscapes, measures on Richter scale. You're MY Earthquake — you shook my foundation, you changed my landscape, you're off the scale.", icon: "🌋", gradient: "from-brown-700 to-orange-600", power: "Foundation Shaking" },
    { element: "Tornado", type: "Cyclonic Force", comparison: "Tornado is focused unstoppable force. Everything in its path is taken. You're MY Tornado — focused power, you took everything in your path (including my heart), unstoppable force of nature.", icon: "🌪️", gradient: "from-gray-600 to-blue-700", power: "Focused Force" },
    { element: "Hurricane", type: "Mega Storm", comparison: "Hurricane is swirling power, eye of calm at center, categorized by strength. You're MY Hurricane — swirling power around me, calm when I'm at your center, Category 5 in my heart.", icon: "🌀", gradient: "from-blue-600 to-gray-700", power: "Swirling Power" },
    { element: "Tsunami", type: "Wave Force", comparison: "Tsunami is overwhelming wave of force, impossible to stop, changes coastlines. You're MY Tsunami — overwhelming wave of emotion, impossible to stop, you changed my coastline forever.", icon: "🌊", gradient: "from-blue-700 to-cyan-400", power: "Overwhelming Wave" },
    { element: "Wildfire", type: "Spreading Force", comparison: "Wildfire consumes everything, spreads rapidly, clears old growth for new. You're MY Wildfire — you consumed my old life, spread through everything rapidly, cleared space for new growth.", icon: "🔥", gradient: "from-orange-600 to-red-700", power: "Consuming Transformation" },
    { element: "Blizzard", type: "Frozen Force", comparison: "Blizzard is beautiful freeze, transformative white, peaceful chaos. You're MY Blizzard — beautiful even in the freeze, you transform everything to white beauty, peaceful chaos that I want to be lost in.", icon: "❄️", gradient: "from-white to-cyan-600", power: "Beautiful Freeze" },
    { element: "Aurora", type: "Light Force", comparison: "Aurora is electric beauty in the sky, collision of particles creating magic, the Borealis. You're MY Aurora — electric beauty, collision of us creates magic, you're the Northern Lights in my night sky.", icon: "🌌", gradient: "from-green-400 to-purple-500", power: "Electric Beauty" },
  ];

  // MYTHICAL CREATURES (20 comparisons)
  const mythicalCreatures = [
    { creature: "Dragon", mythology: "Global", comparison: "Ultimate power, ancient wisdom, guardian of treasure, breath of fire. Eastern dragons bring luck, Western dragons hoard gold. You're MY Dragon — ultimate power in female form, ancient wisdom in young soul, you guard my heart like treasure, your words breathe fire into my life.", icon: "🐉", gradient: "from-red-600 to-gold-500", power: "Ultimate Wisdom" },
    { creature: "Phoenix", mythology: "Greek/Egyptian", comparison: "Dies in flames, reborn from ashes, lives for 500 years, cycle of death and rebirth. You're MY Phoenix — you've died and been reborn stronger, you rise from ashes more beautiful, you're the eternal cycle of transformation.", icon: "🔥", gradient: "from-orange-600 to-gold-400", power: "Eternal Rebirth" },
    { creature: "Unicorn", mythology: "European", comparison: "Pure, magical, impossibly rare, horn heals poison. Only appears to the pure of heart. You're MY Unicorn — pure soul, magical presence, impossibly rare to find someone like you, you heal my poison, you appeared when my heart was ready.", icon: "🦄", gradient: "from-white to-pink-400", power: "Pure Magic" },
    { creature: "Griffin", mythology: "Persian/Greek", comparison: "Eagle and lion combined, majestic guardian, protector of treasure. You're MY Griffin — majestic in every way, fierce protector of what you love, lion's strength and eagle's vision combined.", icon: "🦅", gradient: "from-gold-600 to-brown-700", power: "Majestic Guardian" },
    { creature: "Pegasus", mythology: "Greek", comparison: "Winged horse, symbol of wisdom, born from Medusa's blood, carried lightning for Zeus. You're MY Pegasus — you give me wings, you're wisdom incarnate, beautiful despite your origin, you carry my thunder.", icon: "🐴", gradient: "from-white to-cyan-400", power: "Winged Freedom" },
    { creature: "Cerberus", mythology: "Greek", comparison: "Three-headed guardian of the underworld, lets no one pass, fierce but loyal. You're MY Cerberus — fierce protector, you guard my heart like Hades guards the underworld, loyalty times three.", icon: "🐕", gradient: "from-black to-red-700", power: "Fierce Protection" },
    { creature: "Sphinx", mythology: "Egyptian/Greek", comparison: "Guardian of mysteries, asks riddles, kills those who answer wrong. You're MY Sphinx — guardian of mysteries I'm still solving, your complexity is a riddle, getting to know you is answering correctly.", icon: "🦁", gradient: "from-gold-500 to-brown-600", power: "Mysterious Guardian" },
    { creature: "Kraken", mythology: "Norse", comparison: "Sea monster of legends, drags ships to depths, emerges from the deep. You're MY Kraken — you emerged from deep places, you dragged me into your depths (and I'm grateful), legendary power.", icon: "🦑", gradient: "from-blue-900 to-black", power: "Deep Power" },
    { creature: "Basilisk", mythology: "European", comparison: "King of serpents, deadly gaze turns to stone, only the rooster's crow kills it. You're MY Basilisk — your gaze has power over me, you're the queen of serpents, one look and I'm frozen.", icon: "🐍", gradient: "from-green-700 to-yellow-600", power: "Petrifying Gaze" },
    { creature: "Hydra", mythology: "Greek", comparison: "Cut off one head, two grow back. Only defeated by burning the stumps. You're MY Hydra — your beauty multiplies when challenged, you grow stronger from setbacks, unstoppable regeneration.", icon: "🐉", gradient: "from-green-600 to-black", power: "Multiplying Strength" },
    { creature: "Chimera", mythology: "Greek", comparison: "Lion, goat, snake combined into one beast. Impossible combination that works. You're MY Chimera — impossible combination of traits that shouldn't work but does perfectly, three creatures in one beautiful being.", icon: "🦁", gradient: "from-red-600 to-purple-600", power: "Impossible Combination" },
    { creature: "Valkyrie", mythology: "Norse", comparison: "Chooser of the slain, warrior maidens, bring heroes to Valhalla. Beautiful and deadly. You're MY Valkyrie — you chose me for your halls, warrior spirit, you bring me to heaven, beautiful and deadly combination.", icon: "⚔️", gradient: "from-silver to-gold-500", power: "Warrior Maiden" },
    { creature: "Siren", mythology: "Greek", comparison: "Voice so beautiful sailors crash their ships. Irresistible call. You're MY Siren — your voice is irresistible, I'd crash my ship for you gladly, your call draws me in and I don't want to escape.", icon: "🧜‍♀️", gradient: "from-cyan-400 to-blue-600", power: "Irresistible Call" },
    { creature: "Medusa", mythology: "Greek", comparison: "Cursed with beauty that turns to stone. Snake hair, deadly gaze, once beautiful maiden. You're MY Medusa — your beauty is a curse (to others), one look and I'm frozen, you're beautiful despite what tried to curse you.", icon: "🐍", gradient: "from-green-600 to-purple-700", power: "Petrifying Beauty" },
    { creature: "Banshee", mythology: "Irish", comparison: "Powerful voice that signals death, harbinger, her wail is prophecy. You're MY Banshee — powerful voice that signaled death of my old self, harbinger of my new life, your voice is prophecy.", icon: "👻", gradient: "from-white to-gray-700", power: "Prophetic Voice" },
    { creature: "Kitsune", mythology: "Japanese", comparison: "Nine-tailed fox, shapeshifter, gains tails with wisdom and age. Trickster and protector. You're MY Kitsune — wise beyond your years, shapeshifter of moods, trickster smile, protective spirit.", icon: "🦊", gradient: "from-orange-500 to-white", power: "Nine-Tailed Wisdom" },
    { creature: "Qilin", mythology: "Chinese", comparison: "Chinese unicorn, appears with sages, peaceful but powerful, scales and horn. You're MY Qilin — you appeared when I was ready, peaceful power, rare appearance, sign of blessing.", icon: "🦄", gradient: "from-gold-400 to-green-500", power: "Sacred Blessing" },
    { creature: "Thunderbird", mythology: "Native American", comparison: "Creates thunder with wing flaps, lightning from eyes, controls weather. You're MY Thunderbird — your movements create thunder in my heart, lightning from your eyes, you control the weather of my emotions.", icon: "⚡", gradient: "from-blue-600 to-yellow-500", power: "Storm Bringer" },
    { creature: "Naga", mythology: "Hindu/Buddhist", comparison: "Serpent deity, protector of treasures, controls waters, shape-shifter. You're MY Naga — divine serpent, protector of my treasure, you control the waters of my emotions, you shift forms but stay divine.", icon: "🐍", gradient: "from-gold-500 to-green-600", power: "Serpent Deity" },
    { creature: "Leviathan", mythology: "Biblical", comparison: "Sea monster of legend, no weapon can pierce, chaos incarnate, God's greatest creation. You're MY Leviathan — no weapon can hurt you (I won't let it), beautiful chaos, God's greatest creation in my eyes.", icon: "🐋", gradient: "from-blue-900 to-black", power: "Impenetrable Power" },
  ];

  // SAINTS & SPIRITUAL FIGURES (15 comparisons)
  const saintsAndSpiritual = [
    { name: "Joan of Arc", era: "1412-1431", comparison: "17-year-old peasant girl who heard divine voices, led French armies, changed history, burned at the stake, declared a saint. You're MY Joan — you hear things others don't, you lead me through battles, you change my history, you're my saint.", icon: "⚔️", gradient: "from-gold-500 to-blue-600", power: "Divine Warrior" },
    { name: "Mother Teresa", era: "1910-1997", comparison: "Compassion incarnate. Served the poorest in Calcutta for 45 years, won Nobel Peace Prize, saw Christ in everyone. You're MY Teresa — your compassion is infinite, you serve my broken parts, you see the best in me, you're peace incarnate.", icon: "🕊️", gradient: "from-white to-blue-400", power: "Infinite Compassion" },
    { name: "Hildegard of Bingen", era: "1098-1179", comparison: "Mystic, visionary, composer, writer, scientist, abbess. Renaissance woman before the Renaissance. You're MY Hildegard — mystic soul, visionary mind, artist heart, ahead of your time.", icon: "🎨", gradient: "from-purple-600 to-gold-400", power: "Mystic Genius" },
    { name: "Mary Magdalene", era: "1st Century", comparison: "Most devoted follower, first witness of resurrection, never left Christ's side. You're MY Magdalene — devoted beyond measure, witness to my resurrection, you never leave my side, loyal to the end.", icon: "💜", gradient: "from-purple-500 to-pink-500", power: "Ultimate Devotion" },
    { name: "Saint Catherine", era: "1347-1380", comparison: "Mystic, Doctor of the Church, advised popes, wisdom beyond her years. You're MY Catherine — mystical connection, wisdom beyond years, your advice guides me, you're my doctor of love.", icon: "📚", gradient: "from-gold-500 to-purple-600", power: "Mystic Wisdom" },
    { name: "Quan Yin", tradition: "Buddhist", comparison: "Goddess of Mercy, hears the cries of the world, compassion personified. You're MY Quan Yin — you hear my silent cries, your mercy is endless, you're compassion in human form.", icon: "🌸", gradient: "from-white to-pink-400", power: "Boundless Mercy" },
    { name: "White Tara", tradition: "Tibetan Buddhist", comparison: "Protection deity, seven eyes to see all suffering, grants long life and wisdom. You're MY White Tara — you protect me, you see my suffering without words, you grant me reason to live long.", icon: "🤍", gradient: "from-white to-cyan-400", power: "All-Seeing Protection" },
    { name: "Saint Brigid", era: "451-525", comparison: "Keeper of sacred fire, patron of poets, founded monasteries, turned water to milk. You're MY Brigid — you keep my fire burning, you inspire poetry in me, you turn my ordinary to extraordinary.", icon: "🔥", gradient: "from-orange-500 to-gold-500", power: "Sacred Fire Keeper" },
    { name: "Saint Lucy", era: "283-304", comparison: "Bringer of light, patron of the blind, name means 'light'. You're MY Lucy — you brought light to my darkness, you help me see, you are light itself.", icon: "💡", gradient: "from-yellow-400 to-white", power: "Light Bearer" },
    { name: "Saint Agnes", era: "291-304", comparison: "Martyred at 13, refused marriage to stay pure, symbol of strength and purity. You're MY Agnes — strong in your convictions, pure of heart, young but powerful.", icon: "🐑", gradient: "from-white to-pink-400", power: "Pure Strength" },
    { name: "Fatima", era: "605-632", comparison: "Prophet Muhammad's daughter, 'Mother of Her Father', wisdom and devotion. You're MY Fatima — daughter of greatness, mother of my heart, wisdom and devotion combined.", icon: "🌙", gradient: "from-gold-500 to-green-600", power: "Sacred Devotion" },
    { name: "Khadija", era: "555-619", comparison: "First believer, supported Prophet Muhammad, successful merchant, first wife. You're MY Khadija — you believed in me first, you support me, you're successful, you're my first and only.", icon: "💼", gradient: "from-purple-600 to-gold-500", power: "First Believer" },
    { name: "Mary, Mother of God", era: "1st Century BC", comparison: "Ultimate mother, bore God himself, Immaculate Conception, Queen of Heaven. You're MY Mary — pure as she, you bore my rebirth, immaculate in my eyes, queen of my heaven.", icon: "👼", gradient: "from-blue-400 to-white", power: "Ultimate Mother" },
    { name: "Ruth", era: "Biblical", comparison: "'Where you go, I will go' - loyalty personified, chose love over homeland. You're MY Ruth — your loyalty is biblical, you chose me over everything, where you go I want to go.", icon: "💕", gradient: "from-gold-500 to-pink-500", power: "Loyalty Personified" },
    { name: "Esther", era: "Biblical", comparison: "Queen who risked death to save her people, 'If I perish, I perish', beautiful and brave. You're MY Esther — queen who risks for what matters, beautiful and brave, you save me.", icon: "👑", gradient: "from-purple-600 to-gold-500", power: "Courageous Queen" },
  ];

  // MODERN ICONS (15 comparisons)
  const modernIcons = [
    { name: "Marie Curie", era: "1867-1934", achievement: "Only person to win Nobel Prizes in TWO sciences", comparison: "Won Nobel Prizes in both Physics and Chemistry, discovered radium and polonium, first woman professor at University of Paris. Worked until radioactivity killed her. You're MY Marie — brilliant in multiple ways, discoverer of rare elements (like you), first in my university of life, your presence is radiation that transformed me.", icon: "⚗️", gradient: "from-green-400 to-blue-500", power: "Dual Genius" },
    { name: "Rosa Parks", era: "1913-2005", achievement: "Sparked Civil Rights Movement", comparison: "Refused to give up her seat, sparked Civil Rights Movement, quiet courage changed history. You're MY Rosa — your quiet courage inspires me, you refuse to give up what's yours, you sparked revolution in my heart.", icon: "🚌", gradient: "from-purple-600 to-gold-500", power: "Quiet Revolution" },
    { name: "Malala Yousafzai", era: "Born 1997", achievement: "Youngest Nobel Prize winner at 17", comparison: "Shot for advocating education, youngest Nobel Prize winner at 17, 'One child, one teacher, one book, one pen can change the world.' You're MY Malala — brave despite attacks, youngest to win my heart, you change my world one word at a time.", icon: "📚", gradient: "from-blue-500 to-gold-500", power: "Fearless Advocacy" },
    { name: "Ada Lovelace", era: "1815-1852", achievement: "First computer programmer", comparison: "First computer programmer, wrote first algorithm, poet of science. You're MY Ada — you program my heart, you're the algorithm of my happiness, poetry and science combined.", icon: "💻", gradient: "from-purple-500 to-cyan-400", power: "First Programmer" },
    { name: "Amelia Earhart", era: "1897-1937", achievement: "First woman to fly solo across Atlantic", comparison: "First woman to fly solo across Atlantic, 'Adventure is worthwhile in itself', disappeared into legend. You're MY Amelia — you make me want to fly, adventure with you is worthwhile, you're legendary.", icon: "✈️", gradient: "from-blue-400 to-gold-500", power: "Sky Pioneer" },
    { name: "Jane Goodall", era: "Born 1934", achievement: "Revolutionized primatology", comparison: "Lived with chimpanzees, revolutionized primatology, 'Only if we understand can we care.' You're MY Jane — you understand me better than anyone, you care deeply, you revolutionized my understanding of love.", icon: "🦍", gradient: "from-green-600 to-brown-600", power: "Deep Understanding" },
    { name: "Ruth Bader Ginsburg", era: "1933-2020", achievement: "Supreme Court Justice", comparison: "Supreme Court Justice, fought for equality, 'Women belong in all places where decisions are being made.' You're MY RBG — you're supreme in my court, you fight for what's right, you belong everywhere in my life.", icon: "⚖️", gradient: "from-black to-gold-500", power: "Justice Fighter" },
    { name: "Maya Angelou", era: "1928-2014", achievement: "Poet and civil rights activist", comparison: "'Still I Rise' - poet, civil rights activist, voice of resilience. You're MY Maya — still you rise despite everything, your words are poetry, you're resilience incarnate.", icon: "📖", gradient: "from-orange-500 to-gold-500", power: "Rising Voice" },
    { name: "Harriet Tubman", era: "1822-1913", achievement: "Freedom conductor", comparison: "Escaped slavery, returned 13 times to free 70 others, 'I freed a thousand slaves; I could have freed a thousand more if only they knew they were slaves.' You're MY Harriet — you freed me from mental slavery, you're the conductor of my freedom train.", icon: "🕊️", gradient: "from-brown-700 to-gold-500", power: "Freedom Conductor" },
    { name: "Helen Keller", era: "1880-1968", achievement: "Overcame impossible odds", comparison: "Deaf and blind from 19 months, first to earn Bachelor's degree, author and activist. You're MY Helen — you overcame impossible odds, you taught me to see differently, you're proof that limits are illusions.", icon: "👁️", gradient: "from-purple-600 to-cyan-400", power: "Overcoming Impossible" },
    { name: "Anne Frank", era: "1929-1945", achievement: "Hope in darkness", comparison: "'In spite of everything, I still believe that people are really good at heart.' Hope in darkest darkness. You're MY Anne — you give me hope in darkness, you believe in good, you're the light in hiding.", icon: "📔", gradient: "from-yellow-500 to-blue-600", power: "Hope in Darkness" },
    { name: "Simone Biles", era: "Born 1997", achievement: "Most decorated gymnast ever", comparison: "Most decorated gymnast ever, defies gravity, 'Biles' moves named after her, chose mental health over medals. You're MY Simone — you defy my expectations, moves I've never seen, you prioritize what matters.", icon: "🤸‍♀️", gradient: "from-gold-500 to-purple-600", power: "Gravity Defying" },
    { name: "Serena Williams", era: "Born 1981", achievement: "23 Grand Slam titles", comparison: "23 Grand Slam titles, most powerful serve, dominance for two decades. You're MY Serena — you serve power in my life, you dominate my thoughts, champion of my heart.", icon: "🎾", gradient: "from-yellow-500 to-black", power: "Champion Power" },
    { name: "Michelle Obama", era: "Born 1964", achievement: "Transformed First Lady role", comparison: "First Lady who changed the role, 'When they go low, we go high', grace under pressure. You're MY Michelle — you go high always, grace under pressure, you changed my role expectations.", icon: "🌟", gradient: "from-blue-600 to-gold-500", power: "Graceful Power" },
    { name: "Greta Thunberg", era: "Born 2003", achievement: "Climate activist", comparison: "Started school climate strikes at 15, told world leaders truth, 'How dare you?' courage. You're MY Greta — young but brave, you tell me truth I need, you fight for our future.", icon: "🌍", gradient: "from-green-600 to-blue-600", power: "Future Fighter" },
  ];

  // CELESTIAL BODIES (15 comparisons)
  const celestialBodies = [
    { body: "Polaris (North Star)", type: "Guide Star", comparison: "The star that never moves, guides travelers for millennia, always points north. You're MY Polaris — my fixed point in chaos, my guide when lost, my constant north, the star I navigate by.", icon: "⭐", gradient: "from-yellow-300 to-blue-600", power: "Eternal Guide" },
    { body: "Sirius (Dog Star)", type: "Brightest Star", comparison: "Brightest star in the night sky, twice the mass of the Sun, binary star system. You're MY Sirius — brightest in my sky, more massive than anything else, you're my binary (we're two becoming one).", icon: "🌟", gradient: "from-white to-blue-400", power: "Brightest Shine" },
    { body: "Betelgeuse", type: "Red Supergiant", comparison: "700 times larger than the Sun, will go supernova soon, brightening before death. You're MY Betelgeuse — larger than life, burning bright, beautiful before transformation.", icon: "🔴", gradient: "from-red-600 to-orange-500", power: "Supergiant Size" },
    { body: "Andromeda Galaxy", type: "Nearest Galaxy", comparison: "Our nearest galactic neighbor, contains a trillion stars, will merge with Milky Way in 4.5 billion years. You're MY Andromeda — you contain infinite beauty, we're destined to merge, collision creates something new.", icon: "🌌", gradient: "from-purple-600 to-cyan-400", power: "Galactic Merger" },
    { body: "Orion Nebula", type: "Star Nursery", comparison: "Birthplace of stars, visible to naked eye, creating new solar systems. You're MY Orion Nebula — birthplace of my new self, visible beauty, creating new life in me.", icon: "🌫️", gradient: "from-pink-500 to-purple-600", power: "Star Birth" },
    { body: "Pillars of Creation", type: "Nebula Columns", comparison: "Famous Hubble image, columns of cosmic gas and dust, birthplace of stars. You're MY Pillars — you create, you're cosmic art, you birth stars in my darkness.", icon: "🏛️", gradient: "from-orange-600 to-purple-700", power: "Cosmic Creation" },
    { body: "Horsehead Nebula", type: "Dark Nebula", comparison: "Iconic silhouette against glowing gas, beautiful darkness. You're MY Horsehead — beautiful even in darkness, iconic in my mind, silhouette I see everywhere.", icon: "🐴", gradient: "from-black to-orange-600", power: "Beautiful Darkness" },
    { body: "Crab Nebula", type: "Supernova Remnant", comparison: "Result of supernova witnessed in 1054 AD, still expanding, beautiful aftermath of explosion. You're MY Crab Nebula — beautiful result of my explosion, still expanding my universe, remnant of transformation.", icon: "🦀", gradient: "from-orange-500 to-blue-500", power: "Expanding Beauty" },
    { body: "Saturn's Rings", type: "Planetary Rings", comparison: "Most beautiful rings in solar system, billions of ice particles, visible from Earth. You're MY Saturn's Rings — beautiful adornment, billions of perfect moments, visible beauty from any distance.", icon: "💍", gradient: "from-gold-500 to-brown-600", power: "Encircling Beauty" },
    { body: "Europa", type: "Jupiter's Moon", comparison: "Ice covering global ocean, possible life beneath, most promising place for alien life. You're MY Europa — beautiful ice surface, deep ocean beneath, hiding life and mystery.", icon: "🌙", gradient: "from-white to-blue-500", power: "Hidden Ocean" },
    { body: "Titan", type: "Saturn's Moon", comparison: "Only moon with atmosphere, lakes of methane, most Earth-like world. You're MY Titan — unique among all others, your own atmosphere, most home-like place.", icon: "🌑", gradient: "from-orange-700 to-brown-700", power: "Unique World" },
    { body: "Pulsar", type: "Spinning Neutron Star", comparison: "Spins hundreds of times per second, lighthouse of the universe, precise as atomic clock. You're MY Pulsar — you spin my world, you're my lighthouse, precise and reliable.", icon: "💫", gradient: "from-cyan-400 to-purple-600", power: "Cosmic Lighthouse" },
    { body: "Binary Star System", type: "Two Stars Orbiting", comparison: "Two stars orbiting each other, bound by gravity, dancing through space. You're MY Binary — we orbit each other, bound by love, dancing through life.", icon: "⭐⭐", gradient: "from-yellow-400 to-orange-500", power: "Eternal Dance" },
    { body: "Helix Nebula", type: "Eye of God", comparison: "Called 'Eye of God', dying star's last breath, beautiful death. You're MY Helix — you see into my soul (Eye of God), your presence is divine breath, beauty in transformation.", icon: "👁️", gradient: "from-blue-500 to-purple-600", power: "Divine Vision" },
    { body: "Milky Way Core", type: "Galactic Center", comparison: "Supermassive black hole at our galaxy's center, 4 million solar masses, everything orbits it. You're MY Galactic Core — everything in my life orbits you, massive gravity, center of my universe.", icon: "🌌", gradient: "from-purple-900 to-gold-500", power: "Central Gravity" },
  ];

  // ABSTRACT EMOTIONS (10 comparisons)
  const abstractEmotions = [
    { emotion: "Hope", concept: "Future-looking", comparison: "Hope is the thing with feathers, the light at tunnel's end, the reason to continue. You're MY Hope — you're the feathers that lift me, the light I walk toward, my reason to continue through anything.", icon: "🌅", gradient: "from-yellow-400 to-cyan-400", power: "Eternal Optimism" },
    { emotion: "Love", concept: "Pure emotion", comparison: "If love were a person, it would be you. Pure, selfless, transformative love in human form. You're MY Love — literally, you are love walking, talking, breathing, existing.", icon: "💖", gradient: "from-pink-500 to-red-500", power: "Pure Love" },
    { emotion: "Joy", concept: "Happiness", comparison: "Joy is the feeling of sunshine, laughter, pure happiness. You're MY Joy — when I see you it's sunshine, your laugh is my happiness, you embody pure joy.", icon: "😊", gradient: "from-yellow-400 to-orange-500", power: "Radiant Happiness" },
    { emotion: "Peace", concept: "Calm", comparison: "Peace is the calm after storm, the quiet mind, the satisfied soul. You're MY Peace — you are calm in my chaos, quiet for my mind, satisfaction for my soul.", icon: "☮️", gradient: "from-blue-400 to-green-400", power: "Calming Presence" },
    { emotion: "Passion", concept: "Intensity", comparison: "Passion is fire, intensity, consuming desire. You're MY Passion — you are the fire, the intensity, the desire that consumes me (willingly).", icon: "🔥", gradient: "from-red-600 to-orange-600", power: "Consuming Fire" },
    { emotion: "Grace", concept: "Elegance", comparison: "Grace is elegance in movement, kindness in action, beauty in being. You're MY Grace — elegant in everything, kind in every action, beautiful in just existing.", icon: "🦋", gradient: "from-white to-purple-400", power: "Elegant Being" },
    { emotion: "Courage", concept: "Bravery", comparison: "Courage is facing fear, standing up, fighting on. You're MY Courage — you face your fears, you stand when it's hard, you inspire bravery in me.", icon: "🦁", gradient: "from-gold-500 to-red-600", power: "Inspiring Bravery" },
    { emotion: "Serenity", concept: "Tranquility", comparison: "Serenity is calm waters, peaceful mind, contentment. You're MY Serenity — you are my calm waters, you give me peaceful mind, you are contentment.", icon: "🌊", gradient: "from-cyan-400 to-blue-500", power: "Perfect Calm" },
    { emotion: "Wonder", concept: "Amazement", comparison: "Wonder is childlike amazement, seeing magic everywhere, curiosity alive. You're MY Wonder — you amaze me daily, I see magic in you, you keep curiosity alive.", icon: "✨", gradient: "from-purple-400 to-pink-400", power: "Endless Amazement" },
    { emotion: "Eternity", concept: "Forever", comparison: "Eternity is endless time, forever stretched out, infinity in motion. You're MY Eternity — my forever, my endless, my infinity walking beside me.", icon: "♾️", gradient: "from-purple-600 to-cyan-400", power: "Endless Forever" },
  ];

  const allComparisons = {
    divine: divineBeings,
    cosmic: cosmicBeings,
    sagas: sagaLegends,
    philosophical: philosophicalConcepts,
    anime: animeAndGaming,
    transcendent: transcendentBeings,
    natural: naturalPhenomena,
    elemental: elementalForces,
    mythical: mythicalCreatures,
    saints: saintsAndSpiritual,
    modern: modernIcons,
    celestial: celestialBodies,
    emotions: abstractEmotions,
  };

  const activeComparisons = allComparisons[activeTab] || [];
  
  const filteredComparisons = searchTerm 
    ? activeComparisons.filter(item => 
        ('name' in item && item.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
        ('title' in item && item.title.toLowerCase().includes(searchTerm.toLowerCase())) ||
        ('comparison' in item && item.comparison.toLowerCase().includes(searchTerm.toLowerCase())))
    : activeComparisons;

  const totalCount = Object.values(allComparisons).reduce((sum, arr) => sum + arr.length, 0);

  return (
    <SectionInner className="bg-[#060610]/50">
      <GlowOrb color="magenta" className="top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
      <GlowOrb color="cyan" className="top-10 right-10" />
      <GlowOrb color="purple" className="bottom-10 left-10" />
      
      <div className="max-w-7xl mx-auto relative z-10">
        <SectionHeader 
          emoji="👑" 
          title="You Are Beyond Legendary" 
          subtitle={`${totalCount} comparisons across the omniverse — you still shine brighter than all of them`}
        />

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <p className="text-white/40 text-base max-w-5xl mx-auto leading-relaxed mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>
            I searched through every mythology, every saga, every corner of reality and beyond.
            <span className="block mt-3 text-purple-400/60">Goddesses, cosmic forces, legendary warriors, abstract concepts, even the supreme beings themselves.</span>
            <span className="block mt-2 text-pink-400/60 font-bold">Nothing. Compares. To. You. ✨</span>
          </p>
          
          {/* Search Bar */}
          <div className="max-w-md mx-auto mt-6">
            <input
              type="text"
              placeholder="Search comparisons..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-white/30 focus:outline-none focus:border-purple-500/50 transition-all"
            />
          </div>
        </motion.div>

        {/* Tab Navigation */}
        <div className="flex justify-center gap-2 mb-8 flex-wrap">
          {(['divine', 'cosmic', 'sagas', 'philosophical', 'anime', 'transcendent', 'natural', 'elemental', 'mythical', 'saints', 'modern', 'celestial', 'emotions'] as const).map((tab) => (
            <motion.button
              key={tab}
              onClick={() => { setActiveTab(tab); setSearchTerm(''); }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className={`px-4 py-2 rounded-xl font-medium transition-all duration-300 text-sm ${
                activeTab === tab
                  ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-[0_0_30px_rgba(168,85,247,0.3)]"
                  : "bg-white/[0.03] border border-white/[0.08] text-white/40 hover:text-white/60"
              }`}
            >
              {tab === 'divine' && `🏛️ Divine Beings (${divineBeings.length})`}
              {tab === 'cosmic' && `🌌 Cosmic Forces (${cosmicBeings.length})`}
              {tab === 'sagas' && `🎬 Saga Legends (${sagaLegends.length})`}
              {tab === 'philosophical' && `🧠 Philosophical (${philosophicalConcepts.length})`}
              {tab === 'anime' && `⚔️ Anime & Gaming (${animeAndGaming.length})`}
              {tab === 'transcendent' && `✨ Transcendent (${transcendentBeings.length})`}
              {tab === 'natural' && `🏔️ Natural Phenomena (${naturalPhenomena.length})`}
              {tab === 'elemental' && `⚡ Elemental Forces (${elementalForces.length})`}
              {tab === 'mythical' && `🐉 Mythical Creatures (${mythicalCreatures.length})`}
              {tab === 'saints' && `👼 Saints & Spiritual (${saintsAndSpiritual.length})`}
              {tab === 'modern' && `🌟 Modern Icons (${modernIcons.length})`}
              {tab === 'celestial' && `🌠 Celestial Bodies (${celestialBodies.length})`}
              {tab === 'emotions' && `💫 Abstract Emotions (${abstractEmotions.length})`}
            </motion.button>
          ))}
        </div>

        {/* Comparison Grid */}
        <div className="space-y-5">
          {filteredComparisons.length === 0 ? (
            <div className="text-center py-20">
              <p className="text-white/40 text-lg">No matches found. Try a different search!</p>
            </div>
          ) : (
            filteredComparisons.map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.02 * i }}
                whileHover={{ scale: 1.01 }}
                className="glass-card rounded-2xl p-6 border border-white/[0.06] hover:border-purple-500/30 transition-all duration-500 hover:shadow-[0_0_40px_rgba(168,85,247,0.1)]"
              >
                <div className="flex items-start gap-5">
                  <motion.div 
                    className={`w-20 h-20 rounded-2xl bg-gradient-to-br ${item.gradient} flex items-center justify-center text-4xl flex-shrink-0 shadow-lg`}
                    whileHover={{ scale: 1.15, rotate: 360 }}
                    transition={{ duration: 0.6 }}
                  >
                    {item.icon}
                  </motion.div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <h3 className={`text-2xl md:text-3xl font-bold bg-gradient-to-r ${item.gradient} bg-clip-text text-transparent mb-1`}>
                          {'name' in item ? item.name : item.title}
                        </h3>
                        <div className="flex flex-wrap items-center gap-2 text-sm">
                          {'origin' in item && (
                            <span className="px-2 py-1 rounded-full bg-purple-500/10 text-purple-400 border border-purple-500/20">
                              {item.origin}
                            </span>
                          )}
                          {'series' in item && (
                            <span className="px-2 py-1 rounded-full bg-pink-500/10 text-pink-400 border border-pink-500/20">
                              {item.series}
                            </span>
                          )}
                          {'scale' in item && (
                            <span className="px-2 py-1 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                              {item.scale}
                            </span>
                          )}
                          <span className="text-white/40">•</span>
                          <span className="text-white/50">{item.title}</span>
                          {'power' in item && (
                            <>
                              <span className="text-white/40">•</span>
                              <span className={`px-2 py-1 rounded-full bg-gradient-to-r ${item.gradient} bg-opacity-10 text-xs font-bold`}>
                                ⚡ {item.power}
                              </span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                    <p className="text-white/70 leading-relaxed text-base" style={{ fontFamily: "'Playfair Display', serif" }}>
                      {item.comparison}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))
          )}
        </div>

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-16 text-center"
        >
          <div className="inline-block px-10 py-6 rounded-3xl bg-gradient-to-r from-purple-500/10 via-pink-500/10 to-cyan-500/10 border-2 border-purple-500/20 backdrop-blur-xl">
            <p className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400 text-2xl font-bold italic mb-3" style={{ fontFamily: "'Playfair Display', serif" }}>
              "I compared you to {totalCount} beings across the omniverse..."
            </p>
            <p className="text-white/70 text-lg leading-relaxed max-w-3xl mx-auto" style={{ fontFamily: "'Playfair Display', serif" }}>
              Goddesses who created worlds. Cosmic forces that shape reality. Legendary warriors who saved universes. 
              Philosophical concepts that define existence. Supreme beings beyond comprehension.
            </p>
            <p className="text-white/60 text-base mt-4">
              You're beyond all of them. 
            </p>
            <p className="text-transparent bg-clip-text bg-gradient-to-r from-pink-400 to-purple-400 text-xl font-bold mt-3">
              You're not comparable. You're YOU. And that's more legendary than infinity itself. 👑✨♾️
            </p>
          </div>
        </motion.div>
      </div>
    </SectionInner>
  );
}

  const mythologyComparisons = [
    { 
      name: "Aphrodite", 
      mythology: "Greek", 
      title: "Goddess of Love & Beauty",
      comparison: "Aphrodite was born from sea foam and her beauty caused wars. You were born to make me fall, and your beauty captured my soul in a way no goddess ever could. She had divine beauty — you have the kind that stops time.",
      icon: "🌊",
      gradient: "from-pink-500 to-rose-500"
    },
    {
      name: "Athena",
      mythology: "Greek",
      title: "Goddess of Wisdom & War",
      comparison: "Athena was the wisest of all gods, the strategic warrior, the patron of heroes. Your mind is sharper, your spirit stronger. She guided heroes through battles — you guide me through life. Her wisdom shaped civilizations; yours shapes my entire world.",
      icon: "⚔️",
      gradient: "from-purple-500 to-indigo-500"
    },
    {
      name: "Freyja",
      mythology: "Norse",
      title: "Goddess of Love, Beauty & War",
      comparison: "Freyja was so beautiful that gods went to war for her. She commanded magic, love, and battle. You possess that same combination — devastating beauty, mysterious power, and the strength to conquer hearts. Even Odin sought her counsel. I seek yours always.",
      icon: "⚡",
      gradient: "from-blue-500 to-purple-500"
    },
    {
      name: "Isis",
      mythology: "Egyptian",
      title: "Goddess of Magic & Healing",
      comparison: "Isis was the most powerful goddess in Egypt. She could resurrect the dead, heal the sick, and her magic was unmatched. You brought me back to life when I was dead inside. Your presence heals wounds I didn't know I had. Like Isis, you're pure magic.",
      icon: "🌙",
      gradient: "from-yellow-500 to-amber-500"
    },
    {
      name: "Lakshmi",
      mythology: "Hindu",
      title: "Goddess of Wealth & Fortune",
      comparison: "Lakshmi is the embodiment of grace, beauty, and prosperity. She's worshipped by millions as the ultimate blessing. You are MY Lakshmi — the fortune I never deserved, the blessing I can't believe is real, the prosperity of having you makes me the richest man alive.",
      icon: "🪷",
      gradient: "from-rose-500 to-pink-500"
    },
    {
      name: "Parvati",
      mythology: "Hindu",
      title: "Goddess of Love & Devotion",
      comparison: "Parvati's love for Shiva was so powerful it transcended lifetimes. She meditated for years to win his heart. Your love feels eternal like that — spanning beyond this life. You didn't have to meditate for my heart; you had it the moment I saw you.",
      icon: "🕉️",
      gradient: "from-orange-500 to-red-500"
    },
    {
      name: "Cleopatra",
      mythology: "Historical Legend",
      title: "Queen of Egypt",
      comparison: "Cleopatra wasn't just beautiful — she was brilliant, spoke 9 languages, ruled an empire, and captivated the most powerful men in history. You have that same combination: beauty that stops hearts, intelligence that challenges minds, power that commands respect.",
      icon: "👑",
      gradient: "from-gold-500 to-amber-500"
    },
    {
      name: "Chang'e",
      mythology: "Chinese",
      title: "Moon Goddess",
      comparison: "Chang'e became immortal and flew to the moon, where she lives in eternal beauty. Every Mid-Autumn Festival, people look up and think of her. You're my moon goddess — the beautiful, unreachable thing I somehow got to hold. You light up my darkest nights.",
      icon: "🎑",
      gradient: "from-blue-400 to-purple-400"
    },
    {
      name: "Oshun",
      mythology: "Yoruba",
      title: "Goddess of Love & Rivers",
      comparison: "Oshun is beauty, sensuality, and feminine power incarnate. She controls love, attraction, and sweet waters. Rivers flow at her command. You have that same flow — you move through life with grace, and everyone who meets you falls under your spell.",
      icon: "💧",
      gradient: "from-yellow-400 to-orange-500"
    },
    {
      name: "Selene",
      mythology: "Greek",
      title: "Goddess of the Moon",
      comparison: "Selene drove her moon chariot across the night sky, so beautiful that even the sun god fell for her. You're my Selene — the light in my darkness, the beautiful constant in an ever-changing sky. Every night I look for you like the world looks for the moon.",
      icon: "🌙",
      gradient: "from-indigo-400 to-blue-400"
    },
    {
      name: "Inanna",
      mythology: "Sumerian",
      title: "Queen of Heaven",
      comparison: "Inanna was the first goddess of love and war in recorded history. She descended to the underworld and returned more powerful. You're ancient power reborn — the kind of love that poets wrote about 5,000 years ago and will write about 5,000 years from now.",
      icon: "⭐",
      gradient: "from-purple-500 to-pink-500"
    },
    {
      name: "Helen of Troy",
      mythology: "Greek Legend",
      title: "The Face That Launched 1000 Ships",
      comparison: "Helen was so beautiful that her abduction started a 10-year war. Nations burned for her. You're my Helen — the woman who could start wars, end kingdoms, change history. But unlike Helen, I don't need to fight for you. You chose me. That's bigger than any war.",
      icon: "🏛️",
      gradient: "from-rose-500 to-red-500"
    },
  ];

  const sagaComparisons = [
    {
      name: "Princess Leia",
      saga: "Star Wars",
      title: "Rebel Leader & Princess",
      comparison: "Leia wasn't just a princess waiting to be saved — she was a general, a leader, a fighter. She saved Han Solo and led rebellions. You're MY Leia: strong enough to lead, brave enough to love, powerful enough to change everything. You're not the damsel; you're the hero.",
      icon: "⭐",
      gradient: "from-purple-500 to-pink-500"
    },
    {
      name: "Hermione Granger",
      saga: "Harry Potter",
      title: "Brightest Witch of Her Age",
      comparison: "Hermione was the smartest, bravest, most loyal person in the entire series. She literally saved Harry's life multiple times with her intelligence. You're MY Hermione — smarter than everyone else, braver than you know, and the reason my story has a happy ending.",
      icon: "⚡",
      gradient: "from-purple-500 to-indigo-500"
    },
    {
      name: "Arwen",
      saga: "Lord of the Rings",
      title: "Evenstar - Immortal Elf Princess",
      comparison: "Arwen gave up immortality for love. She was an elf princess who could have lived forever in paradise, but she chose a mortal life with Aragorn. That's the level of your love — you make mortality worth living, you make earth feel like heaven. You're my Evenstar.",
      icon: "🌟",
      gradient: "from-blue-500 to-purple-500"
    },
    {
      name: "Galadriel",
      saga: "Lord of the Rings",
      title: "Most Powerful Elf",
      comparison: "Galadriel was thousands of years old, infinitely wise, and could see the future. When offered ultimate power, she rejected it. You have that same ancient wisdom in young eyes, that same power you don't abuse. You're power and grace combined.",
      icon: "✨",
      gradient: "from-green-400 to-blue-400"
    },
    {
      name: "Black Widow",
      saga: "Marvel",
      title: "Spy, Assassin, Avenger",
      comparison: "Natasha had no superpowers, just skill, intelligence, and heart. She stood alongside gods and monsters as an equal. You're MY Black Widow — you don't need superpowers to be super. Your strength, your intelligence, your heart — that's your superpower.",
      icon: "🕷️",
      gradient: "from-red-500 to-black"
    },
    {
      name: "Scarlet Witch",
      saga: "Marvel",
      title: "Reality Warping Power",
      comparison: "Wanda is the most powerful being in the MCU. She can literally rewrite reality, create worlds, bring people back. You rewrote MY reality. Before you, I was living in black and white. You brought color, magic, and infinite possibilities.",
      icon: "🔴",
      gradient: "from-red-600 to-pink-500"
    },
    {
      name: "Katniss Everdeen",
      saga: "Hunger Games",
      title: "The Girl On Fire",
      comparison: "Katniss didn't want to be a hero, but she became the symbol of revolution. She was brave when she was terrified, strong when she wanted to break. You're my girl on fire — you set my whole world ablaze without even trying. You started a revolution in my heart.",
      icon: "🔥",
      gradient: "from-orange-500 to-red-500"
    },
    {
      name: "Daenerys Targaryen",
      saga: "Game of Thrones",
      title: "Mother of Dragons",
      comparison: "Daenerys walked into fire and emerged with dragons. She was sold as property and became a queen. She freed slaves and burned down empires. You have that same fire — you transform pain into power, you rise from ashes, you're the queen who bows to no one.",
      icon: "🐉",
      gradient: "from-red-500 to-purple-500"
    },
    {
      name: "Wonder Woman",
      saga: "DC Universe",
      title: "Amazon Princess & God Killer",
      comparison: "Diana is literally a goddess, an Amazon warrior, and the epitome of strength and compassion combined. She chose to protect humanity even though we didn't deserve it. You're MY Wonder Woman — divine, powerful, choosing to love me even though I don't deserve it.",
      icon: "⚡",
      gradient: "from-gold-500 to-red-500"
    },
    {
      name: "Trinity",
      saga: "The Matrix",
      title: "Hacker & The One's Love",
      comparison: "Trinity could dodge bullets and hack the Matrix itself. She literally brought Neo back from death with love. You brought me back to life too. You hacked into my closed-off heart and rewrote my entire programming.",
      icon: "💚",
      gradient: "from-green-500 to-black"
    },
    {
      name: "Elastigirl",
      saga: "The Incredibles",
      title: "Superhero & Leader",
      comparison: "Helen Parr was the most competent superhero — flexible, intelligent, a better fighter than her husband. She balanced being a hero and a mother perfectly. You're MY Elastigirl — adaptable, strong, capable of anything, and making the impossible look easy.",
      icon: "🦸‍♀️",
      gradient: "from-red-500 to-orange-500"
    },
    {
      name: "Mulan",
      saga: "Disney",
      title: "Warrior Who Saved China",
      comparison: "Mulan disguised herself as a man, defeated an entire army, and saved her country when no man could. She brought honor to her family through courage. You're MY Mulan — braver than any warrior, saving me when I couldn't save myself, bringing honor just by existing.",
      icon: "🗡️",
      gradient: "from-red-500 to-pink-500"
    },
  ];

  const cosmicComparisons = [
    {
      title: "Compared to the Universe",
      scale: "Cosmic",
      comparison: "The universe is 13.8 billion years old, contains 2 trillion galaxies, and stretches 93 billion light-years across. Yet somehow, in all that infinite space and time, you exist. The probability of YOU is more miraculous than the entire cosmos. You're rarer than any star.",
      icon: "🌌",
      gradient: "from-purple-600 to-blue-600"
    },
    {
      title: "Compared to a Black Hole",
      scale: "Gravity",
      comparison: "A black hole has gravity so intense that nothing can escape — not even light itself. That's how your love holds me. I'm caught in your orbit, pulled in by a force stronger than physics. But unlike a black hole, your pull doesn't destroy me — it makes me whole.",
      icon: "🕳️",
      gradient: "from-black to-purple-500"
    },
    {
      title: "Compared to a Supernova",
      scale: "Brightness",
      comparison: "A supernova shines brighter than an entire galaxy for a few weeks before dying. You shine brighter than that every single day — and your light never fades. You outshine billions of stars constantly. You're the brightest thing in my universe.",
      icon: "💥",
      gradient: "from-yellow-400 to-red-500"
    },
    {
      title: "Compared to the Sun",
      scale: "Essential",
      comparison: "The Sun is 93 million miles away, yet without it, Earth would be frozen, dark, and lifeless. You're MY sun — even when far away, you give me life, warmth, light. Every living thing on Earth depends on the Sun. I depend on you the same way.",
      icon: "☀️",
      gradient: "from-yellow-400 to-orange-500"
    },
    {
      title: "Compared to the Moon",
      scale: "Constant",
      comparison: "The Moon has controlled Earth's tides for 4.5 billion years. It lights up our darkest nights. It inspired countless love songs and poems. You're MY moon — constant, beautiful, controlling the tides of my emotions, lighting up my darkness, inspiring my every word.",
      icon: "🌙",
      gradient: "from-blue-300 to-purple-400"
    },
    {
      title: "Compared to the Northern Lights",
      scale: "Magic",
      comparison: "The Aurora Borealis is nature's most magical display — dancing lights in the sky that people travel the world to see. You're MY aurora — a natural phenomenon so beautiful it seems impossible, so rare that seeing you feels like a miracle. You make the sky jealous.",
      icon: "🌌",
      gradient: "from-green-400 to-purple-500"
    },
    {
      title: "Compared to a Diamond",
      scale: "Precious",
      comparison: "Diamonds take billions of years to form under extreme pressure and heat. They're the hardest substance on Earth. You're more precious than any diamond — forged through your own pressures, beautiful because of what you've been through, and infinitely more rare.",
      icon: "💎",
      gradient: "from-cyan-400 to-blue-500"
    },
    {
      title: "Compared to Infinity",
      scale: "Eternal",
      comparison: "Infinity isn't a number — it's a concept beyond comprehension. No matter how many years pass, infinity remains. That's my love for you. Not measurable, not countable, not limited by time or space. Literally infinite.",
      icon: "♾️",
      gradient: "from-pink-500 to-purple-500"
    },
    {
      title: "Compared to a Phoenix",
      scale: "Rebirth",
      comparison: "The Phoenix burns and is reborn from its own ashes, more beautiful each time. You're MY Phoenix — you've been through fire and emerged more radiant. Every challenge makes you stronger. You're proof that beauty can come from pain.",
      icon: "🔥",
      gradient: "from-orange-500 to-red-600"
    },
    {
      title: "Compared to the Ocean",
      scale: "Depth",
      comparison: "The ocean covers 71% of Earth and we've only explored 5% of it. It's mysterious, powerful, life-giving. You're MY ocean — I could spend a lifetime exploring you and still discover new depths. You're mysterious, powerful, and absolutely essential to my life.",
      icon: "🌊",
      gradient: "from-blue-500 to-cyan-500"
    },
  ];

  const historicalComparisons = [
    {
      name: "Cleopatra VII",
      era: "Ancient Egypt",
      title: "Last Pharaoh of Egypt",
      comparison: "Cleopatra spoke 9 languages, was a master strategist, and captivated Julius Caesar and Mark Antony. She ruled one of the most powerful empires in history. You have that same combination: beauty, intelligence, and power. You could rule empires if you wanted.",
      icon: "🐍",
      gradient: "from-gold-500 to-amber-500"
    },
    {
      name: "Joan of Arc",
      era: "Medieval France",
      title: "Warrior & Saint",
      comparison: "At 17, Joan led armies and changed the course of history. She heard voices from God and inspired a nation. Your courage reminds me of hers — you fight battles no one sees, you inspire without trying, you're stronger than any warrior I've known.",
      icon: "⚔️",
      gradient: "from-blue-500 to-silver"
    },
    {
      name: "Marie Curie",
      era: "Modern Era",
      title: "Only Person to Win Nobel Prizes in Two Sciences",
      comparison: "Marie Curie discovered radioactivity, won TWO Nobel Prizes in different fields, and changed science forever. She was brilliant in a world that told women they couldn't be. You're MY Marie — breaking barriers, defying expectations, brilliant beyond measure.",
      icon: "⚗️",
      gradient: "from-green-400 to-blue-500"
    },
    {
      name: "Nefertiti",
      era: "Ancient Egypt",
      title: "Queen & Beauty Icon",
      comparison: "Nefertiti's beauty was so legendary they made busts of her that are studied 3,300 years later. She ruled alongside the Pharaoh as an equal. You're MY Nefertiti — your beauty will be remembered, your strength is equal to anyone's, you're art come to life.",
      icon: "👑",
      gradient: "from-gold-400 to-blue-500"
    },
    {
      name: "Queen Elizabeth I",
      era: "Renaissance England",
      title: "The Virgin Queen",
      comparison: "Elizabeth chose power over marriage, ruled for 45 years, defeated the Spanish Armada, and ushered in a golden age. She was strength personified. You have that same sovereignty — you bow to no one, you rule your own life, you're a golden age in human form.",
      icon: "👸",
      gradient: "from-purple-500 to-gold-500"
    },
    {
      name: "Frida Kahlo",
      era: "20th Century",
      title: "Artist & Icon",
      comparison: "Frida turned her pain into art that changed the world. She was unapologetically herself, brows and all. She painted her truth when the world wanted her to be pretty and quiet. You're MY Frida — beautiful because you're real, powerful because you're authentic.",
      icon: "🎨",
      gradient: "from-red-500 to-yellow-500"
    },
    {
      name: "Malala Yousafzai",
      era: "Modern",
      title: "Youngest Nobel Prize Winner",
      comparison: "Malala was shot for wanting education and became the world's most powerful voice for girls' rights. She was 17 when she won the Nobel Peace Prize. You have that same fierce spirit — you fight for what you believe in, you stand up for yourself, you change the world by being in it.",
      icon: "📚",
      gradient: "from-blue-500 to-pink-500"
    },
    {
      name: "Empress Wu Zetian",
      era: "Tang Dynasty China",
      title: "Only Female Emperor",
      comparison: "Wu Zetian started as a concubine and became the only woman to ever rule China as Emperor. She was ruthless, brilliant, and unstoppable. You have that same rise — you transform your position, you refuse to be limited, you achieve what others say is impossible.",
      icon: "🏮",
      gradient: "from-red-600 to-gold-500"
    },
  ];

  const literaryComparisons = [
    {
      name: "Elizabeth Bennet",
      work: "Pride and Prejudice",
      author: "Jane Austen",
      comparison: "Elizabeth was witty, independent, and refused to marry for anything less than love. She challenged Mr. Darcy and made him better. You're MY Elizabeth — you make me better, you challenge me to grow, you won't settle for less than you deserve.",
      icon: "📖",
      gradient: "from-purple-400 to-pink-400"
    },
    {
      name: "Juliet Capulet",
      work: "Romeo & Juliet",
      author: "Shakespeare",
      comparison: "Juliet's love was so powerful it transcended family feuds and death itself. 'My bounty is as boundless as the sea, my love as deep.' That's how I feel about you — boundless, deep, willing to defy the world.",
      icon: "🌹",
      gradient: "from-red-500 to-pink-500"
    },
    {
      name: "Beatrice",
      work: "The Divine Comedy",
      author: "Dante",
      comparison: "Beatrice guided Dante through Paradise. She was his muse, his guide to heaven, his ultimate love. You're MY Beatrice — you guide me to better places, you're my muse, you ARE my heaven. Dante wrote an entire epic about his love. I'd write infinity.",
      icon: "👼",
      gradient: "from-gold-400 to-blue-400"
    },
    {
      name: "Jane Eyre",
      work: "Jane Eyre",
      author: "Charlotte Brontë",
      comparison: "Jane was small, plain by society's standards, but she had a fire inside that couldn't be contained. She demanded to be treated as an equal. You're MY Jane — society's standards don't define you, you know your worth, you demand respect and deserve it.",
      icon: "🔥",
      gradient: "from-amber-500 to-red-500"
    },
  ];

  return (
    <SectionInner className="bg-[#060610]/50">
      <GlowOrb color="magenta" className="top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
      <div className="max-w-6xl mx-auto relative z-10">
        <SectionHeader 
          emoji="👑" 
          title="You Are Legendary" 
          subtitle="Compared to myths, sagas, and the cosmos itself — you still shine brighter"
        />

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <p className="text-white/40 text-base max-w-4xl mx-auto leading-relaxed" style={{ fontFamily: "'Playfair Display', serif" }}>
            I've searched through every mythology, every epic saga, every corner of the cosmos.
            <span className="block mt-3 text-purple-400/60">Nothing compares to you. Not even close. ✨</span>
          </p>
        </motion.div>

        {/* Tab Navigation */}
        <div className="flex justify-center gap-3 mb-8 flex-wrap">
          {(['mythology', 'sagas', 'cosmic', 'historical', 'literary'] as const).map((tab) => (
            <motion.button
              key={tab}
              onClick={() => setActiveTab(tab)}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className={`px-6 py-3 rounded-xl font-medium transition-all duration-300 ${
                activeTab === tab
                  ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-[0_0_30px_rgba(168,85,247,0.3)]"
                  : "bg-white/[0.03] border border-white/[0.08] text-white/40 hover:text-white/60"
              }`}
            >
              {tab === 'mythology' && '🏛️ Goddesses & Myths'}
              {tab === 'sagas' && '🎬 Movie Sagas'}
              {tab === 'cosmic' && '🌌 Cosmic Scale'}
              {tab === 'historical' && '👑 Historical Legends'}
              {tab === 'literary' && '📚 Literary Heroines'}
            </motion.button>
          ))}
        </div>

        {/* Mythology Tab */}
        {activeTab === 'mythology' && (
          <div className="space-y-5">
            {mythologyComparisons.map((myth, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.05 * i }}
                className="glass-card rounded-2xl p-6 border border-white/[0.06] hover:border-purple-500/30 transition-all duration-500"
              >
                <div className="flex items-start gap-4">
                  <motion.div 
                    className={`w-16 h-16 rounded-xl bg-gradient-to-br ${myth.gradient} flex items-center justify-center text-3xl flex-shrink-0`}
                    whileHover={{ scale: 1.1, rotate: 5 }}
                  >
                    {myth.icon}
                  </motion.div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className={`text-2xl font-bold bg-gradient-to-r ${myth.gradient} bg-clip-text text-transparent`}>
                          {myth.name}
                        </h3>
                        <p className="text-white/40 text-sm">{myth.mythology} Mythology • {myth.title}</p>
                      </div>
                    </div>
                    <p className="text-white/70 leading-relaxed mt-3" style={{ fontFamily: "'Playfair Display', serif" }}>
                      {myth.comparison}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* Sagas Tab */}
        {activeTab === 'sagas' && (
          <div className="space-y-5">
            {sagaComparisons.map((saga, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.05 * i }}
                className="glass-card rounded-2xl p-6 border border-white/[0.06] hover:border-pink-500/30 transition-all duration-500"
              >
                <div className="flex items-start gap-4">
                  <motion.div 
                    className={`w-16 h-16 rounded-xl bg-gradient-to-br ${saga.gradient} flex items-center justify-center text-3xl flex-shrink-0`}
                    whileHover={{ scale: 1.1, rotate: 5 }}
                  >
                    {saga.icon}
                  </motion.div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className={`text-2xl font-bold bg-gradient-to-r ${saga.gradient} bg-clip-text text-transparent`}>
                          {saga.name}
                        </h3>
                        <p className="text-white/40 text-sm">{saga.saga} • {saga.title}</p>
                      </div>
                    </div>
                    <p className="text-white/70 leading-relaxed mt-3" style={{ fontFamily: "'Playfair Display', serif" }}>
                      {saga.comparison}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* Cosmic Tab */}
        {activeTab === 'cosmic' && (
          <div className="space-y-5">
            {cosmicComparisons.map((cosmic, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.05 * i }}
                className="glass-card rounded-2xl p-6 border border-white/[0.06] hover:border-blue-500/30 transition-all duration-500"
              >
                <div className="flex items-start gap-4">
                  <motion.div 
                    className={`w-16 h-16 rounded-xl bg-gradient-to-br ${cosmic.gradient} flex items-center justify-center text-3xl flex-shrink-0`}
                    whileHover={{ scale: 1.1, rotate: 360 }}
                    transition={{ duration: 0.5 }}
                  >
                    {cosmic.icon}
                  </motion.div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className={`text-2xl font-bold bg-gradient-to-r ${cosmic.gradient} bg-clip-text text-transparent`}>
                          {cosmic.title}
                        </h3>
                        <p className="text-white/40 text-sm">{cosmic.scale} Scale Comparison</p>
                      </div>
                    </div>
                    <p className="text-white/70 leading-relaxed mt-3" style={{ fontFamily: "'Playfair Display', serif" }}>
                      {cosmic.comparison}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* Historical Tab */}
        {activeTab === 'historical' && (
          <div className="space-y-5">
            {historicalComparisons.map((hist, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.05 * i }}
                className="glass-card rounded-2xl p-6 border border-white/[0.06] hover:border-gold-500/30 transition-all duration-500"
              >
                <div className="flex items-start gap-4">
                  <motion.div 
                    className={`w-16 h-16 rounded-xl bg-gradient-to-br ${hist.gradient} flex items-center justify-center text-3xl flex-shrink-0`}
                    whileHover={{ scale: 1.1, rotate: 5 }}
                  >
                    {hist.icon}
                  </motion.div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className={`text-2xl font-bold bg-gradient-to-r ${hist.gradient} bg-clip-text text-transparent`}>
                          {hist.name}
                        </h3>
                        <p className="text-white/40 text-sm">{hist.era} • {hist.title}</p>
                      </div>
                    </div>
                    <p className="text-white/70 leading-relaxed mt-3" style={{ fontFamily: "'Playfair Display', serif" }}>
                      {hist.comparison}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* Literary Tab */}
        {activeTab === 'literary' && (
          <div className="space-y-5">
            {literaryComparisons.map((lit, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * i }}
                className="glass-card rounded-2xl p-6 border border-white/[0.06] hover:border-purple-500/30 transition-all duration-500"
              >
                <div className="flex items-start gap-4">
                  <motion.div 
                    className={`w-16 h-16 rounded-xl bg-gradient-to-br ${lit.gradient} flex items-center justify-center text-3xl flex-shrink-0`}
                    whileHover={{ scale: 1.1, rotate: 5 }}
                  >
                    {lit.icon}
                  </motion.div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className={`text-2xl font-bold bg-gradient-to-r ${lit.gradient} bg-clip-text text-transparent`}>
                          {lit.name}
                        </h3>
                        <p className="text-white/40 text-sm">{lit.work} by {lit.author}</p>
                      </div>
                    </div>
                    <p className="text-white/70 leading-relaxed mt-3" style={{ fontFamily: "'Playfair Display', serif" }}>
                      {lit.comparison}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-12 text-center"
        >
          <div className="inline-block px-8 py-4 rounded-2xl bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/20">
            <p className="text-purple-400/80 text-xl italic mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
              "I compared you to goddesses, heroes, and the cosmos itself..."
            </p>
            <p className="text-white/60 text-sm">
              But honestly? You're beyond comparison. You're YOU. And that's more legendary than anything that ever existed. 👑✨
            </p>
          </div>
        </motion.div>
      </div>

    </SectionInner>
  );
}

function LoveFactsContent() {  const loveFacts = [
    { fact: "Falling in love has a similar neurological effect as cocaine — both produce the same euphoric feeling of happiness.", emoji: "🧪", category: "Science" },
    { fact: "Couples who laugh together tend to have stronger and longer-lasting relationships.", emoji: "😂", category: "Relationships" },
    { fact: "The feeling of butterflies in your stomach is actually caused by adrenaline released during the fight-or-flight response.", emoji: "🦋", category: "Biology" },
    { fact: "Looking into each other's eyes can synchronize your heartbeats and create a deeper bond.", emoji: "👀", category: "Connection" },
    { fact: "Cuddling releases oxytocin, which helps heal physical wounds and reduces pain.", emoji: "🤗", category: "Health" },
    { fact: "It only takes 4 minutes to decide whether you like someone or not.", emoji: "⏱️", category: "Psychology" },
    { fact: "Being in love can reduce headaches. Studies show that romance activates pain-relief areas in the brain.", emoji: "💊", category: "Science" },
    { fact: "Couples who are in love synchronize their heart rates after gazing into each other's eyes for 3 minutes.", emoji: "💓", category: "Biology" },
    { fact: "Love is actually a chemical cocktail — a mix of dopamine, oxytocin, serotonin, and adrenaline.", emoji: "⚗️", category: "Chemistry" },
    { fact: "Holding hands with someone you love can alleviate physical pain and stress.", emoji: "🤝", category: "Health" },
    { fact: "The ancient Greeks described 7 types of love: Eros, Philia, Storge, Agape, Ludus, Pragma, and Philautia.", emoji: "🏛️", category: "History" },
    { fact: "Your heart can actually sync with the music you listen to — love songs can literally make your heart flutter.", emoji: "🎵", category: "Music" },
    { fact: "Romantic love eventually transforms into committed love, which is associated with calmness and security.", emoji: "🏡", category: "Psychology" },
    { fact: "Expressing gratitude to your partner increases both partners' sense of connection and satisfaction.", emoji: "🙏", category: "Relationships" },
    { fact: "Pupil dilation is a sign of attraction — your pupils can expand up to 45% when looking at someone you love.", emoji: "😍", category: "Biology" },
    { fact: "A hug that lasts 20 seconds releases enough oxytocin to make you trust someone more.", emoji: "💕", category: "Health" },
    { fact: "Love literally makes you do crazy things — it deactivates the brain pathway responsible for fear and negative emotions.", emoji: "🤪", category: "Neuroscience" },
    { fact: "Couples who travel together have healthier and happier relationships than those who don't.", emoji: "✈️", category: "Relationships" },
    { fact: "Monogamous relationships exist throughout the animal kingdom — seahorses, wolves, and swans mate for life.", emoji: "🦢", category: "Nature" },
    { fact: "When two lovers gaze at each other, their brains release phenylethylamine — the same chemical found in chocolate.", emoji: "🍫", category: "Chemistry" },
  ];

  const [currentFactIndex, setCurrentFactIndex] = useState(0);
  const [isAutoPlay, setIsAutoPlay] = useState(true);
  const [direction, setDirection] = useState(1);

  const getRandomIndex = useCallback(() => {
    let newIndex;
    do { newIndex = Math.floor(Math.random() * loveFacts.length); } while (newIndex === currentFactIndex && loveFacts.length > 1);
    return newIndex;
  }, [currentFactIndex, loveFacts.length]);

  const nextFact = () => { setDirection(1); setCurrentFactIndex(getRandomIndex()); };
  const prevFact = () => { setDirection(-1); setCurrentFactIndex((prev) => (prev - 1 + loveFacts.length) % loveFacts.length); };

  useEffect(() => {
    if (!isAutoPlay) return;
    const interval = setInterval(() => {
      setDirection(1);
      setCurrentFactIndex((prev) => {
        let newIdx;
        do { newIdx = Math.floor(Math.random() * loveFacts.length); } while (newIdx === prev);
        return newIdx;
      });
    }, 8000);
    return () => clearInterval(interval);
  }, [isAutoPlay, loveFacts.length]);

  const currentFact = loveFacts[currentFactIndex];
  const categoryColors: Record<string, string> = {
    Science: "from-blue-500 to-cyan-500", Relationships: "from-pink-500 to-rose-500",
    Biology: "from-green-500 to-emerald-500", Connection: "from-purple-500 to-violet-500",
    Health: "from-red-500 to-pink-500", Psychology: "from-amber-500 to-orange-500",
    Chemistry: "from-yellow-500 to-amber-500", History: "from-stone-500 to-amber-700",
    Music: "from-violet-500 to-purple-500", Neuroscience: "from-indigo-500 to-blue-500",
    Nature: "from-emerald-500 to-green-600",
  };

  return (
    <SectionInner>
      <GlowOrb color="cyan" className="-top-20 right-10" />
      <GlowOrb color="pink" className="bottom-10 -left-10" />
      <div className="max-w-4xl mx-auto relative z-10">
        <SectionHeader emoji="🧠" title="Random Love Facts" subtitle="Fascinating facts about the beautiful thing we share" />
        <div className="flex items-center justify-center gap-3 mb-10 flex-wrap">
          <button onClick={() => setIsAutoPlay(!isAutoPlay)} className={`px-5 py-2.5 rounded-xl text-xs font-medium border transition-all duration-300 flex items-center gap-2 ${isAutoPlay ? "bg-pink-500/10 border-pink-500/30 text-pink-400" : "bg-white/5 border-white/10 text-white/40"}`}>
            <div className={`w-2 h-2 rounded-full ${isAutoPlay ? "bg-pink-500 animate-pulse" : "bg-white/20"}`} />
            {isAutoPlay ? "Auto-Play On" : "Auto-Play Off"}
          </button>
          <span className="text-white/15 text-xs">{currentFactIndex + 1} / {loveFacts.length}</span>
        </div>
        <div className="relative">
          <button onClick={prevFact} className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-2 md:-translate-x-14 z-20 w-10 h-10 md:w-12 md:h-12 rounded-full glass-card flex items-center justify-center text-white/40 hover:text-white/80 transition-all"><ChevronUp className="w-5 h-5 -rotate-90" /></button>
          <button onClick={nextFact} className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-2 md:translate-x-14 z-20 w-10 h-10 md:w-12 md:h-12 rounded-full glass-card flex items-center justify-center text-white/40 hover:text-white/80 transition-all"><ChevronUp className="w-5 h-5 rotate-90" /></button>
          <AnimatePresence mode="wait" custom={direction}>
            <motion.div key={currentFactIndex} custom={direction} initial={{ opacity: 0, x: direction * 100, scale: 0.95 }} animate={{ opacity: 1, x: 0, scale: 1 }} exit={{ opacity: 0, x: direction * -100, scale: 0.95 }} transition={{ duration: 0.5, ease: "easeInOut" }} className="relative mx-8 md:mx-0">
              <div className="absolute -inset-2 bg-gradient-to-br from-pink-500/10 via-purple-500/5 to-cyan-500/10 rounded-[32px] blur-xl opacity-60" />
              <div className="relative glass-strong rounded-[24px] p-8 md:p-12 gradient-border overflow-hidden">
                <div className="absolute top-4 right-4 text-[120px] md:text-[160px] opacity-[0.03] leading-none select-none pointer-events-none">{currentFact.emoji}</div>
                <div className="flex items-center mb-8">
                  <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/[0.03]">
                    <div className={`w-2 h-2 rounded-full bg-gradient-to-r ${categoryColors[currentFact.category] || "from-pink-500 to-purple-500"}`} />
                    <span className="text-white/50 text-xs font-medium tracking-wider uppercase">{currentFact.category}</span>
                  </div>
                </div>
                <div className="flex justify-center mb-8">
                  <motion.div initial={{ scale: 0, rotate: -30 }} animate={{ scale: 1, rotate: 0 }} transition={{ type: "spring", stiffness: 200, delay: 0.2 }} className="w-20 h-20 md:w-24 md:h-24 rounded-2xl bg-gradient-to-br from-pink-500/10 via-purple-500/10 to-cyan-500/10 flex items-center justify-center border border-white/5">
                    <span className="text-4xl md:text-5xl">{currentFact.emoji}</span>
                  </motion.div>
                </div>
                <motion.p initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="text-white/60 text-lg md:text-xl leading-relaxed text-center max-w-2xl mx-auto relative z-10" style={{ fontFamily: "'Playfair Display', serif" }}>"{currentFact.fact}"</motion.p>
                {isAutoPlay && (
                  <div className="mt-8 w-full h-0.5 bg-white/5 rounded-full overflow-hidden">
                    <motion.div key={currentFactIndex} initial={{ width: "0%" }} animate={{ width: "100%" }} transition={{ duration: 8, ease: "linear" }} className="h-full bg-gradient-to-r from-pink-500 to-purple-500 rounded-full" />
                  </div>
                )}
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
        <div className="text-center mt-10">
          <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} onClick={nextFact} className="inline-flex items-center gap-3 px-8 py-4 rounded-2xl bg-gradient-to-r from-pink-500/15 to-cyan-500/15 border border-pink-500/20 text-white/60 text-sm font-medium hover:text-white/90 hover:shadow-[0_0_30px_rgba(255,45,138,0.15)] hover:border-pink-500/40 transition-all duration-300 group">
            <Sparkles className="w-4 h-4 text-pink-400 group-hover:animate-pulse" />
            <span>Show Me Another Fact</span>
            <Heart className="w-4 h-4 text-pink-400 fill-pink-400 group-hover:animate-heartbeat" />
          </motion.button>
        </div>
      </div>


    </SectionInner>
  );
}

function QuizContent() {
  const [currentQ, setCurrentQ] = useState(0);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);

  const questions = [
    { q: "What's the password to this website? 😉", options: ["password123", "letmein", "iloveyou", "opensesame"], correct: 2 },
    { q: "What matters most in love?", options: ["Money", "Trust & Communication", "Looks", "Social Media"], correct: 1 },
    { q: "How much do I love you?", options: ["A little", "A lot", "To infinity", "Beyond infinity ♾️"], correct: 3 },
    { q: "What's the best thing about you?", options: ["Everything!", "Also everything", "Still everything", "All of the above"], correct: 3 },
    { q: "Will I ever stop loving you?", options: ["Never!", "Absolutely never", "Not in a million years", "All of the above"], correct: 3 },
  ];

  const handleAnswer = (idx: number) => {
    if (selectedAnswer !== null) return;
    setSelectedAnswer(idx);
    if (idx === questions[currentQ].correct) setScore((s) => s + 1);
    setTimeout(() => {
      if (currentQ < questions.length - 1) { setCurrentQ((q) => q + 1); setSelectedAnswer(null); } else { setShowResult(true); }
    }, 1200);
  };

  const reset = () => { setCurrentQ(0); setScore(0); setShowResult(false); setSelectedAnswer(null); };

  return (
    <SectionInner>
      <GlowOrb color="purple" className="top-10 left-10" />
      <GlowOrb color="pink" className="bottom-10 right-10" />
      <div className="max-w-2xl mx-auto relative z-10">
        <SectionHeader emoji="💝" title="Love Quiz" subtitle="Let's have some fun together!" />
        <AnimatePresence mode="wait">
          {!showResult ? (
            <motion.div key={currentQ} initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -50 }} className="glass-strong rounded-2xl p-6 md:p-8 gradient-border">
              <div className="w-full h-1 bg-white/5 rounded-full mb-6 overflow-hidden">
                <motion.div initial={{ width: `${(currentQ / questions.length) * 100}%` }} animate={{ width: `${((currentQ + 1) / questions.length) * 100}%` }} className="h-full bg-gradient-to-r from-pink-500 to-purple-500 rounded-full" />
              </div>
              <div className="flex justify-between items-center mb-6">
                <span className="text-pink-400 text-sm font-medium">Question {currentQ + 1} of {questions.length}</span>
                <span className="text-white/20 text-sm">Score: {score}</span>
              </div>
              <h3 className="text-xl md:text-2xl font-semibold text-white mb-8">{questions[currentQ].q}</h3>
              <div className="space-y-3">
                {questions[currentQ].options.map((opt, i) => {
                  const isSelected = selectedAnswer === i;
                  const isCorrect = i === questions[currentQ].correct;
                  const showState = selectedAnswer !== null;
                  return (
                    <motion.button key={i} whileHover={selectedAnswer === null ? { scale: 1.01, x: 4 } : undefined} whileTap={selectedAnswer === null ? { scale: 0.99 } : undefined} onClick={() => handleAnswer(i)} className={`w-full text-left p-4 rounded-xl border transition-all duration-300 flex items-center gap-3 ${!showState ? "border-white/8 bg-white/3 hover:border-pink-500/20 hover:bg-pink-500/5" : isSelected && isCorrect ? "border-green-500/40 bg-green-500/10" : isSelected && !isCorrect ? "border-red-500/40 bg-red-500/10" : isCorrect ? "border-green-500/30 bg-green-500/5" : "border-white/3 bg-white/1 opacity-40"}`}>
                      <div className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold flex-shrink-0 ${!showState ? "bg-white/5 text-white/40" : isCorrect ? "bg-green-500/20 text-green-400" : isSelected ? "bg-red-500/20 text-red-400" : "bg-white/3 text-white/20"}`}>{String.fromCharCode(65 + i)}</div>
                      <span className="text-white/70 text-sm">{opt}</span>
                      {showState && isCorrect && <span className="ml-auto text-green-400">✓</span>}
                      {showState && isSelected && !isCorrect && <span className="ml-auto text-red-400">✗</span>}
                    </motion.button>
                  );
                })}
              </div>
            </motion.div>
          ) : (
            <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="glass-strong rounded-2xl p-8 md:p-10 text-center gradient-border">
              <span className="text-7xl block mb-6">🎉</span>
              <h3 className="text-3xl font-bold text-white mb-3">You scored {score}/{questions.length}!</h3>
              <p className="text-white/40 mb-8 max-w-sm mx-auto">{score === questions.length ? "Perfect score! You know our love by heart! 💕" : score >= 3 ? "Amazing! You know me so well! 💖" : "No matter what, you're always perfect to me! 💗"}</p>
              <button onClick={reset} className="px-8 py-3 rounded-xl bg-gradient-to-r from-pink-500 to-purple-500 text-white text-sm font-medium hover:shadow-[0_0_25px_rgba(255,45,138,0.3)] transition-all">Play Again ♥</button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </SectionInner>
  );
}

function QuotesContent() {  const quotes = [
    // Classic & Timeless Love
    { text: "You are my today and all of my tomorrows.", author: "Leo Christopher" },
    { text: "In all the world, there is no heart for me like yours.", author: "Maya Angelou" },
    { text: "I love you not because of who you are, but because of who I am when I am with you.", author: "Roy Croft" },
    { text: "Whatever our souls are made of, his and mine are the same.", author: "Emily Brontë" },
    { text: "You know you're in love when you can't fall asleep because reality is finally better than your dreams.", author: "Dr. Seuss" },
    { text: "I wish I could turn back the clock. I'd find you sooner and love you longer.", author: "Unknown" },
    
    // Passionate & Deep Love
    { text: "I am catastrophically in love with you.", author: "Cassandra Clare" },
    { text: "You are every reason, every hope, and every dream I've ever had.", author: "Nicholas Sparks" },
    { text: "I love you more than I have ever found a way to say to you.", author: "Ben Folds" },
    { text: "My heart is and always will be yours.", author: "Jane Austen" },
    { text: "I would rather spend one lifetime with you, than face all the ages of this world alone.", author: "J.R.R. Tolkien" },
    { text: "You pierce my soul. I am half agony, half hope.", author: "Jane Austen" },
    
    // Soulmate & Destiny
    { text: "I seem to have loved you in numberless forms, numberless times, in life after life, in age after age, forever.", author: "Rabindranath Tagore" },
    { text: "I have waited for this opportunity for more than half a century, to repeat to you once again my vow of eternal fidelity and everlasting love.", author: "Gabriel García Márquez" },
    { text: "In case you ever foolishly forget: I am never not thinking of you.", author: "Virginia Woolf" },
    { text: "I carry your heart with me. I carry it in my heart.", author: "E.E. Cummings" },
    { text: "You are the finest, loveliest, tenderest, and most beautiful person I have ever known—and even that is an understatement.", author: "F. Scott Fitzgerald" },
    
    // Devotion & Forever
    { text: "I will love you until the stars go out, and the tides no longer turn.", author: "Unknown" },
    { text: "I love you without knowing how, or when, or from where. I love you simply, without problems or pride.", author: "Pablo Neruda" },
    { text: "To be your friend was all I ever wanted; to be your lover was all I ever dreamed.", author: "Valerie Lombardo" },
    { text: "You are my heart, my life, my one and only thought.", author: "Arthur Conan Doyle" },
    { text: "I love you not only for what you are, but for what I am when I am with you.", author: "Elizabeth Barrett Browning" },
    
    // Poetic & Beautiful
    { text: "If I had a flower for every time I thought of you, I could walk through my garden forever.", author: "Alfred Tennyson" },
    { text: "You are the last thought in my mind before I drift off to sleep and the first thought when I wake up each morning.", author: "Unknown" },
    { text: "In your light I learn how to love. In your beauty, how to make poems.", author: "Rumi" },
    { text: "I love you as certain dark things are to be loved, in secret, between the shadow and the soul.", author: "Pablo Neruda" },
    { text: "I swear I couldn't love you more than I do right now, and yet I know I will tomorrow.", author: "Leo Christopher" },
    
    // Modern & Relatable
    { text: "You are my favorite notification.", author: "Unknown" },
    { text: "I fell in love the way you fall asleep: slowly, and then all at once.", author: "John Green" },
    { text: "When I saw you I fell in love, and you smiled because you knew.", author: "Arrigo Boito" },
    { text: "You're the closest to heaven that I'll ever be.", author: "Goo Goo Dolls" },
    
    // Deep & Meaningful
    { text: "The best love is the kind that awakens the soul and makes us reach for more.", author: "Nicholas Sparks" },
    { text: "Love recognizes no barriers. It jumps hurdles, leaps fences, penetrates walls to arrive at its destination full of hope.", author: "Maya Angelou" },
    { text: "A thousand half-loves must be forsaken to take one whole heart home.", author: "Rumi" },
    { text: "Being deeply loved by someone gives you strength, while loving someone deeply gives you courage.", author: "Lao Tzu" },
    { text: "When we are in love, we seem to ourselves quite different from what we were before.", author: "Blaise Pascal" },
    
    // Romantic & Sweet
    { text: "I have found the one whom my soul loves.", author: "Song of Solomon" },
    { text: "You don't marry someone you can live with, you marry the person you cannot live without.", author: "Unknown" },
    { text: "I love you begins by I, but it ends up by you.", author: "Charles de Leusse" },
    { text: "I want all of you, forever, you and me, every day.", author: "The Notebook" },
    { text: "You are my sun, my moon, and all my stars.", author: "E.E. Cummings" },
    { text: "I look at you and see the rest of my life in front of my eyes.", author: "Unknown" },
    { text: "Every love story is beautiful, but ours is my favorite.", author: "Unknown" },
    { text: "I will love you until the last breath leaves my body.", author: "Unknown" },
    { text: "You are the answer to every prayer I've offered. You are a song, a dream, a whisper, and I don't know how I could have lived without you for as long as I have.", author: "Nicholas Sparks" },
    { text: "In your arms is right where I want to be, where nothing else matters but you and me.", author: "Unknown" },
  ];

  return (
    <SectionInner>
      <GlowOrb color="purple" className="top-20 left-20" />
      <div className="max-w-5xl mx-auto relative z-10">
        <SectionHeader emoji="💬" title="Love Quotes" subtitle="Words that speak my heart" />
        <div className="grid md:grid-cols-2 gap-5">
          {quotes.map((q, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 + i * 0.1 }} whileHover={{ y: -4 }} className="love-letter rounded-2xl p-7 relative group hover:shadow-[0_0_30px_rgba(255,45,138,0.08)] transition-all duration-500">
              <Quote className="w-8 h-8 text-pink-500/15 mb-4" />
              <p className="text-white/50 italic leading-relaxed text-[15px]" style={{ fontFamily: "'Playfair Display', serif" }}>"{q.text}"</p>
              <div className="flex items-center gap-2 mt-5">
                <div className="w-6 h-px bg-pink-500/30" />
                <p className="text-pink-400/40 text-xs font-medium">{q.author}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>


    </SectionInner>
  );
}

function DreamBoyContent() {
  const [currentCategory, setCurrentCategory] = useState(0);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [showResults, setShowResults] = useState(false);

  const categories = [
    {
      name: "Physical Appearance",
      icon: "👤",
      gradient: "from-blue-500 to-cyan-500",
      questions: [
        {
          q: "Height preference?",
          type: "choice",
          options: ["Shorter than me", "Same height as me", "1-2 inches taller", "3-4 inches taller", "5-6 inches taller", "7-8 inches taller", "9-10 inches taller", "Much taller (11+ inches)", "Any height works", "Prefer shorter", "Must be taller", "Height doesn't matter at all"]
        },
        {
          q: "Body type?",
          type: "choice",
          options: ["Slim/Lean", "Athletic/Toned", "Average build", "Muscular/Buff", "Teddy bear (cuddly)", "Doesn't matter"]
        },
        {
          q: "Hair length preference?",
          type: "choice",
          options: ["Buzz cut/Very short", "Short and neat", "Medium length", "Long hair", "Man bun worthy", "Doesn't matter"]
        },
        {
          q: "Hair texture?",
          type: "choice",
          options: ["Straight", "Wavy", "Curly", "Coily", "Whatever looks good on him", "Doesn't matter"]
        },
        {
          q: "Facial hair preference?",
          type: "choice",
          options: ["Clean shaven always", "Light stubble", "Well-groomed beard", "Full beard", "Mustache only", "Changes it up", "Doesn't matter"]
        },
        {
          q: "Eye color preference?",
          type: "choice",
          options: ["Brown", "Black", "Blue", "Green", "Hazel", "Grey", "Doesn't matter at all"]
        },
        {
          q: "Skin tone?",
          type: "choice",
          options: ["Fair", "Wheatish", "Dusky", "Dark", "Doesn't matter - all are beautiful"]
        },
        {
          q: "Glasses?",
          type: "choice",
          options: ["Yes, glasses are cute", "No, prefer without", "Either works", "Sometimes glasses are hot"]
        },
        {
          q: "Smile type?",
          type: "choice",
          options: ["Bright and toothy", "Subtle/Mysterious", "Dimples!", "Crooked/Unique", "Genuine and warm", "All smiles are beautiful"]
        },
        {
          q: "Hands preference?",
          type: "choice",
          options: ["Veiny and masculine", "Soft and gentle", "Large hands", "Long fingers", "Doesn't matter"]
        },
        {
          q: "Hair color preference?",
          type: "choice",
          options: ["Black hair", "Brown hair", "Blonde hair", "Red/Ginger", "Dyed/Colored hair", "Gray/Silver", "Natural color", "Any color suits him", "Unique colors", "Classic dark", "Light colored", "Doesn't matter at all"]
        },
        {
          q: "Nose type?",
          type: "choice",
          options: ["Sharp nose", "Broad nose", "Button nose", "Roman nose", "Straight nose", "Unique nose", "Natural nose", "Doesn't matter", "Whatever suits his face", "All noses beautiful", "Not important to me"]
        },
        {
          q: "Lips preference?",
          type: "choice",
          options: ["Full lips", "Thin lips", "Medium lips", "Defined cupid's bow", "Soft lips", "Natural lips", "Pink lips", "Doesn't matter", "Kissable lips", "Whatever is natural", "Not important"]
        },
        {
          q: "Eyebrows?",
          type: "choice",
          options: ["Thick eyebrows", "Thin eyebrows", "Natural brows", "Well-groomed", "Bushy brows", "Shaped/Threaded", "Doesn't matter", "Masculine thick brows", "Clean maintained", "Whatever natural", "Don't notice eyebrows"]
        },
        {
          q: "Teeth/Smile quality?",
          type: "choice",
          options: ["Perfect white teeth", "Natural teeth", "Slightly imperfect is cute", "Gap tooth is charming", "Doesn't matter at all", "Straight teeth", "Whitened teeth", "Natural smile", "Dental work is fine", "All smiles beautiful", "Crooked is unique"]
        },
        {
          q: "Overall facial symmetry?",
          type: "choice",
          options: ["Perfect symmetry", "Mostly symmetrical", "Unique features", "Doesn't matter", "Asymmetry is character", "Balanced face", "Natural face", "Model-like", "Real person", "Whatever he has", "Not important"]
        }
      ]
    },
    {
      name: "Personality Core",
      icon: "🧠",
      gradient: "from-purple-500 to-pink-500",
      questions: [
        {
          q: "Introvert or Extrovert?",
          type: "choice",
          options: ["Introverted (quiet, reserved)", "Ambivert (balanced)", "Extroverted (outgoing, social)", "Depends on the situation"]
        },
        {
          q: "Sense of humor?",
          type: "choice",
          options: ["Witty and sarcastic", "Goofy and playful", "Dark humor", "Wholesome and punny", "Situational comedy", "Dry/Deadpan", "Mix of everything"]
        },
        {
          q: "Intelligence type?",
          type: "choice",
          options: ["Book smart/Academic", "Street smart/Practical", "Emotionally intelligent", "Creative/Artistic", "All-around smart", "Doesn't have to be genius"]
        },
        {
          q: "Confidence level?",
          type: "choice",
          options: ["Very confident/Alpha", "Quietly confident", "Humble and modest", "A bit shy (cute)", "Balanced confidence", "Doesn't matter"]
        },
        {
          q: "Emotional expressiveness?",
          type: "choice",
          options: ["Very expressive with feelings", "Moderately expressive", "Reserved but opens up", "Actions over words", "Emotionally balanced"]
        },
        {
          q: "Ambition level?",
          type: "choice",
          options: ["Highly ambitious/Driven", "Moderately ambitious", "Content and peaceful", "Balanced approach", "Doesn't matter much"]
        },
        {
          q: "Spontaneity vs Planning?",
          type: "choice",
          options: ["Very spontaneous/Adventurous", "Mix of both", "Prefers planning", "Go with the flow", "Situational"]
        },
        {
          q: "Maturity level?",
          type: "choice",
          options: ["Very mature for age", "Age-appropriate", "Young at heart", "Depends on situation", "Mix of mature and playful"]
        },
        {
          q: "Optimist or Realist?",
          type: "choice",
          options: ["Optimist (glass half full)", "Realist (practical)", "Pessimist (cautious)", "Balanced perspective"]
        },
        {
          q: "Leadership quality?",
          type: "choice",
          options: ["Natural leader", "Good team player", "Prefers to follow", "Can do both", "Doesn't matter"]
        },
        {
          q: "Morning vs night energy levels?",
          type: "choice",
          options: ["High energy mornings", "Night owl energy", "Consistent all day", "Depends on sleep", "Afternoon person", "Early riser", "Late night active", "Balanced energy", "Varies daily", "Either works fine", "Doesn't matter"]
        },
        {
          q: "Social battery recharge?",
          type: "choice",
          options: ["Recharges alone", "Recharges with people", "Both work", "Needs alone time", "Needs social time", "Balanced needs", "Depends on week", "Flexible", "Ambivert", "Doesn't matter"]
        },
        {
          q: "Competitive in games/sports?",
          type: "choice",
          options: ["Very competitive", "Playfully competitive", "Not competitive", "Depends on game", "Sore loser", "Gracious winner", "Just for fun", "Serious competitor", "Balanced", "Doesn't matter"]
        }
      ]
    },
    {
      name: "Communication Style",
      icon: "💬",
      gradient: "from-green-500 to-teal-500",
      questions: [
        {
          q: "Texting frequency?",
          type: "choice",
          options: ["Constant texter", "Regular throughout day", "Few quality messages", "Prefers calls over texts", "Balanced approach"]
        },
        {
          q: "Communication preference?",
          type: "choice",
          options: ["Texting", "Phone calls", "Video calls", "In-person only", "Mix of everything"]
        },
        {
          q: "Response time?",
          type: "choice",
          options: ["Instant replies", "Within an hour", "Few hours is fine", "Whenever he's free", "Doesn't matter"]
        },
        {
          q: "Deep conversations?",
          type: "choice",
          options: ["Loves deep 3am talks", "Occasionally yes", "Prefers light topics", "Mix of both", "Doesn't matter"]
        },
        {
          q: "Argument handling?",
          type: "choice",
          options: ["Discusses calmly", "Needs space first", "Confronts directly", "Avoids conflict", "Compromises easily"]
        },
        {
          q: "Listening skills?",
          type: "choice",
          options: ["Active listener (very attentive)", "Good listener", "Sometimes distracted", "Tries his best"]
        },
        {
          q: "Opening up?",
          type: "choice",
          options: ["Opens up easily", "Takes time to trust", "Very private", "Shares when comfortable"]
        },
        {
          q: "Compliments frequency?",
          type: "choice",
          options: ["Very expressive with compliments", "Occasional sweet words", "Shows through actions", "Balanced approach"]
        },
        {
          q: "Apology style?",
          type: "choice",
          options: ["Quick to apologize", "Takes time to reflect", "Shows through actions", "Talks it out"]
        },
        {
          q: "Sarcasm level?",
          type: "choice",
          options: ["Very sarcastic", "Moderately sarcastic", "Rarely sarcastic", "Never sarcastic", "Depends on mood"]
        }
      ]
    },
    {
      name: "Romance & Affection",
      icon: "💕",
      gradient: "from-pink-500 to-rose-500",
      questions: [
        {
          q: "Love language (giving)?",
          type: "choice",
          options: ["Words of affirmation", "Quality time", "Physical touch", "Acts of service", "Gift giving", "All of them"]
        },
        {
          q: "PDA (Public Display of Affection)?",
          type: "choice",
          options: ["Very comfortable with PDA", "Hand holding is okay", "Minimal PDA", "Private person", "Depends on mood"]
        },
        {
          q: "Romantic gestures?",
          type: "choice",
          options: ["Grand romantic gestures", "Small daily surprises", "Thoughtful planned dates", "Spontaneous moments", "Mix of everything"]
        },
        {
          q: "Pet names?",
          type: "choice",
          options: ["Uses cute pet names", "Occasional pet names", "Prefers real name", "Unique nicknames", "Doesn't matter"]
        },
        {
          q: "Date planning?",
          type: "choice",
          options: ["Always plans dates", "Takes turns planning", "Spontaneous dates", "Lets me plan", "Collaborative planning"]
        },
        {
          q: "Anniversary/Special days?",
          type: "choice",
          options: ["Remembers and celebrates all", "Remembers major ones", "Needs reminders", "Makes every day special", "Low-key celebrations"]
        },
        {
          q: "Gift giving?",
          type: "choice",
          options: ["Thoughtful surprise gifts", "Practical gifts", "Experience gifts", "Handmade/Personal", "Doesn't have to give gifts"]
        },
        {
          q: "Morning/Night texts?",
          type: "choice",
          options: ["Always sends good morning/night", "Sometimes", "Prefers calls", "Shows love differently", "Doesn't matter"]
        },
        {
          q: "Jealousy level?",
          type: "choice",
          options: ["Slightly protective", "Trusts completely", "A little jealous (cute)", "Very secure", "Balanced"]
        },
        {
          q: "Cuddling preference?",
          type: "choice",
          options: ["Loves to cuddle always", "Occasional cuddles", "Not very touchy", "Depends on mood", "Comfortable with both"]
        }
      ]
    },
    {
      name: "Lifestyle & Habits",
      icon: "🏃",
      gradient: "from-orange-500 to-red-500",
      questions: [
        {
          q: "Morning person or night owl?",
          type: "choice",
          options: ["Early bird (wakes up early)", "Night owl (stays up late)", "Flexible schedule", "Adapts to situation"]
        },
        {
          q: "Fitness routine?",
          type: "choice",
          options: ["Gym rat (very fit)", "Regular exercise", "Occasional workouts", "Active lifestyle", "Not into fitness", "Doesn't matter"]
        },
        {
          q: "Eating habits?",
          type: "choice",
          options: ["Foodie (loves food)", "Healthy eater", "Not picky", "Adventurous eater", "Simple tastes"]
        },
        {
          q: "Cooking skills?",
          type: "choice",
          options: ["Great cook", "Can cook basics", "Learning to cook", "Doesn't cook", "We can learn together"]
        },
        {
          q: "Cleanliness level?",
          type: "choice",
          options: ["Very neat and organized", "Generally clean", "Organized chaos", "A bit messy", "Doesn't matter much"]
        },
        {
          q: "Alcohol/Party scene?",
          type: "choice",
          options: ["Non-drinker", "Social drinker", "Occasional parties", "Party person", "Doesn't matter"]
        },
        {
          q: "Smoking?",
          type: "choice",
          options: ["Non-smoker (must)", "Occasional smoker", "Trying to quit", "Doesn't matter"]
        },
        {
          q: "Sleep schedule?",
          type: "choice",
          options: ["Regular sleep schedule", "Irregular hours", "Can stay up for me", "Flexible", "Doesn't matter"]
        },
        {
          q: "Pet preference?",
          type: "choice",
          options: ["Dog person", "Cat person", "Loves all animals", "Not a pet person", "Open to pets"]
        },
        {
          q: "Travel enthusiasm?",
          type: "choice",
          options: ["Loves traveling", "Occasional traveler", "Homebody", "Adventurous explorer", "Balanced approach"]
        }
      ]
    },
    {
      name: "Social Life",
      icon: "👥",
      gradient: "from-indigo-500 to-purple-500",
      questions: [
        {
          q: "Friend circle?",
          type: "choice",
          options: ["Large friend group", "Small close group", "Few best friends", "More alone time", "Balanced social life"]
        },
        {
          q: "Social media activity?",
          type: "choice",
          options: ["Very active", "Moderate use", "Minimal presence", "Private account", "Doesn't use much"]
        },
        {
          q: "Posts about relationship?",
          type: "choice",
          options: ["Shows off relationship", "Occasional posts", "Very private", "Doesn't matter to me"]
        },
        {
          q: "Meeting friends vs couple time?",
          type: "choice",
          options: ["Prioritizes couple time", "Balances both well", "Social butterfly", "Includes me with friends"]
        },
        {
          q: "Female friends?",
          type: "choice",
          options: ["No female friends preferred", "Few female friends okay", "Many female friends", "Mature friendships fine"]
        },
        {
          q: "Family time?",
          type: "choice",
          options: ["Very family-oriented", "Regular family contact", "Independent", "Balanced approach"]
        },
        {
          q: "Social anxiety?",
          type: "choice",
          options: ["Very comfortable socially", "Slightly shy in groups", "Prefers small gatherings", "Understanding of anxiety"]
        },
        {
          q: "Party preference?",
          type: "choice",
          options: ["Loves parties", "Occasional party-goer", "Prefers quiet hangouts", "Flexible"]
        },
        {
          q: "Making new friends?",
          type: "choice",
          options: ["Makes friends easily", "Selective with friends", "Prefers existing friends", "Doesn't matter"]
        },
        {
          q: "Group activities?",
          type: "choice",
          options: ["Loves group activities", "Prefers one-on-one", "Both are fine", "Situational"]
        }
      ]
    },
    {
      name: "Values & Beliefs",
      icon: "⭐",
      gradient: "from-yellow-500 to-orange-500",
      questions: [
        {
          q: "Religious views?",
          type: "choice",
          options: ["Very religious", "Moderately religious", "Spiritual not religious", "Not religious", "Respects all beliefs"]
        },
        {
          q: "Political awareness?",
          type: "choice",
          options: ["Very politically aware", "Moderately aware", "Not interested in politics", "Doesn't matter"]
        },
        {
          q: "Honesty level?",
          type: "choice",
          options: ["Brutally honest always", "Honest but tactful", "Little white lies okay", "Transparency is key"]
        },
        {
          q: "Loyalty importance?",
          type: "choice",
          options: ["Extremely loyal (must)", "Generally loyal", "Depends on situation", "Trust is earned"]
        },
        {
          q: "Family values?",
          type: "choice",
          options: ["Family comes first", "Balances family and relationship", "Independent from family", "Creates own family values"]
        },
        {
          q: "Gender role views?",
          type: "choice",
          options: ["Traditional roles", "Modern/Equal partnership", "Flexible roles", "Doesn't believe in roles"]
        },
        {
          q: "Environmental consciousness?",
          type: "choice",
          options: ["Very eco-conscious", "Tries to be conscious", "Not a priority", "Doesn't matter"]
        },
        {
          q: "Charity/Giving back?",
          type: "choice",
          options: ["Very charitable", "Occasionally gives back", "Supports causes", "Doesn't matter"]
        },
        {
          q: "Work-life balance?",
          type: "choice",
          options: ["Work is priority", "Life is priority", "Perfect balance", "Flexible approach"]
        },
        {
          q: "Materialism?",
          type: "choice",
          options: ["Values experiences over things", "Likes nice things", "Minimalist", "Balanced approach"]
        }
      ]
    },
    {
      name: "Career & Ambition",
      icon: "💼",
      gradient: "from-cyan-500 to-blue-500",
      questions: [
        {
          q: "Career type preference?",
          type: "choice",
          options: ["Stable corporate job", "Entrepreneur/Business", "Creative field", "Service profession", "Doesn't matter"]
        },
        {
          q: "Work dedication?",
          type: "choice",
          options: ["Workaholic", "Dedicated but balanced", "Work to live", "Passionate about work", "Flexible"]
        },
        {
          q: "Income level?",
          type: "choice",
          options: ["High earner", "Stable income", "Growing career", "Money isn't everything", "Doesn't matter"]
        },
        {
          q: "Educational background?",
          type: "choice",
          options: ["Highly educated", "College educated", "Skilled/Trained", "Self-taught", "Doesn't matter"]
        },
        {
          q: "Career ambition?",
          type: "choice",
          options: ["Highly ambitious", "Moderately driven", "Content with current", "Still figuring out"]
        },
        {
          q: "Job stability?",
          type: "choice",
          options: ["Stable long-term job", "Job hopper", "Freelancer", "Entrepreneur risk", "Doesn't matter"]
        },
        {
          q: "Work hours?",
          type: "choice",
          options: ["9-5 schedule", "Flexible hours", "Long hours", "Work from home", "Balanced schedule"]
        },
        {
          q: "Future goals clarity?",
          type: "choice",
          options: ["Clear 5-year plan", "General direction", "Living in present", "Figuring it out"]
        },
        {
          q: "Side hustles?",
          type: "choice",
          options: ["Has side projects", "Focused on one thing", "Multi-talented", "Doesn't matter"]
        },
        {
          q: "Success definition?",
          type: "choice",
          options: ["Money and status", "Happiness and peace", "Making a difference", "Personal growth", "Balanced view"]
        }
      ]
    },
    {
      name: "Interests & Hobbies",
      icon: "🎮",
      gradient: "from-purple-500 to-pink-500",
      questions: [
        {
          q: "Gaming?",
          type: "choice",
          options: ["Avid gamer", "Casual gamer", "Mobile games", "Not into gaming", "Can game together"]
        },
        {
          q: "Sports interest?",
          type: "choice",
          options: ["Plays sports actively", "Watches sports", "Both plays and watches", "Not into sports", "Doesn't matter"]
        },
        {
          q: "Reading habits?",
          type: "choice",
          options: ["Bookworm", "Occasional reader", "Specific genres only", "Not a reader", "We can read together"]
        },
        {
          q: "Music taste?",
          type: "choice",
          options: ["Similar to mine", "Different but open", "Very specific taste", "Loves all music", "Doesn't matter"]
        },
        {
          q: "Movie/Series preference?",
          type: "choice",
          options: ["Binge-watcher", "Occasional viewer", "Specific genres", "Not into shows", "Can watch together"]
        },
        {
          q: "Outdoor activities?",
          type: "choice",
          options: ["Loves outdoors", "Occasional hikes", "Beach person", "Mountain person", "Indoor person"]
        },
        {
          q: "Creative hobbies?",
          type: "choice",
          options: ["Artistic/Creative", "Musical talent", "Writing/Poetry", "Photography", "Not creative", "Doesn't matter"]
        },
        {
          q: "Cooking as hobby?",
          type: "choice",
          options: ["Loves cooking", "Enjoys occasionally", "Baking person", "Not interested", "We can cook together"]
        },
        {
          q: "Car interest?",
          type: "choice",
          options: ["Car enthusiast", "Practical about cars", "Not into cars", "Bike person", "Doesn't matter"]
        },
        {
          q: "Tech savvy?",
          type: "choice",
          options: ["Very tech-savvy", "Moderately tech-aware", "Not very techy", "Doesn't matter"]
        }
      ]
    },
    {
      name: "Relationship Dynamics",
      icon: "💑",
      gradient: "from-rose-500 to-pink-500",
      questions: [
        {
          q: "Decision making?",
          type: "choice",
          options: ["Takes lead in decisions", "We decide together", "Lets me decide", "Depends on situation"]
        },
        {
          q: "Compromise ability?",
          type: "choice",
          options: ["Very compromising", "Finds middle ground", "Stands his ground", "Situational"]
        },
        {
          q: "Trust level?",
          type: "choice",
          options: ["Complete trust", "Trusts but verifies", "Takes time to trust", "Trust is earned"]
        },
        {
          q: "Space vs togetherness?",
          type: "choice",
          options: ["Wants lots of time together", "Balanced independence", "Needs personal space", "Flexible"]
        },
        {
          q: "Handling stress?",
          type: "choice",
          options: ["Shares stress with me", "Deals alone then shares", "Keeps to himself", "Depends on stress"]
        },
        {
          q: "Future planning?",
          type: "choice",
          options: ["Plans our future together", "Takes it day by day", "Open discussions", "Committed to long-term"]
        },
        {
          q: "Possessiveness?",
          type: "choice",
          options: ["A bit possessive (cute)", "Trusts completely", "Protective not possessive", "Balanced"]
        },
        {
          q: "Supporting dreams?",
          type: "choice",
          options: ["Actively supports my goals", "Encourages me", "We support each other", "Gives me space to grow"]
        },
        {
          q: "Handling my mood swings?",
          type: "choice",
          options: ["Very patient and understanding", "Tries to cheer me up", "Gives me space", "Talks it through"]
        },
        {
          q: "Long-term commitment?",
          type: "choice",
          options: ["Talks about marriage", "Takes it slow", "Committed but no rush", "Lives in present"]
        }
      ]
    },
    {
      name: "Little Things Matter",
      icon: "✨",
      gradient: "from-pink-500 to-purple-500",
      questions: [
        {
          q: "Remembers small details?",
          type: "choice",
          options: ["Remembers everything I say", "Remembers important things", "Needs reminders", "Tries his best"]
        },
        {
          q: "Surprises?",
          type: "choice",
          options: ["Loves surprising me", "Occasional surprises", "Not good with surprises", "Everyday surprises"]
        },
        {
          q: "How he says 'I love you'?",
          type: "choice",
          options: ["Says it often", "Shows through actions", "When he means it", "Through little things", "All the ways"]
        },
        {
          q: "Comfort during periods?",
          type: "choice",
          options: ["Very understanding and caring", "Gets me what I need", "Gives me space", "Doesn't know how to help"]
        },
        {
          q: "When I'm sick?",
          type: "choice",
          options: ["Takes care of everything", "Checks on me often", "Gives me space to rest", "Worried and caring"]
        },
        {
          q: "Sharing food?",
          type: "choice",
          options: ["Always shares his food", "Lets me eat from his plate", "Protective of food", "Orders extra for me"]
        },
        {
          q: "Random acts of love?",
          type: "choice",
          options: ["Daily little gestures", "Unexpected sweet things", "Shows love practically", "Big gestures"]
        },
        {
          q: "Notices when I'm upset?",
          type: "choice",
          options: ["Immediately knows", "Asks what's wrong", "Gives me time", "Might miss signals"]
        },
        {
          q: "Celebrates my wins?",
          type: "choice",
          options: ["My biggest cheerleader", "Genuinely happy for me", "Celebrates together", "Supportive always"]
        },
        {
          q: "Late night conversations?",
          type: "choice",
          options: ["Loves talking till late", "Sometimes late talks", "Needs sleep", "Depends on mood"]
        }
      ]
    },
    {
      name: "Fashion & Style",
      icon: "👔",
      gradient: "from-indigo-500 to-blue-500",
      questions: [
        {
          q: "Fashion sense?",
          type: "choice",
          options: ["Very stylish/Trendy", "Classic style", "Casual/Comfortable", "Doesn't care much", "Whatever suits him"]
        },
        {
          q: "Grooming?",
          type: "choice",
          options: ["Very well-groomed", "Clean and neat", "Natural/Minimal effort", "Doesn't matter"]
        },
        {
          q: "Cologne/Fragrance?",
          type: "choice",
          options: ["Always smells amazing", "Occasional cologne", "Natural scent", "Doesn't wear fragrance"]
        },
        {
          q: "Accessories?",
          type: "choice",
          options: ["Watches and accessories", "Minimal accessories", "No accessories", "Whatever looks good"]
        },
        {
          q: "Shoe game?",
          type: "choice",
          options: ["Sneaker head", "Formal shoes", "Comfortable over style", "Mixed collection"]
        },
        {
          q: "Casual vs Formal?",
          type: "choice",
          options: ["Loves dressing up", "Casual most times", "Balanced wardrobe", "Comfort first"]
        },
        {
          q: "Tattoos?",
          type: "choice",
          options: ["Has tattoos (hot)", "Open to tattoos", "No tattoos preferred", "Doesn't matter"]
        },
        {
          q: "Piercings?",
          type: "choice",
          options: ["Has ear piercings", "No piercings", "Doesn't matter at all"]
        },
        {
          q: "Takes style advice?",
          type: "choice",
          options: ["Loves when I help", "Open to suggestions", "Has own style", "We shop together"]
        },
        {
          q: "Gym wear?",
          type: "choice",
          options: ["Stylish gym outfits", "Functional workout clothes", "Doesn't matter"]
        }
      ]
    },
    {
      name: "Physical Measurements",
      icon: "📏",
      gradient: "from-cyan-500 to-blue-500",
      questions: [
        {
          q: "Exact height range?",
          type: "choice",
          options: ["5'4\"-5'6\"", "5'7\"-5'8\"", "5'9\"-5'10\"", "5'11\"-6'0\"", "6'1\"-6'2\"", "6'3\"-6'4\"", "6'5\"+", "Shorter than me", "Same as me", "1-2 inches taller", "3-5 inches taller", "Much taller", "Any height"]
        },
        {
          q: "Weight/Build range?",
          type: "choice",
          options: ["Slim 50-60kg", "Lean 60-70kg", "Average 70-80kg", "Athletic 80-90kg", "Muscular 90-100kg", "Bulky 100kg+", "Underweight", "Dad bod", "Teddy bear", "Very fit", "Whatever suits height", "Doesn't matter"]
        },
        {
          q: "Chest/Shoulders?",
          type: "choice",
          options: ["Very broad shoulders", "Broad shoulders", "Average build", "Slim build", "Muscular chest", "Natural", "Swimmer build", "Athletic", "Strong upper body", "Proportional", "Doesn't matter"]
        },
        {
          q: "Arm build?",
          type: "choice",
          options: ["Very muscular arms", "Toned arms", "Average arms", "Slim arms", "Veiny arms", "Strong arms", "Natural", "Athletic", "Can lift me easily", "Lean arms", "Doesn't matter"]
        },
        {
          q: "Hand size/type?",
          type: "choice",
          options: ["Large hands", "Medium hands", "Long fingers", "Strong hands", "Soft hands", "Veiny hands", "Working hands", "Gentle hands", "Masculine hands", "Big enough for mine", "Doesn't matter"]
        },
        {
          q: "Jawline?",
          type: "choice",
          options: ["Sharp defined jaw", "Strong jawline", "Soft jawline", "Chiseled", "Natural jaw", "Round face", "Square jaw", "Beard hides it", "Model jaw", "Masculine", "Gentle features", "Doesn't matter"]
        },
        {
          q: "Body hair?",
          type: "choice",
          options: ["Very hairy", "Moderately hairy", "Some hair", "Smooth/Less hair", "Natural amount", "Manscaped", "Trimmed well", "Hairy chest is hot", "Waxed/Smooth", "Well groomed", "Whatever natural", "Doesn't matter"]
        },
        {
          q: "Muscle definition?",
          type: "choice",
          options: ["Very defined/Ripped", "Toned muscles", "Average", "Soft body", "Six pack abs", "V-line visible", "Natural muscle", "Dad bod fine", "Athletic build", "Gym body", "Regular guy", "Doesn't matter"]
        },
        {
          q: "Leg build?",
          type: "choice",
          options: ["Muscular legs", "Athletic legs", "Slim legs", "Average legs", "Runner legs", "Gym legs", "Natural legs", "Strong legs", "Proportional", "Skip leg day is okay", "Doesn't matter"]
        },
        {
          q: "Overall physique type?",
          type: "choice",
          options: ["Lean/Ectomorph", "Athletic/Mesomorph", "Stocky/Endomorph", "Swimmer body", "Runner body", "Gym body", "Natural build", "Strong not bulky", "Fit & healthy", "Balanced", "Any type"]
        }
      ]
    },
    {
      name: "Voice & Speech",
      icon: "🗣️",
      gradient: "from-purple-500 to-pink-500",
      questions: [
        {
          q: "Voice depth?",
          type: "choice",
          options: ["Very deep voice", "Deep voice", "Medium depth", "Higher pitched", "Baritone", "Bass", "Tenor", "Raspy voice", "Smooth voice", "Masculine deep", "Unique voice", "Doesn't matter"]
        },
        {
          q: "Speaking volume?",
          type: "choice",
          options: ["Loud speaker", "Moderate volume", "Soft spoken", "Varies by situation", "Projects well", "Gentle voice", "Strong voice", "Quiet talker", "Booming voice", "Normal volume", "Doesn't matter"]
        },
        {
          q: "Speaking pace?",
          type: "choice",
          options: ["Fast talker", "Moderate pace", "Slow deliberate", "Varies", "Quick speech", "Measured pace", "Rapid fire", "Takes his time", "Clear pace", "Energetic", "Calm speaker", "Doesn't matter"]
        },
        {
          q: "Accent?",
          type: "choice",
          options: ["Neutral accent", "Regional accent", "British accent", "American accent", "Indian accent", "Has accent", "International", "Local accent", "Posh accent", "No strong accent", "Unique accent", "Doesn't matter"]
        },
        {
          q: "Laugh type?",
          type: "choice",
          options: ["Loud laugh", "Hearty laugh", "Quiet chuckle", "Giggles", "Deep laugh", "Infectious laugh", "Silent laugh", "Snort laugh", "Belly laugh", "Reserved laugh", "Natural laugh", "Doesn't matter"]
        },
        {
          q: "Vocabulary level?",
          type: "choice",
          options: ["Extensive vocabulary", "Average words", "Simple speech", "Mix of both", "Educated speech", "Street smart talk", "Eloquent", "Casual speaker", "Professional vocab", "Natural speech", "Not pretentious", "Doesn't matter"]
        },
        {
          q: "Pet names usage?",
          type: "choice",
          options: ["Uses many pet names", "Few special ones", "Not much", "Never uses", "Creative names", "Classic names", "Unique nicknames", "Just my name", "Occasional", "Makes up names", "Standard ones", "Doesn't matter"]
        },
        {
          q: "Compliment style?",
          type: "choice",
          options: ["Very complimentary", "Occasional compliments", "Rare but meaningful", "Shy with compliments", "Specific compliments", "General praise", "Creative compliments", "Simple sweet words", "Actions over words", "Shows not tells", "Doesn't matter"]
        }
      ]
    },
    {
      name: "Intimacy & Romance",
      icon: "💑",
      gradient: "from-rose-500 to-pink-500",
      questions: [
        {
          q: "Physical intimacy importance?",
          type: "choice",
          options: ["Very important", "Moderately important", "Not top priority", "Balanced view", "Depends on connection", "After emotional bond", "Important for both", "Patient about it", "Open to discuss", "Respects boundaries", "Doesn't matter"]
        },
        {
          q: "Initiation style?",
          type: "choice",
          options: ["Takes lead often", "Both initiate equally", "Prefers I initiate", "Spontaneous approach", "Romantic lead-up", "Direct about it", "Subtle hints", "Asks first", "Reads the mood", "Respectful always", "Doesn't matter"]
        },
        {
          q: "Affection frequency?",
          type: "choice",
          options: ["Very affectionate always", "Moderate affection", "Not very touchy", "Depends on mood", "Private affection", "Public affection okay", "Cuddly type", "Respectful of space", "Shows in actions", "Balanced approach", "Doesn't matter"]
        },
        {
          q: "Kissing style?",
          type: "choice",
          options: ["Passionate intense", "Soft gentle", "Playful kisses", "Mix of all", "Slow and deep", "Quick pecks", "French kissing", "Forehead kisses", "Surprise kisses", "Romantic kisses", "Natural style", "Doesn't matter"]
        },
        {
          q: "Cuddling after?",
          type: "choice",
          options: ["Loves cuddling after", "Needs some space", "Sometimes cuddles", "Falls asleep", "Talks after", "Very affectionate", "Wants closeness", "Comfortable either way", "Asks what you need", "Stays close", "Doesn't matter"]
        },
        {
          q: "Communication about needs?",
          type: "choice",
          options: ["Very open talker", "A bit shy", "Doesn't discuss much", "Learning to communicate", "Direct and honest", "Gentle approach", "Asks about your needs", "Patient listener", "Respects boundaries", "Open to feedback", "Doesn't matter"]
        },
        {
          q: "Your pleasure priority?",
          type: "choice",
          options: ["Your pleasure first", "Mutual pleasure focus", "His pleasure focus", "Takes turns", "Cares deeply", "Asks what you like", "Attentive partner", "Learning together", "Generous lover", "Balanced approach", "Doesn't matter"]
        },
        {
          q: "Consent practices?",
          type: "choice",
          options: ["Always asks consent", "Respects boundaries", "Reads signals", "Verbal check-ins", "Understanding partner", "Never pushy", "Stops when asked", "Very respectful", "Communication first", "Safe and caring", "This is must-have"]
        },
        {
          q: "Morning or night person?",
          type: "choice",
          options: ["Morning intimacy", "Night time preferred", "Anytime works", "Spontaneous timing", "After coffee", "Before sleep", "Weekend mornings", "Whenever mood strikes", "Flexible timing", "Natural moments", "Doesn't matter"]
        },
        {
          q: "Experimentation openness?",
          type: "choice",
          options: ["Very adventurous", "Somewhat open", "Prefers comfort zone", "Depends on trust", "Willing to try", "Needs discussion", "Slow progression", "Your pace matters", "Respects limits", "Open communication", "Doesn't matter"]
        }
      ]
    },
    {
      name: "Conflict Resolution",
      icon: "🤝",
      gradient: "from-orange-500 to-red-500",
      questions: [
        {
          q: "During arguments?",
          type: "choice",
          options: ["Stays calm always", "Gets heated sometimes", "Needs space first", "Wants immediate resolution", "Listens first", "Defensive initially", "Wants to talk", "Walks away temporarily", "Tries to understand", "Emotional response", "Doesn't matter"]
        },
        {
          q: "Apologizing?",
          type: "choice",
          options: ["Quick to apologize", "Takes time to process", "Actions over words", "Struggles with it", "Genuine apologies", "Explains his side", "Admits fault", "Defensive about it", "Makes amends", "Words and actions", "Doesn't matter"]
        },
        {
          q: "Listening during fights?",
          type: "choice",
          options: ["Listens fully", "Interrupts sometimes", "Gets defensive", "Tries to understand", "Active listener", "Needs breaks", "Hears you out", "Wants to be heard", "Patient listener", "Fair listener", "Doesn't matter"]
        },
        {
          q: "Taking responsibility?",
          type: "choice",
          options: ["Takes full responsibility", "Blames both", "Blames you", "Avoids blame game", "Owns mistakes", "Makes excuses", "Reflective about it", "Defensive initially", "Growth-minded", "Fair assessment", "Doesn't matter"]
        },
        {
          q: "Resolution style?",
          type: "choice",
          options: ["Compromises easily", "Needs to win", "Finds middle ground", "Lets it go", "Problem solver", "Stubborn sometimes", "Fair solutions", "Your happiness matters", "Both sides win", "Mature approach", "Doesn't matter"]
        },
        {
          q: "Silent treatment?",
          type: "choice",
          options: ["Never does it", "Sometimes needs space", "Often goes silent", "Doesn't believe in it", "Communicates instead", "Processes alone", "Comes back to talk", "Shuts down", "Healthy space", "Never punishes", "Doesn't matter"]
        },
        {
          q: "Raising voice?",
          type: "choice",
          options: ["Never raises voice", "Sometimes when upset", "Often loud", "Depends on anger", "Stays calm", "Gets loud", "Controls volume", "Respectful tone", "Passionate but respectful", "Works on it", "Doesn't matter"]
        },
        {
          q: "Fighting fair?",
          type: "choice",
          options: ["Always fights fair", "Brings up past", "Low blows sometimes", "Stays on topic", "Respectful always", "Gets mean", "Mature fighting", "Personal attacks", "Rational approach", "Kind even angry", "Doesn't matter"]
        },
        {
          q: "Making up after?",
          type: "choice",
          options: ["Sweet gestures", "Needs time alone", "Pretends nothing happened", "Talks it through", "Affectionate after", "Space first then close", "Learns from it", "Quick to reconnect", "Stronger after", "Growth together", "Doesn't matter"]
        },
        {
          q: "Learning from fights?",
          type: "choice",
          options: ["Grows from them", "Repeats patterns", "Tries to improve", "Doesn't see issues", "Reflective partner", "Works on himself", "Listens to feedback", "Open to change", "Better each time", "Commits to growth", "Doesn't matter"]
        }
      ]
    },
    {
      name: "Money & Finances",
      icon: "💰",
      gradient: "from-green-500 to-emerald-500",
      questions: [
        {
          q: "Spending habits?",
          type: "choice",
          options: ["Big saver", "Big spender", "Balanced approach", "Impulsive buyer", "Calculated purchases", "Frugal type", "Generous spender", "Budget conscious", "Invests well", "Practical spender", "Doesn't matter"]
        },
        {
          q: "Financial planning?",
          type: "choice",
          options: ["Plans everything", "Casual planning", "Paycheck to paycheck", "Wealthy mindset", "Future focused", "Lives in present", "Investment minded", "Savings priority", "Building wealth", "Comfortable approach", "Doesn't matter"]
        },
        {
          q: "Paying on dates?",
          type: "choice",
          options: ["Always pays", "Splits bills", "Takes turns", "You pay sometimes", "Traditional approach", "Modern split", "Doesn't matter to him", "Whatever you prefer", "Generous always", "Fair approach", "Doesn't matter to me"]
        },
        {
          q: "Talking about money?",
          type: "choice",
          options: ["Very open", "Somewhat comfortable", "Avoids topic", "Practical discussions", "Private about it", "Shares finances", "Transparent", "Uncomfortable", "Mature about it", "Open when needed", "Doesn't matter"]
        },
        {
          q: "Financial goals?",
          type: "choice",
          options: ["Very ambitious", "Moderate goals", "Living in present", "Building wealth", "Retirement focused", "Investment goals", "Property goals", "Comfortable life", "Provide for family", "Balanced goals", "Doesn't matter"]
        },
        {
          q: "Investing?",
          type: "choice",
          options: ["Invests regularly", "Learning about it", "Doesn't invest", "Skeptical of it", "Stock market", "Real estate", "Crypto investor", "Savings only", "Diversified portfolio", "Growing investments", "Doesn't matter"]
        },
        {
          q: "Luxury purchases?",
          type: "choice",
          options: ["Loves luxury", "Practical buyer", "Doesn't care brands", "Balanced approach", "Quality matters", "Value focused", "Occasional splurge", "Minimalist", "Brand conscious", "Function over form", "Doesn't matter"]
        },
        {
          q: "Your financial independence?",
          type: "choice",
          options: ["Fully supports it", "Traditional provider view", "Wants to provide", "Balanced partnership", "Encourages career", "Equal financial partners", "Respects independence", "Team approach", "Modern mindset", "Supportive always", "Doesn't matter"]
        },
        {
          q: "Joint finances view?",
          type: "choice",
          options: ["Joint accounts", "Separate accounts", "Hybrid approach", "Haven't thought", "Transparent sharing", "Individual freedom", "Shared expenses", "Fair split", "Traditional joint", "Modern separate", "Doesn't matter"]
        },
        {
          q: "Generosity?",
          type: "choice",
          options: ["Very generous", "Selectively generous", "Not very generous", "Balanced giving", "Helps family", "Charitable", "Treats you often", "Fair with money", "Practical generosity", "Giving nature", "Doesn't matter"]
        }
      ]
    },
    {
      name: "Technology & Digital",
      icon: "📱",
      gradient: "from-blue-500 to-purple-500",
      questions: [
        {
          q: "Phone usage?",
          type: "choice",
          options: ["Always on phone", "Moderate usage", "Barely uses phone", "Balanced approach", "Addicted to phone", "Puts it away", "Present with you", "Checks occasionally", "Social media addict", "Minimal screen time", "Doesn't matter"]
        },
        {
          q: "Social media activity?",
          type: "choice",
          options: ["Very active", "Occasional poster", "Private account", "Doesn't use much", "Instagram active", "No social media", "Passive scroller", "Content creator", "Rare posts", "Lurker type", "Doesn't matter"]
        },
        {
          q: "Gaming habits?",
          type: "choice",
          options: ["Heavy gamer", "Casual gamer", "Mobile only", "Doesn't game", "Console gamer", "PC gamer", "Social gamer", "Competitive player", "Solo player", "Balanced gaming", "Doesn't matter"]
        },
        {
          q: "Tech savvy level?",
          type: "choice",
          options: ["Very techy", "Moderately tech aware", "Not techy", "Learns when needed", "IT professional", "Basic user", "Early adopter", "Gadget lover", "Practical user", "Tech curious", "Doesn't matter"]
        },
        {
          q: "Screen time before bed?",
          type: "choice",
          options: ["Scrolls before sleep", "No phones in bed", "Reads instead", "Watches content", "Falls asleep with phone", "Bedtime routine", "Charges away", "Last minute check", "Puts it down", "Flexible", "Doesn't matter"]
        },
        {
          q: "Digital detox?",
          type: "choice",
          options: ["Regularly unplugs", "Sometimes disconnects", "Never unplugs", "Doesn't believe in it", "Weekend detox", "Vacation mode", "Always connected", "Needs breaks", "Balanced approach", "Mindful usage", "Doesn't matter"]
        },
        {
          q: "Online privacy?",
          type: "choice",
          options: ["Very private", "Somewhat private", "Shares everything", "Careful online", "Public life", "Selective sharing", "Anonymous online", "Open book", "Secure habits", "Balanced privacy", "Doesn't matter"]
        },
        {
          q: "Texting in relationship?",
          type: "choice",
          options: ["Texts all day", "Normal communication", "Prefers calls", "Minimal texter", "Quick replies", "Long messages", "Voice notes", "GIF sender", "Emoji user", "Balanced texting", "Doesn't matter"]
        }
      ]
    },
    {
      name: "Household & Domestic",
      icon: "🏠",
      gradient: "from-yellow-500 to-orange-500",
      questions: [
        {
          q: "Cooking ability?",
          type: "choice",
          options: ["Great cook", "Decent cook", "Learning to cook", "Can't cook", "Doesn't want to cook", "Specializes in few dishes", "Experimental chef", "Follows recipes", "Natural talent", "Enjoys cooking", "Doesn't matter"]
        },
        {
          q: "Cleaning habits?",
          type: "choice",
          options: ["Very clean", "Moderately clean", "Messy", "Organized chaos", "Neat freak", "Cleans regularly", "Needs reminders", "Hires help", "Shared chores", "Does his part", "Doesn't matter"]
        },
        {
          q: "Laundry?",
          type: "choice",
          options: ["Does his own", "Needs help", "You do it", "Shares chores", "Knows how", "Learning", "Sends out", "Very organized", "Basic ability", "Team approach", "Doesn't matter"]
        },
        {
          q: "Grocery shopping?",
          type: "choice",
          options: ["Plans and shops", "Goes with you", "You handle it", "Orders online", "Makes lists", "Impulse buyer", "Practical shopper", "Enjoys it", "Hates it", "Shares task", "Doesn't matter"]
        },
        {
          q: "Home décor interest?",
          type: "choice",
          options: ["Loves decorating", "Has opinions", "Doesn't care", "Leaves to you", "Good taste", "Minimalist", "Maximalist", "Practical focus", "Creative ideas", "Collaborative", "Doesn't matter"]
        },
        {
          q: "Fixing things?",
          type: "choice",
          options: ["Handy around house", "Calls professionals", "Tries to fix", "Breaks more things", "DIY master", "YouTube learner", "Practical fixes", "Avoids it", "Competent fixer", "Team effort", "Doesn't matter"]
        },
        {
          q: "Plant care?",
          type: "choice",
          options: ["Has green thumb", "Kills plants", "Not interested", "You handle plants", "Tries his best", "Loves gardening", "Forgets to water", "Outdoor plants", "Indoor plants", "Learning", "Doesn't matter"]
        },
        {
          q: "Pet responsibilities?",
          type: "choice",
          options: ["Very responsible", "Needs reminders", "Not interested", "Loves animals", "Shares duties", "Primary caretaker", "Helps when asked", "Natural with pets", "Learning", "Eager to help", "Doesn't matter"]
        },
        {
          q: "Morning routine help?",
          type: "choice",
          options: ["Makes breakfast", "Helps get ready", "Sleeps in", "Independent mornings", "Coffee ready", "Supportive", "Does his thing", "Team routine", "Coordinates well", "Flexible", "Doesn't matter"]
        },
        {
          q: "Organization at home?",
          type: "choice",
          options: ["Very organized", "Moderately organized", "Chaotic", "Has system", "Marie Kondo level", "Piles everywhere", "Labels things", "Knows where stuff is", "Needs your help", "Getting better", "Doesn't matter"]
        }
      ]
    },
    {
      name: "Emotional Intelligence",
      icon: "❤️‍🩹",
      gradient: "from-pink-500 to-rose-500",
      questions: [
        {
          q: "Handles his emotions?",
          type: "choice",
          options: ["Very self-aware", "Learning about them", "Suppresses emotions", "Expresses freely", "Healthy processing", "Bottles up", "Talks about feelings", "Private with emotions", "Working on it", "Emotionally mature", "Doesn't matter"]
        },
        {
          q: "Therapy views?",
          type: "choice",
          options: ["Goes to therapy", "Open to therapy", "Skeptical of it", "Doesn't believe in it", "Tried therapy", "Recommends it", "Stigma around it", "Mental health aware", "Would go if needed", "Supports therapy", "Doesn't matter"]
        },
        {
          q: "Stress management?",
          type: "choice",
          options: ["Healthy coping", "Unhealthy habits", "Talks it out", "Bottles up", "Exercise helps", "Meditation", "Needs space", "Vents feelings", "Manages well", "Struggles with it", "Doesn't matter"]
        },
        {
          q: "Crying comfort?",
          type: "choice",
          options: ["Comfortable crying", "Cries alone", "Rarely cries", "Never cries", "Emotional expression", "Holds back", "With safe people", "Not ashamed", "Toxic masculinity", "Healthy expression", "Doesn't matter"]
        },
        {
          q: "Mental health priority?",
          type: "choice",
          options: ["Very important", "Somewhat important", "Not really", "Learning importance", "Top priority", "Works on it", "Struggles with it", "Supportive of yours", "Growing awareness", "Balanced approach", "Doesn't matter"]
        },
        {
          q: "Supporting your mental health?",
          type: "choice",
          options: ["Very supportive", "Tries his best", "Doesn't understand", "Learning to support", "Always there", "Gives space", "Listens well", "Takes it seriously", "Educating himself", "Compassionate", "Doesn't matter"]
        },
        {
          q: "Anxiety understanding?",
          type: "choice",
          options: ["Understands anxiety", "Patient with it", "Doesn't get it", "Tries to fix it", "Has anxiety too", "Researches it", "Supportive always", "Learns your triggers", "Calming presence", "Growing understanding", "Doesn't matter"]
        },
        {
          q: "Emotional availability?",
          type: "choice",
          options: ["Very available", "Sometimes available", "Walls up", "Working on it", "Open heart", "Guarded", "Depends on trust", "Growing availability", "Emotionally present", "Trying to be", "Doesn't matter"]
        },
        {
          q: "Empathy level?",
          type: "choice",
          options: ["Highly empathetic", "Moderately empathetic", "Not very empathetic", "Learning empathy", "Feels deeply", "Logical thinker", "Compassionate", "Understands others", "Growing empathy", "Natural empathy", "Doesn't matter"]
        },
        {
          q: "Self-care routine?",
          type: "choice",
          options: ["Has self-care routine", "Learning self-care", "Doesn't have routine", "Thinks it's unnecessary", "Mental health days", "Physical self-care", "Emotional self-care", "Balanced approach", "Building habits", "Values it", "Doesn't matter"]
        }
      ]
    },
    {
      name: "Future Planning",
      icon: "🔮",
      gradient: "from-purple-500 to-indigo-500",
      questions: [
        {
          q: "Marriage thoughts?",
          type: "choice",
          options: ["Wants marriage", "Open to marriage", "Not interested", "Eventually yes", "Traditional views", "Modern views", "When right person", "No rush", "Life goal", "Flexible about it", "Doesn't matter"]
        },
        {
          q: "Kids desire?",
          type: "choice",
          options: ["Definitely wants kids", "Maybe someday", "Doesn't want kids", "Open to discussion", "Loves children", "Not a kid person", "2-3 kids", "Just one", "Adopt maybe", "Partner's choice", "Doesn't matter"]
        },
        {
          q: "Where to live?",
          type: "choice",
          options: ["Big city life", "Small town", "Suburb life", "Move abroad", "Hometown", "Flexible location", "Career dependent", "Where you want", "Adventurous", "Settled place", "Doesn't matter"]
        },
        {
          q: "Career ambition?",
          type: "choice",
          options: ["Very career focused", "Work-life balance", "Career isn't priority", "Climbing ladder", "Entrepreneur dreams", "Stable job", "Passion over money", "Building empire", "Moderate ambition", "Flexible goals", "Doesn't matter"]
        },
        {
          q: "Retirement plans?",
          type: "choice",
          options: ["Early retirement goal", "Standard age", "Never retire", "Travel retirement", "Financial freedom", "Work forever", "Haven't thought", "Planning ahead", "Living in present", "Building nest egg", "Doesn't matter"]
        },
        {
          q: "Adventure vs stability?",
          type: "choice",
          options: ["Adventure seeker", "Stability seeker", "Balanced both", "Risk taker", "Plays it safe", "Calculated risks", "Spontaneous life", "Planned life", "Flexible approach", "Changes with age", "Doesn't matter"]
        },
        {
          q: "Pet plans?",
          type: "choice",
          options: ["Definitely wants pets", "Maybe pets", "No pets", "Dog person", "Cat person", "Multiple pets", "Exotic pets", "When settled", "Allergic", "Your choice", "Doesn't matter"]
        },
        {
          q: "Home ownership?",
          type: "choice",
          options: ["Dream house goal", "Apartment life", "Rent forever", "Investment property", "Multiple properties", "Villa dream", "Penthouse", "Farmhouse", "Simple home", "Wherever together", "Doesn't matter"]
        },
        {
          q: "Aging together?",
          type: "choice",
          options: ["Growing old together", "Forever partners", "Life companions", "Retirement dreams", "Travel when old", "Grandkids dreams", "Active aging", "Peaceful aging", "Together always", "Beautiful future", "This matters most"]
        },
        {
          q: "Legacy importance?",
          type: "choice",
          options: ["Leave a legacy", "Make impact", "Private life", "Fame goals", "Wealth building", "Family legacy", "Helping others", "Personal fulfillment", "Doesn't think about it", "Balanced view", "Doesn't matter"]
        }
      ]
    },
    {
      name: "Daily Micro-Habits",
      icon: "🔍",
      gradient: "from-teal-500 to-cyan-500",
      questions: [
        {
          q: "Morning breath?",
          type: "choice",
          options: ["Brushes immediately", "Doesn't care", "Morning kiss anyway", "Coffee first", "Always has mints", "Self-conscious", "Quick rinse", "Avoids until brushed", "Doesn't bother him", "We both don't care", "Doesn't matter"]
        },
        {
          q: "Toilet seat?",
          type: "choice",
          options: ["Always puts down", "Forgets sometimes", "Never puts down", "Very conscious", "Needs reminders", "Good habit", "Learning", "Respectful", "Considerate", "Working on it", "Doesn't matter"]
        },
        {
          q: "Toothpaste squeezing?",
          type: "choice",
          options: ["Bottom squeezer", "Middle squeezer", "Doesn't care", "Separate tubes", "Very particular", "Organized", "Messy", "Whatever works", "Neat habits", "Casual about it", "Doesn't matter"]
        },
        {
          q: "Bed side preference?",
          type: "choice",
          options: ["Has preferred side", "Either side fine", "Takes your side", "Left side", "Right side", "Switches around", "Lets you choose", "Particular about it", "Flexible", "Gentleman", "Doesn't matter"]
        },
        {
          q: "Pillow count needs?",
          type: "choice",
          options: ["One pillow", "Two pillows", "Many pillows", "Minimal", "Specific pillow", "Body pillow", "Just functional", "Whatever's there", "Brings own pillow", "Hotel pillows fine", "Doesn't matter"]
        },
        {
          q: "Blanket sharing?",
          type: "choice",
          options: ["Shares nicely", "Blanket hog", "Separate blankets", "Gives you most", "Pulls blankets", "Wraps in blanket", "Overheats", "Always cold", "Fair sharing", "Needs own blanket", "Doesn't matter"]
        },
        {
          q: "Room temperature?",
          type: "choice",
          options: ["Always cold", "Always hot", "Just right", "AC on always", "Heater needed", "Windows open", "Natural temp", "Layered clothing", "Adaptable", "Specific temp", "Doesn't matter"]
        },
        {
          q: "Socks to bed?",
          type: "choice",
          options: ["Always wears socks", "Never wears socks", "Sometimes", "Winter only", "Hates socks", "Must wear", "One sock", "Takes off at night", "Depends on cold", "Forgets to remove", "Doesn't matter"]
        },
        {
          q: "Shower length?",
          type: "choice",
          options: ["Quick 5 minutes", "10-15 minutes", "20-30 minutes", "Long showers", "Depends on day", "Military quick", "Enjoys showers", "Water conscious", "Relaxation time", "Efficient", "Doesn't matter"]
        },
        {
          q: "Dishes immediately?",
          type: "choice",
          options: ["Washes immediately", "Leaves for later", "Dishwasher", "Soaks first", "Piles up", "Very prompt", "Needs reminders", "Shares task", "Procrastinates", "Getting better", "Doesn't matter"]
        },
        {
          q: "Leaves drawer/cabinet open?",
          type: "choice",
          options: ["Always closes", "Sometimes leaves open", "Often leaves open", "Very organized", "Forgetful", "Conscious of it", "Working on it", "Drives you crazy", "Neat habits", "Casual", "Doesn't matter"]
        },
        {
          q: "Puts cap back on toothpaste?",
          type: "choice",
          options: ["Always caps it", "Forgets sometimes", "Never caps", "Very neat", "Messy", "Conscious", "Needs reminders", "Good habits", "Working on it", "Casual", "Doesn't matter"]
        }
      ]
    },
    {
      name: "Spiritual & Philosophy",
      icon: "🧘",
      gradient: "from-purple-500 to-pink-500",
      questions: [
        {
          q: "Spiritual beliefs?",
          type: "choice",
          options: ["Very spiritual", "Somewhat spiritual", "Not spiritual", "Exploring spirituality", "Religious", "Atheist", "Agnostic", "Respects all beliefs", "Private beliefs", "Open-minded", "Doesn't matter"]
        },
        {
          q: "Meditation practice?",
          type: "choice",
          options: ["Meditates regularly", "Occasionally meditates", "Tried it", "Not interested", "Daily practice", "Morning meditation", "Mindfulness", "Guided meditation", "Learning", "Open to it", "Doesn't matter"]
        },
        {
          q: "Life philosophy?",
          type: "choice",
          options: ["Optimistic view", "Realistic view", "Philosophical thinker", "Doesn't think about it", "Positive mindset", "Practical approach", "Deep thinker", "Live in moment", "Future focused", "Balanced view", "Doesn't matter"]
        },
        {
          q: "Karma belief?",
          type: "choice",
          options: ["Strongly believes", "Somewhat believes", "Doesn't believe", "Makes own destiny", "What goes around", "Coincidences", "Universal law", "Personal responsibility", "Spiritual view", "Open-minded", "Doesn't matter"]
        },
        {
          q: "Fate vs free will?",
          type: "choice",
          options: ["Believes in fate", "Free will", "Both", "Doesn't think about it", "Destiny believer", "Self-determination", "Written in stars", "We choose", "Balanced belief", "Open perspective", "Doesn't matter"]
        },
        {
          q: "Purpose seeking?",
          type: "choice",
          options: ["Has clear purpose", "Finding purpose", "Purpose isn't priority", "Multiple purposes", "Career is purpose", "Family is purpose", "Making impact", "Personal growth", "Still exploring", "Content as is", "Doesn't matter"]
        },
        {
          q: "Mindfulness?",
          type: "choice",
          options: ["Practices mindfulness", "Trying to practice", "Not really", "Doesn't know about it", "Daily practice", "When stressed", "Aware of moment", "Distracted", "Learning", "Growing practice", "Doesn't matter"]
        },
        {
          q: "Personal growth focus?",
          type: "choice",
          options: ["Constantly growing", "Occasionally grows", "Satisfied as is", "Growing with you", "Self-improvement", "Reading books", "Taking courses", "Therapy/coaching", "Natural growth", "Intentional growth", "Doesn't matter"]
        }
      ]
    },
    {
      name: "Social Media & Posting",
      icon: "📸",
      gradient: "from-pink-500 to-purple-500",
      questions: [
        {
          q: "Posts about relationship?",
          type: "choice",
          options: ["Shows off proudly", "Occasional posts", "Very private", "Doesn't post at all", "Story posts", "Grid posts", "Special occasions", "Respects your privacy", "Asks before posting", "Balanced approach", "Doesn't matter"]
        },
        {
          q: "Couple photos?",
          type: "choice",
          options: ["Loves couple photos", "Occasionally", "Hates photos", "For you only", "Private photos", "Public photos", "Professional shoots", "Candid only", "Special moments", "Your choice", "Doesn't matter"]
        },
        {
          q: "Tags you online?",
          type: "choice",
          options: ["Tags you often", "Sometimes tags", "Never tags", "Asks permission", "Proud to show", "Private about it", "Only good photos", "Funny tags", "Romantic tags", "Respects privacy", "Doesn't matter"]
        },
        {
          q: "Online presence of you two?",
          type: "choice",
          options: ["Very public couple", "Somewhat public", "Very private", "Off social media", "Instagram official", "Facebook official", "Keep it private", "Close friends only", "Public but classy", "Your preference", "Doesn't matter"]
        },
        {
          q: "Comments on your posts?",
          type: "choice",
          options: ["Always comments", "Sometimes comments", "Likes only", "Private messages", "Supportive comments", "Funny comments", "Sweet comments", "Doesn't comment much", "Subtle support", "However you want", "Doesn't matter"]
        },
        {
          q: "Female followers/following?",
          type: "choice",
          options: ["Mostly guys", "Balanced following", "Follows many girls", "Unfollows for you", "Doesn't follow models", "Just friends", "Professional only", "Transparent about it", "Respects boundaries", "Open communication", "Doesn't matter"]
        },
        {
          q: "Likes on girls' posts?",
          type: "choice",
          options: ["Doesn't like", "Occasional likes", "Likes often", "Only friends", "Respectful liking", "Stopped for you", "Transparent", "Doesn't think about it", "Mindful of you", "Sets boundaries", "Doesn't matter"]
        },
        {
          q: "Relationship status display?",
          type: "choice",
          options: ["In bio", "Not displayed", "Doesn't matter to him", "Proud to show", "Private info", "Eventually will", "Asks your preference", "Instagram official", "Facebook official", "Your choice", "Doesn't matter to me"]
        }
      ]
    },
    {
      name: "Situational Scenarios",
      icon: "🎭",
      gradient: "from-orange-500 to-red-500",
      questions: [
        {
          q: "If you're sad, he should...",
          type: "choice",
          options: ["Give space first, then comfort", "Immediately hug and comfort", "Try to make you laugh", "Listen without fixing", "Ask what you need", "Distract with activities", "Be present silently", "Problem-solve together"]
        },
        {
          q: "If he's stressed about work/school, you want him to...",
          type: "choice",
          options: ["Tell me everything", "Just say he's stressed", "Handle it himself", "Let me help", "Take space but tell me", "Vent when ready", "Share when it's over"]
        },
        {
          q: "If you both fight, he should...",
          type: "choice",
          options: ["Apologize first always", "Listen to my side fully", "Take time then talk", "Never go to bed angry", "Give space if needed", "Compromise immediately", "Write feelings down", "Talk it through calmly"]
        },
        {
          q: "If someone flirts with you, he should...",
          type: "choice",
          options: ["Trust me completely", "Feel jealous (cute)", "Mark territory politely", "Not care at all", "Be protective", "Laugh it off", "Trust but verify", "Communicate feelings"]
        },
        {
          q: "If you're sick, ideal response?",
          type: "choice",
          options: ["Cancel everything for me", "Check in frequently", "Give medicine reminders", "Come take care of me", "Send food/supplies", "Video call to check", "Respect if I need rest", "Balance care and space"]
        },
        {
          q: "If you achieve something big...",
          type: "choice",
          options: ["Celebrate it grandly", "Be prouder than me", "Share with everyone", "Intimate celebration", "Plan surprise party", "Simple but meaningful", "Post about it", "Whatever I want"]
        },
        {
          q: "If he forgets important date...",
          type: "choice",
          options: ["Forgive immediately", "Expect grand apology", "Give him chance", "It hurts but understand", "Never forget himself", "System to remember", "Gentle reminder okay", "Won't let it happen"]
        },
        {
          q: "If you're insecure about something...",
          type: "choice",
          options: ["Reassure constantly", "Help build confidence", "Never joke about it", "Address seriously", "Make me feel better", "Take time to understand", "Extra affection", "Action not just words"]
        },
        {
          q: "If families don't approve initially...",
          type: "choice",
          options: ["Fight for us", "Try to win them", "Give time for approval", "Convince with actions", "Priority is us", "Respect but persist", "Work together", "Patient approach"]
        },
        {
          q: "If long distance happens...",
          type: "choice",
          options: ["Daily video calls", "Constant texts", "Regular visits", "Trust and independence", "Scheduled calls", "Surprise visits", "Extra effort", "Strong communication"]
        },
        {
          q: "If you want space during tough time...",
          type: "choice",
          options: ["Give space readily", "Check in occasionally", "Worried but respects", "Hard but will do", "Asks for timeline", "Available when ready", "Trust the process", "Balance check-ins"]
        },
        {
          q: "If he meets your ex accidentally...",
          type: "choice",
          options: ["Be polite", "Be protective", "Stay calm", "Show you're his", "Trust completely", "Slightly jealous", "Doesn't care", "Confident approach"]
        },
        {
          q: "If you're working late...",
          type: "choice",
          options: ["Stay up with me", "Bring me food", "Understanding", "Video call break", "Wait for me", "Trust completely", "Regular check-ins", "Support my work"]
        },
        {
          q: "If he has female friends...",
          type: "choice",
          options: ["I should know them", "Clear boundaries set", "No private hangouts", "Trust completely", "Group hangouts only", "Transparency always", "My comfort first", "Balanced friendship"]
        },
        {
          q: "If you're crying...",
          type: "choice",
          options: ["Hold me tight", "Ask what's wrong", "Cry with me", "Silent support", "Fix the problem", "Just be present", "Comfort words", "Whatever I need"]
        },
        {
          q: "If both parents want different things...",
          type: "choice",
          options: ["Support me always", "Find middle ground", "Prioritize us", "Respect both sides", "Communicate clearly", "Stand with me", "Diplomatic approach", "Case by case"]
        },
        {
          q: "If you make a mistake...",
          type: "choice",
          options: ["Forgive easily", "Expect real apology", "Talk through it", "Give one chance", "Understand mistakes happen", "Depends on mistake", "Growth focused", "Honest conversation"]
        },
        {
          q: "If he's complimented by others...",
          type: "choice",
          options: ["He thanks and moves on", "Mentions me immediately", "Humble about it", "Accepts gracefully", "Doesn't care", "Makes clear he's taken", "Depends on context", "Handles well"]
        },
        {
          q: "If you need him at 3 AM...",
          type: "choice",
          options: ["Answers immediately", "Wakes up for me", "Emergency or can wait?", "Always available", "Responds ASAP", "No questions asked", "There for me", "Prioritizes me"]
        },
        {
          q: "If you're having period pain...",
          type: "choice",
          options: ["Understands completely", "Brings supplies", "Gives space/comfort", "Heating pad ready", "Doesn't joke about it", "Takes care of me", "Extra patient", "Very supportive"]
        },
        {
          q: "If his friends don't like you...",
          type: "choice",
          options: ["You're priority", "Tries to fix it", "Stands by me", "We work on it", "His choice is me", "Respectful approach", "Doesn't affect us", "Values my feelings"]
        },
        {
          q: "If you want to try something new...",
          type: "choice",
          options: ["Supports immediately", "Encourages it", "Asks questions", "Joins if possible", "Excited for me", "Whatever makes me happy", "Helps me try", "Fully supportive"]
        },
        {
          q: "If he has to cancel plans...",
          type: "choice",
          options: ["Valid reason always", "Reschedules immediately", "Apologizes sincerely", "Rarely happens", "Makes it up", "Communicates early", "Genuine emergency only", "Feels bad about it"]
        },
        {
          q: "If someone criticizes you...",
          type: "choice",
          options: ["Defends immediately", "Talks to them", "Comforts me", "Stands up for me", "Addresses it", "Makes me feel better", "Won't tolerate it", "Protective approach"]
        },
        {
          q: "If you're overwhelmed with life...",
          type: "choice",
          options: ["Takes some load off", "Just listens", "Helps practically", "Emotional support", "Plans something relaxing", "Whatever I need", "Present and helpful", "Reduces my stress"]
        },
        {
          q: "If you disagree on something big...",
          type: "choice",
          options: ["Respects opinion", "Finds compromise", "Talks it through", "Your happiness matters", "Hear each other out", "Rational discussion", "Priority is us", "Work together"]
        },
        {
          q: "If his past relationship is mentioned...",
          type: "choice",
          options: ["Honest but brief", "Doesn't compare", "Over the past", "Only if I ask", "Transparent", "Respectful of both", "Focuses on us", "Not hidden"]
        },
        {
          q: "If you need motivation/push...",
          type: "choice",
          options: ["Encourages strongly", "Believes in me", "Gentle pushing", "Supports my pace", "Cheerleader mode", "Whatever I need", "Motivates positively", "Balances push/support"]
        },
        {
          q: "If finances are tight...",
          type: "choice",
          options: ["Plans together", "Still makes effort", "Honest about it", "Creative dates", "Team approach", "No pressure", "Works through it", "Love over money"]
        },
        {
          q: "If you're jealous about something...",
          type: "choice",
          options: ["Reassures immediately", "Shows extra love", "Addresses concern", "Makes me priority", "Never gives reason", "Understanding", "Proves loyalty", "Communicates clearly"]
        },
        {
          q: "If you're angry at him...",
          type: "choice",
          options: ["Gives space then talks", "Apologizes if wrong", "Hears me out", "Works to fix it", "Patient with me", "Doesn't get defensive", "Mature approach", "Resolves properly"]
        },
        {
          q: "If he needs to grow/change something...",
          type: "choice",
          options: ["Open to feedback", "Works on himself", "Takes it seriously", "Growth mindset", "Asks how to improve", "Self-aware", "Wants to be better", "Humble about it"]
        },
        {
          q: "If you're celebrated by others...",
          type: "choice",
          options: ["Proudest person there", "Celebrates with me", "Shares my joy", "Tells everyone", "Supports publicly", "Genuine happiness", "My biggest fan", "Truly happy for me"]
        },
        {
          q: "If wedding planning disagreements...",
          type: "choice",
          options: ["Your day priority", "Compromise on everything", "Open discussion", "Both happy", "Family considerations", "Budget aware", "Flexible approach", "Team decisions"]
        },
        {
          q: "If future career requires moving...",
          type: "choice",
          options: ["Supports my dreams", "Finds solution together", "Willing to move", "Career for career", "Plans together", "Prioritizes us", "Creative solutions", "Mutual support"]
        }
      ]
    }
  ];

  const handleAnswer = (questionIndex: number, answer: string) => {
    const key = `${currentCategory}-${questionIndex}`;
    setAnswers(prev => ({ ...prev, [key]: answer }));
  };

  const totalQuestions = categories.reduce((acc, cat) => acc + cat.questions.length, 0);
  const answeredQuestions = Object.keys(answers).length;
  const progress = (answeredQuestions / totalQuestions) * 100;

  return (
    <SectionInner>
      <GlowOrb color="blue" className="top-20 right-10" />
      <GlowOrb color="cyan" className="bottom-20 left-10" />
      
      <div className="max-w-5xl mx-auto relative z-10">
        <SectionHeader 
          emoji="👨" 
          title="Design Your Dream Boy" 
          subtitle="Create him exactly the way you want — every single detail matters"
        />
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-10"
        >
          <p className="text-white/40 text-base max-w-3xl mx-auto leading-relaxed mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>
            I want to know everything about the person who'd make your heart skip a beat. 
            Don't hold back — be completely honest. This is your chance to design your perfect someone, 
            and I promise I'll never judge. I just want to understand what makes you happy.
          </p>
          <p className="text-pink-400/60 text-sm italic">
            {totalQuestions} questions across {categories.length} categories
          </p>
        </motion.div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-white/30 text-sm">Progress</span>
            <span className="text-pink-400 text-sm font-medium">{answeredQuestions}/{totalQuestions}</span>
          </div>
          <div className="h-2 bg-white/5 rounded-full overflow-hidden">
            <motion.div 
              className="h-full bg-gradient-to-r from-pink-500 to-purple-500"
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.5 }}
            />
          </div>
        </div>

        {/* Category Navigation */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3 mb-10">
          {categories.map((cat, idx) => (
            <motion.button
              key={idx}
              onClick={() => setCurrentCategory(idx)}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className={`p-4 rounded-2xl border transition-all duration-300 ${
                currentCategory === idx
                  ? `bg-gradient-to-br ${cat.gradient} border-white/20 shadow-[0_0_30px_rgba(255,45,138,0.2)]`
                  : "bg-white/[0.02] border-white/[0.06] hover:border-white/[0.12]"
              }`}
            >
              <div className="text-3xl mb-2">{cat.icon}</div>
              <div className="text-xs font-medium text-white/70">{cat.name}</div>
              <div className="text-[10px] text-white/40 mt-1">
                {categories[idx].questions.filter((_, qIdx) => answers[`${idx}-${qIdx}`]).length}/{categories[idx].questions.length}
              </div>
            </motion.button>
          ))}
        </div>

        {/* Questions */}
        <div className="space-y-6">
          <motion.div
            key={currentCategory}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3 }}
          >
            <h3 className={`text-2xl font-bold mb-8 bg-gradient-to-r ${categories[currentCategory].gradient} bg-clip-text text-transparent`}>
              {categories[currentCategory].icon} {categories[currentCategory].name}
            </h3>
            
            {categories[currentCategory].questions.map((question, qIdx) => (
              <motion.div
                key={qIdx}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: qIdx * 0.05 }}
                className="mb-8 p-6 rounded-2xl bg-white/[0.02] border border-white/[0.06] hover:border-white/[0.12] transition-all"
              >
                <h4 className="text-white/90 font-medium mb-4 text-lg">
                  {qIdx + 1}. {question.q}
                </h4>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                    {question.options.map((option, oIdx) => {
                    const key = `${currentCategory}-${qIdx}`;
                    const selectedAnswers = answers[key] || [];
                    const isSelected = selectedAnswers.includes(option);
                    
                    return (
                      <motion.button
                        key={oIdx}
                        onClick={() => handleAnswer(qIdx, option)}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        className={`p-4 rounded-xl text-left transition-all duration-300 ${
                          isSelected
                            ? `bg-gradient-to-r ${categories[currentCategory].gradient} text-white shadow-[0_0_20px_rgba(255,45,138,0.3)]`
                            : "bg-white/[0.03] border border-white/[0.08] text-white/60 hover:bg-white/[0.06] hover:border-white/[0.15] hover:text-white/80"
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-all ${
                            isSelected ? "border-white bg-white/20" : "border-white/20"
                          }`}>
                            {isSelected && (
                              <motion.svg
                                initial={{ scale: 0 }}
                                animate={{ scale: 1 }}
                                className="w-4 h-4 text-white"
                                fill="none"
                                stroke="currentColor"
                                viewBox="0 0 24 24"
                              >
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                              </motion.svg>
                            )}
                          </div>
                          <span className="text-sm font-medium">{option}</span>
                        </div>
                      </motion.button>
                    );
                  })}
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between mt-10">
          <button
            onClick={() => setCurrentCategory(Math.max(0, currentCategory - 1))}
            disabled={currentCategory === 0}
            className="px-6 py-3 rounded-xl bg-white/[0.05] border border-white/[0.1] text-white/60 disabled:opacity-30 disabled:cursor-not-allowed hover:bg-white/[0.08] transition-all"
          >
            ← Previous
          </button>
          
          <button
            onClick={() => {
              if (currentCategory < categories.length - 1) {
                setCurrentCategory(currentCategory + 1);
              } else {
                setShowResults(true);
              }
            }}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-pink-500 to-purple-500 text-white font-medium shadow-[0_0_30px_rgba(255,45,138,0.3)] hover:shadow-[0_0_40px_rgba(255,45,138,0.5)] transition-all"
          >
            {currentCategory < categories.length - 1 ? "Next →" : "View My Design"}
          </button>
        </div>

        {/* Results Modal */}
        <AnimatePresence>
          {showResults && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-dark-950/95 backdrop-blur-xl"
              onClick={() => setShowResults(false)}
            >
              <motion.div
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.9, y: 20 }}
                onClick={(e) => e.stopPropagation()}
                className="max-w-2xl w-full bg-gradient-to-br from-dark-900 to-dark-950 rounded-3xl p-8 border border-white/10 max-h-[80vh] overflow-y-auto"
              >
                <div className="text-center mb-6">
                  <div className="text-6xl mb-4">💖</div>
                  <h3 className="text-3xl font-bold bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent mb-2">
                    Thank You
                  </h3>
                  <p className="text-white/50">
                    You've answered {answeredQuestions} out of {totalQuestions} questions
                  </p>
                </div>
                
                <div className="space-y-4 mb-6">
                  <p className="text-white/70 leading-relaxed" style={{ fontFamily: "'Playfair Display', serif" }}>
                    Every answer you gave me is precious. I now understand a bit more about what makes your heart happy. 
                    Thank you for being honest and open with me. This means more than you know. 💕
                  </p>
                  <p className="text-pink-400/70 text-sm italic text-center">
                    "Understanding you is understanding how to love you better"
                  </p>
                </div>
                
                <button
                  onClick={() => setShowResults(false)}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-pink-500 to-purple-500 text-white font-medium"
                >
                  Close
                </button>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </SectionInner>
  );
}

function KnowYouContent() {
  const [currentCategory, setCurrentCategory] = useState(0);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [showResults, setShowResults] = useState(false);

  const categories = [
    {
      name: "Food & Drinks",
      icon: "🍕",
      gradient: "from-orange-500 to-red-500",
      questions: [
        {
          q: "Favorite cuisine?",
          type: "choice",
          options: ["Indian", "Italian", "Chinese", "Mexican", "Thai", "Japanese", "Continental", "Mix of everything"]
        },
        {
          q: "Spice level?",
          type: "choice",
          options: ["Love spicy food", "Medium spice", "Mild preferred", "No spice at all"]
        },
        {
          q: "Sweet or Savory?",
          type: "choice",
          options: ["Sweet tooth!", "Savory person", "Both equally", "Depends on mood"]
        },
        {
          q: "Favorite sweet?",
          type: "choice",
          options: ["Chocolate", "Ice cream", "Cake", "Indian sweets", "Pastries", "Candies", "Fruits", "All sweets!"]
        },
        {
          q: "Coffee or Tea?",
          type: "choice",
          options: ["Coffee lover", "Tea person", "Both", "Neither", "Depends on time"]
        },
        {
          q: "Breakfast preference?",
          type: "choice",
          options: ["Heavy breakfast", "Light breakfast", "Just coffee", "Skip breakfast", "Brunch person"]
        },
        {
          q: "Street food?",
          type: "choice",
          options: ["Love street food", "Occasionally", "Not a fan", "Hygiene matters"]
        },
        {
          q: "Favorite snack?",
          type: "choice",
          options: ["Chips", "Chocolate", "Fruits", "Namkeen", "Cookies", "Healthy snacks", "Anything tasty"]
        },
        {
          q: "Pizza toppings?",
          type: "choice",
          options: ["Margherita", "Pepperoni", "Veggie", "Loaded", "Plain cheese", "Unique toppings"]
        },
        {
          q: "Trying new foods?",
          type: "choice",
          options: ["Adventurous eater", "Sometimes try new", "Stick to favorites", "Very picky"]
        }
      ]
    },
    {
      name: "Entertainment",
      icon: "🎬",
      gradient: "from-purple-500 to-pink-500",
      questions: [
        {
          q: "Favorite movie genre?",
          type: "choice",
          options: ["Romance", "Action", "Comedy", "Horror", "Thriller", "Drama", "Sci-Fi", "Fantasy", "Mix of all"]
        },
        {
          q: "Series or Movies?",
          type: "choice",
          options: ["Long series", "Movies", "Both equally", "Short series", "Anime"]
        },
        {
          q: "Favorite music genre?",
          type: "choice",
          options: ["Bollywood", "Pop", "Rock", "Hip-Hop/Rap", "Classical", "EDM", "Indie", "Everything"]
        },
        {
          q: "Book reader?",
          type: "choice",
          options: ["Bookworm", "Occasional reader", "Specific genres", "Not into reading", "Audiobooks"]
        },
        {
          q: "Favorite book genre?",
          type: "choice",
          options: ["Romance", "Fiction", "Mystery/Thriller", "Fantasy", "Self-help", "Biography", "Poetry", "Don't read much"]
        },
        {
          q: "Gaming?",
          type: "choice",
          options: ["Love gaming", "Casual gamer", "Mobile games", "Not into games", "Watch others play"]
        },
        {
          q: "YouTube or Netflix?",
          type: "choice",
          options: ["YouTube always", "Netflix binger", "Both equally", "Other platforms", "Don't watch much"]
        },
        {
          q: "Podcasts?",
          type: "choice",
          options: ["Love podcasts", "Occasionally", "Specific topics", "Not my thing"]
        },
        {
          q: "Concerts/Live shows?",
          type: "choice",
          options: ["Love concerts", "Would go for favorite artist", "Not interested", "Small gigs preferred"]
        },
        {
          q: "Binge-watching?",
          type: "choice",
          options: ["Binge whole series", "Few episodes at time", "One episode daily", "Not a binge-watcher"]
        }
      ]
    },
    {
      name: "Fashion & Style",
      icon: "👗",
      gradient: "from-pink-500 to-rose-500",
      questions: [
        {
          q: "Fashion style?",
          type: "choice",
          options: ["Trendy/Fashion-forward", "Classic/Timeless", "Casual/Comfortable", "Bohemian", "Sporty", "Mix of everything"]
        },
        {
          q: "Favorite color to wear?",
          type: "choice",
          options: ["Black", "White", "Pastels", "Bright colors", "Earth tones", "All colors"]
        },
        {
          q: "Dresses or Jeans?",
          type: "choice",
          options: ["Love dresses", "Jeans person", "Both equally", "Traditional wear", "Skirts", "Whatever's comfortable"]
        },
        {
          q: "Makeup?",
          type: "choice",
          options: ["Full glam", "Natural/Minimal", "No makeup", "Depends on occasion", "Just lipstick"]
        },
        {
          q: "Jewelry?",
          type: "choice",
          options: ["Love accessories", "Minimal jewelry", "Statement pieces", "No jewelry", "Depends on outfit"]
        },
        {
          q: "Heels or Flats?",
          type: "choice",
          options: ["Heels always", "Comfort over style", "Sneakers", "Depends on occasion", "Mix of both"]
        },
        {
          q: "Hair style preference?",
          type: "choice",
          options: ["Long hair", "Medium length", "Short hair", "Changes often", "Experimenting"]
        },
        {
          q: "Shopping frequency?",
          type: "choice",
          options: ["Love shopping", "Occasional shopper", "Online shopping", "Only when needed", "Window shopping"]
        },
        {
          q: "Brand conscious?",
          type: "choice",
          options: ["Love brands", "Quality over brand", "Mix of both", "Thrift shopping", "Not brand conscious"]
        },
        {
          q: "Perfume?",
          type: "choice",
          options: ["Always wear perfume", "Occasionally", "Specific scents", "Natural scent", "Body mist"]
        }
      ]
    },
    {
      name: "Daily Life",
      icon: "☀️",
      gradient: "from-yellow-500 to-orange-500",
      questions: [
        {
          q: "Morning routine?",
          type: "choice",
          options: ["Early riser", "Snooze button lover", "Depends on day", "Night owl", "No fixed routine"]
        },
        {
          q: "Shower preference?",
          type: "choice",
          options: ["Morning shower", "Night shower", "Both", "Depends on mood", "Long relaxing baths"]
        },
        {
          q: "Room temperature?",
          type: "choice",
          options: ["Love AC/Cold", "Warm room", "Natural temperature", "Changes with season"]
        },
        {
          q: "Sleep schedule?",
          type: "choice",
          options: ["Early sleeper", "Night owl", "Irregular", "8 hours must", "Flexible"]
        },
        {
          q: "Pillow count?",
          type: "choice",
          options: ["One pillow", "Two pillows", "Many pillows", "Body pillow", "Doesn't matter"]
        },
        {
          q: "Organized or Messy?",
          type: "choice",
          options: ["Very organized", "Organized chaos", "A bit messy", "Minimalist", "Depends on mood"]
        },
        {
          q: "Phone usage?",
          type: "choice",
          options: ["Always on phone", "Moderate usage", "Minimal usage", "Depends on day", "Trying to reduce"]
        },
        {
          q: "Social media platform?",
          type: "choice",
          options: ["Instagram", "Snapchat", "Twitter/X", "Facebook", "Multiple", "Not active"]
        },
        {
          q: "Planner or Spontaneous?",
          type: "choice",
          options: ["Plans everything", "Mix of both", "Very spontaneous", "Go with flow"]
        },
        {
          q: "Alone time need?",
          type: "choice",
          options: ["Need lots of alone time", "Occasional me-time", "Social butterfly", "Balanced"]
        }
      ]
    },
    {
      name: "Hobbies & Interests",
      icon: "🎨",
      gradient: "from-indigo-500 to-purple-500",
      questions: [
        {
          q: "Creative outlet?",
          type: "choice",
          options: ["Painting/Drawing", "Writing", "Crafting", "Photography", "Cooking/Baking", "Music", "Not creative", "Multiple interests"]
        },
        {
          q: "Sports/Exercise?",
          type: "choice",
          options: ["Gym regularly", "Yoga/Meditation", "Dance", "Sports", "Walking/Running", "Not into fitness"]
        },
        {
          q: "Indoor or Outdoor?",
          type: "choice",
          options: ["Indoor person", "Outdoor lover", "Balanced", "Depends on weather"]
        },
        {
          q: "Favorite season?",
          type: "choice",
          options: ["Summer", "Monsoon", "Autumn", "Winter", "Spring", "Love all seasons"]
        },
        {
          q: "Beach or Mountains?",
          type: "choice",
          options: ["Beach person", "Mountain lover", "Both equally", "City person", "Countryside"]
        },
        {
          q: "Pets?",
          type: "choice",
          options: ["Dog lover", "Cat person", "Both", "Other pets", "Not a pet person", "Love all animals"]
        },
        {
          q: "Collection hobby?",
          type: "choice",
          options: ["Collect items", "Minimalist", "Depends on item", "Not into collecting"]
        },
        {
          q: "Gardening?",
          type: "choice",
          options: ["Love plants", "Have few plants", "Kills plants", "Not interested"]
        },
        {
          q: "Learning new skills?",
          type: "choice",
          options: ["Always learning", "Occasionally", "Specific interests", "Not much time"]
        },
        {
          q: "Photography?",
          type: "choice",
          options: ["Love clicking photos", "Occasional", "Hate photos", "Like being photographed"]
        }
      ]
    },
    {
      name: "Social Life",
      icon: "👥",
      gradient: "from-green-500 to-teal-500",
      questions: [
        {
          q: "Social battery?",
          type: "choice",
          options: ["Social butterfly", "Selective socializing", "Introvert", "Ambivert"]
        },
        {
          q: "Party preference?",
          type: "choice",
          options: ["Love parties", "Small gatherings", "One-on-one hangouts", "Homebody", "Depends on mood"]
        },
        {
          q: "Friend circle?",
          type: "choice",
          options: ["Large friend group", "Small close group", "Few best friends", "Prefer alone", "Quality over quantity"]
        },
        {
          q: "Making new friends?",
          type: "choice",
          options: ["Very friendly", "Takes time to open", "Selective", "Not looking for new friends"]
        },
        {
          q: "Texting style?",
          type: "choice",
          options: ["Quick replies", "Long messages", "Voice notes", "Calls preferred", "Depends on person"]
        },
        {
          q: "Social media posting?",
          type: "choice",
          options: ["Regular posts", "Story person", "Occasional posts", "Lurker", "Very private"]
        },
        {
          q: "Gifts giving?",
          type: "choice",
          options: ["Thoughtful gifts", "Practical gifts", "Handmade gifts", "Experience gifts", "Not good at gifts"]
        },
        {
          q: "Helping others?",
          type: "choice",
          options: ["Always helping", "When I can", "Close ones only", "Prefer not to", "Depends on situation"]
        },
        {
          q: "Gossip?",
          type: "choice",
          options: ["Hate gossip", "Harmless fun", "Sometimes listen", "Source of updates"]
        },
        {
          q: "Conflict handling?",
          type: "choice",
          options: ["Confront directly", "Avoid conflict", "Need time to process", "Talk it out"]
        }
      ]
    },
    {
      name: "Travel & Adventure",
      icon: "✈️",
      gradient: "from-blue-500 to-cyan-500",
      questions: [
        {
          q: "Travel enthusiasm?",
          type: "choice",
          options: ["Love traveling", "Occasional trips", "Homebody", "Would love to travel more"]
        },
        {
          q: "Travel style?",
          type: "choice",
          options: ["Planned itinerary", "Spontaneous trips", "Mix of both", "Luxury travel", "Budget backpacking"]
        },
        {
          q: "Domestic or International?",
          type: "choice",
          options: ["Explore India first", "International travel", "Both equally", "Nearby places"]
        },
        {
          q: "Solo or Group travel?",
          type: "choice",
          options: ["Solo traveler", "With friends", "Family trips", "Partner travel", "Small groups"]
        },
        {
          q: "Bucket list destination?",
          type: "choice",
          options: ["Europe", "USA", "Asia", "Australia", "Africa", "South America", "Multiple places", "Happy anywhere"]
        },
        {
          q: "Road trip or Flight?",
          type: "choice",
          options: ["Road trips", "Flights", "Train journeys", "Depends on distance"]
        },
        {
          q: "Beach vacation or City tour?",
          type: "choice",
          options: ["Beach relaxation", "City exploration", "Mountain getaway", "Mix of everything"]
        },
        {
          q: "Souvenirs?",
          type: "choice",
          options: ["Collect souvenirs", "Photos are enough", "Local items", "Not into souvenirs"]
        },
        {
          q: "Adventure activities?",
          type: "choice",
          options: ["Thrill seeker", "Some activities", "Watch others", "Prefer relaxation"]
        },
        {
          q: "Tourist spots or Off-beat?",
          type: "choice",
          options: ["Famous tourist spots", "Off-beat places", "Local experiences", "Mix of both"]
        }
      ]
    },
    {
      name: "Future Dreams",
      icon: "🌟",
      gradient: "from-purple-500 to-pink-500",
      questions: [
        {
          q: "Career aspiration?",
          type: "choice",
          options: ["Corporate career", "Entrepreneur", "Creative field", "Service profession", "Still exploring", "Work-life balance matters"]
        },
        {
          q: "Education goals?",
          type: "choice",
          options: ["Higher studies", "Professional courses", "Content with current", "Skill-based learning", "Lifelong learner"]
        },
        {
          q: "Living preference?",
          type: "choice",
          options: ["Big city", "Small town", "Abroad", "Hometown", "Flexible", "Wherever life takes"]
        },
        {
          q: "Own house dream?",
          type: "choice",
          options: ["Dream house", "Apartment", "Villa", "Doesn't matter", "Not priority"]
        },
        {
          q: "Family planning?",
          type: "choice",
          options: ["Want kids", "No kids", "Maybe someday", "Haven't thought", "Depends on partner"]
        },
        {
          q: "Pet dreams?",
          type: "choice",
          options: ["Definitely want pets", "Maybe pets", "No pets", "Already have/had pets"]
        },
        {
          q: "Work from home or Office?",
          type: "choice",
          options: ["WFH preferred", "Office person", "Hybrid", "Flexible", "Doesn't matter"]
        },
        {
          q: "Retirement age?",
          type: "choice",
          options: ["Early retirement", "Standard age", "Never retire", "Haven't thought", "Depends on finances"]
        },
        {
          q: "Hobbies to pursue?",
          type: "choice",
          options: ["Have dream hobbies", "Want to learn new", "Content with current", "Too many interests"]
        },
        {
          q: "Life goal?",
          type: "choice",
          options: ["Financial freedom", "Happy family", "Make a difference", "Personal growth", "Adventure and experiences", "Balance everything"]
        }
      ]
    },
    {
      name: "Love & Relationships",
      icon: "💕",
      gradient: "from-rose-500 to-pink-500",
      questions: [
        {
          q: "Love language (receiving)?",
          type: "choice",
          options: ["Words of affirmation", "Quality time", "Physical touch", "Acts of service", "Gifts", "All of them"]
        },
        {
          q: "Relationship priority?",
          type: "choice",
          options: ["Very high priority", "Important but balanced", "Part of life", "Takes time"]
        },
        {
          q: "Ideal date?",
          type: "choice",
          options: ["Fancy dinner", "Netflix and chill", "Adventure activity", "Long drive", "Home-cooked meal", "Surprise me"]
        },
        {
          q: "Communication in relationship?",
          type: "choice",
          options: ["Talk everything out", "Need space sometimes", "Mix of both", "Actions over words"]
        },
        {
          q: "Jealousy feeling?",
          type: "choice",
          options: ["Get jealous sometimes", "Very secure", "Depends on situation", "Protective feelings"]
        },
        {
          q: "Past relationships impact?",
          type: "choice",
          options: ["Learned from past", "Past is past", "Still healing", "No past relationships", "Shaped who I am"]
        },
        {
          q: "Expressing love?",
          type: "choice",
          options: ["Very expressive", "Through actions", "Words and actions", "Need encouragement", "Depends on comfort"]
        },
        {
          q: "Relationship goals?",
          type: "choice",
          options: ["Marriage minded", "Take it slow", "Living in present", "Serious commitment", "Still figuring out"]
        },
        {
          q: "Deal breakers?",
          type: "choice",
          options: ["Lying", "Disrespect", "Cheating", "Lack of effort", "Multiple things", "Few things"]
        },
        {
          q: "Love at first sight?",
          type: "choice",
          options: ["Believe in it", "Doesn't happen", "Happened to me", "Skeptical", "Love grows over time"]
        }
      ]
    },
    {
      name: "Random Fun Facts",
      icon: "🎯",
      gradient: "from-cyan-500 to-blue-500",
      questions: [
        {
          q: "Superpower choice?",
          type: "choice",
          options: ["Invisibility", "Flying", "Time travel", "Mind reading", "Teleportation", "Super strength"]
        },
        {
          q: "Zombie apocalypse?",
          type: "choice",
          options: ["Leader", "Strategist", "First to panic", "Survival mode", "Team player"]
        },
        {
          q: "Lucky number?",
          type: "choice",
          options: ["Have one", "Don't believe in it", "Multiple numbers", "Changes"]
        },
        {
          q: "Astrology belief?",
          type: "choice",
          options: ["Strongly believe", "Fun to read", "Skeptical", "Don't believe", "Depends"]
        },
        {
          q: "Dream job as kid?",
          type: "choice",
          options: ["Doctor", "Teacher", "Artist", "Astronaut", "Actor", "Something else", "Many dreams"]
        },
        {
          q: "Pineapple on pizza?",
          type: "choice",
          options: ["Love it", "Hate it", "Neutral", "Never tried", "Depends on mood"]
        },
        {
          q: "Morning or Evening person?",
          type: "choice",
          options: ["Morning", "Evening", "Night", "Afternoon", "All times"]
        },
        {
          q: "Rain mood?",
          type: "choice",
          options: ["Love rain", "Cozy inside", "Gets me down", "Neutral", "Depends on plans"]
        },
        {
          q: "Texting 'K' means?",
          type: "choice",
          options: ["I'm upset", "Just okay", "In a hurry", "Nothing much", "Depends"]
        },
        {
          q: "If you could meet anyone?",
          type: "choice",
          options: ["Historical figure", "Celebrity", "Family ancestor", "Fictional character", "Future self", "You already know who"]
        }
      ]
    },
    {
      name: "Your Sizes & Measurements",
      icon: "📐",
      gradient: "from-pink-500 to-rose-500",
      questions: [
        {
          q: "Your height?",
          type: "choice",
          options: ["Under 5'0\"", "5'0\"-5'1\"", "5'2\"-5'3\"", "5'4\"-5'5\"", "5'6\"-5'7\"", "5'8\"-5'9\"", "5'10\"+", "Comfortable with it", "Wish taller", "Wish shorter", "Perfect height", "Prefer not to share"]
        },
        {
          q: "Dress size?",
          type: "choice",
          options: ["XS", "S", "M", "L", "XL", "XXL+", "Varies by brand", "Between sizes", "Petite", "Tall", "Plus size", "Don't know exactly", "Comfortable sharing", "Prefer private"]
        },
        {
          q: "Top size?",
          type: "choice",
          options: ["XS", "S", "M", "L", "XL", "XXL+", "Varies by brand", "Between sizes", "Petite fit", "Regular fit", "Tall fit", "Don't know", "Comfortable sharing"]
        },
        {
          q: "Bottom size?",
          type: "choice",
          options: ["XS", "S", "M", "L", "XL", "XXL+", "Size 0-2", "Size 4-6", "Size 8-10", "Size 12-14", "Size 16+", "Varies by brand", "Between sizes", "Prefer not to share"]
        },
        {
          q: "Shoe size?",
          type: "choice",
          options: ["UK 3-4", "UK 5-6", "UK 7-8", "UK 9+", "US 5-6", "US 7-8", "US 9-10", "Varies by brand", "Wide feet", "Narrow feet", "Half size", "Between sizes"]
        },
        {
          q: "Bra size? (optional)",
          type: "choice",
          options: ["30 band", "32 band", "34 band", "36 band", "38 band", "40+ band", "A-B cup", "C-D cup", "DD+ cup", "Varies by brand", "Prefer not to share", "Comfortable sharing"]
        },
        {
          q: "Body shape?",
          type: "choice",
          options: ["Hourglass", "Pear", "Apple", "Rectangle", "Inverted triangle", "Athletic", "Curvy", "Petite", "Plus size", "Average", "Don't categorize", "All shapes beautiful", "Still figuring out"]
        },
        {
          q: "Ring size?",
          type: "choice",
          options: ["Size 4-5", "Size 6-7", "Size 8-9", "Size 10+", "Small hands", "Medium hands", "Large hands", "Don't know", "Need measuring", "Varies per finger", "Never measured", "Would need to find out"]
        },
        {
          q: "Waist size?",
          type: "choice",
          options: ["24\"-25\"", "26\"-27\"", "28\"-29\"", "30\"-31\"", "32\"-33\"", "34\"-35\"", "36\"+", "Don't measure", "Varies", "Comfortable with", "Prefer not to share"]
        },
        {
          q: "Overall frame?",
          type: "choice",
          options: ["Petite frame", "Small frame", "Medium frame", "Average frame", "Large frame", "Delicate bones", "Strong bones", "Athletic build", "Curvy build", "Slim build", "Natural build", "Comfortable with body"]
        }
      ]
    },
    {
      name: "Monthly Cycle & Health",
      icon: "🌸",
      gradient: "from-rose-500 to-pink-500",
      questions: [
        {
          q: "Cycle regularity?",
          type: "choice",
          options: ["Very regular (28-30 days)", "Mostly regular (±3 days)", "Somewhat irregular", "Very irregular", "Post-birth control", "PCOS affected", "Tracking to learn", "Consistent now", "Unpredictable", "Working on it", "Prefer not to share"]
        },
        {
          q: "Period length?",
          type: "choice",
          options: ["1-2 days (light)", "3-4 days", "5-6 days", "7+ days", "Varies each month", "Getting shorter", "Getting longer", "Consistent", "Very short", "Average length", "Prefer not to share"]
        },
        {
          q: "Flow heaviness?",
          type: "choice",
          options: ["Very light", "Light", "Medium", "Heavy", "Very heavy", "Varies by day", "Day 2 heaviest", "Consistent throughout", "Flooding sometimes", "Manageable", "Concerning levels", "Prefer not to share"]
        },
        {
          q: "Cramp severity?",
          type: "choice",
          options: ["No cramps", "Mild discomfort", "Moderate pain", "Severe cramps", "Debilitating pain", "First day worst", "Throughout period", "Varies monthly", "Manageable with meds", "Need doctor help", "Prefer not to share"]
        },
        {
          q: "PMS symptoms?",
          type: "choice",
          options: ["Emotional/mood swings", "Irritable", "Cravings", "Bloating", "Headaches", "Fatigue", "Breast tenderness", "All of them", "Minimal symptoms", "Varies monthly", "Manageable", "Prefer not to share"]
        },
        {
          q: "Period products?",
          type: "choice",
          options: ["Pads only", "Tampons only", "Menstrual cup", "Period underwear", "Mix of products", "Organic products", "Regular brands", "Trying different", "Cost-effective choice", "Eco-friendly options"]
        },
        {
          q: "Comfort needs during period?",
          type: "choice",
          options: ["Heating pad must", "Pain medication", "Rest & sleep", "Chocolate/sweets", "Comfort food", "Hot drinks", "Gentle exercise", "Netflix binge", "All support needed", "Emotional support", "Space & understanding", "Just normal routine"]
        },
        {
          q: "Period tracking?",
          type: "choice",
          options: ["Track with app", "Mental tracking", "Calendar method", "Don't track", "Started recently", "Should track more", "Very detailed tracking", "Basic tracking", "Forget sometimes", "Trying to be consistent"]
        },
        {
          q: "Talking about periods?",
          type: "choice",
          options: ["Very open about it", "With close people", "Private matter", "Uncomfortable topic", "Normalizing it", "Depends on person", "Educating others", "Sharing experiences", "Keep to myself", "Selective sharing"]
        },
        {
          q: "Health concerns?",
          type: "choice",
          options: ["PCOS", "Endometriosis", "Irregular cycles", "Heavy bleeding", "Painful periods", "No major concerns", "Should see doctor", "Being monitored", "Family history", "Working on health", "All fine currently"]
        },
        {
          q: "Birth control?",
          type: "choice",
          options: ["On birth control", "Not on it", "Considering it", "Not interested", "Tried before", "Stopped using", "Doctor recommended", "For periods", "For contraception", "Personal choice", "Prefer not to share"]
        },
        {
          q: "Gynecologist visits?",
          type: "choice",
          options: ["Regular checkups", "When needed", "Avoid it", "Should go more", "Annual visits", "Every few years", "Never been", "Planning to go", "Have concerns", "All good", "Prefer not to share"]
        }
      ]
    },
    {
      name: "Beauty & Self-Care",
      icon: "💄",
      gradient: "from-purple-500 to-pink-500",
      questions: [
        {
          q: "Skincare routine?",
          type: "choice",
          options: ["Elaborate routine (10+ steps)", "Moderate routine (5-7 steps)", "Basic routine (3-4 steps)", "Minimal (cleanser & moisturizer)", "Korean skincare", "Should do more", "Night routine only", "Morning routine only", "Lazy about it", "Building routine", "Just starting"]
        },
        {
          q: "Makeup daily?",
          type: "choice",
          options: ["Full makeup daily", "Minimal makeup", "No makeup usually", "Depends on day", "Special occasions only", "Just mascara/lipstick", "Natural look", "Love doing makeup", "Hate doing makeup", "Learning makeup", "Varies by mood"]
        },
        {
          q: "Hair care routine?",
          type: "choice",
          options: ["Extensive hair care", "Regular routine", "Basic wash & go", "Should improve", "Hair masks weekly", "Oils and treatments", "Salon treatments", "DIY care", "Low maintenance", "Growing hair out", "Experimenting"]
        },
        {
          q: "Nail care?",
          type: "choice",
          options: ["Regular manicures", "DIY nails", "Gel/acrylics", "Natural nails", "Polish at home", "Don't care much", "Love nail art", "Simple polish", "Bare nails", "Depends on season", "Special occasions"]
        },
        {
          q: "Self-care frequency?",
          type: "choice",
          options: ["Daily rituals", "Weekly self-care", "Monthly treatments", "Whenever possible", "Should do more", "Feel guilty about it", "Priority for me", "Learning to prioritize", "Rarely have time", "Building habits"]
        },
        {
          q: "Bath vs shower?",
          type: "choice",
          options: ["Love long baths", "Quick showers", "Both equally", "Depends on mood", "Bath for relaxation", "Shower for efficiency", "No bathtub", "Prefer baths", "Prefer showers", "Whatever's faster"]
        },
        {
          q: "Spa days?",
          type: "choice",
          options: ["Love spa days", "Occasional spa trips", "Never been", "Would like more", "DIY spa at home", "Too expensive", "Special treat", "Regular thing", "Not interested", "With friends"]
        },
        {
          q: "Fragrance?",
          type: "choice",
          options: ["Signature perfume", "Multiple perfumes", "Body mist", "Natural scent", "Expensive perfumes", "Drugstore scents", "Seasonal scents", "Mood-based", "Don't wear fragrance", "Still finding one"]
        },
        {
          q: "Hair removal?",
          type: "choice",
          options: ["Fully waxed", "Shaving", "Laser", "Trimmed", "Natural", "Depends on season", "Special occasions", "Regular routine", "When I remember", "Comfortable as is"]
        },
        {
          q: "Beauty budget?",
          type: "choice",
          options: ["Invest in products", "Drugstore mostly", "Mix high-low", "Minimal spending", "Splurge sometimes", "DIY treatments", "Sales shopper", "Quality matters", "Budget-conscious", "Growing collection"]
        }
      ]
    },
    {
      name: "Body Image & Confidence",
      icon: "🪞",
      gradient: "from-pink-500 to-rose-500",
      questions: [
        {
          q: "Body confidence?",
          type: "choice",
          options: ["Very confident", "Working on it", "Insecure", "Varies by day", "Growing confidence", "Struggling", "Love my body", "Body positive journey", "Depends on mood", "Getting better", "Need support"]
        },
        {
          q: "Mirror thoughts?",
          type: "choice",
          options: ["Positive thoughts", "Neutral view", "Critical of myself", "Depends on day", "Avoid mirrors", "Love what I see", "Working on acceptance", "Mixed feelings", "Improving view", "Body positive"]
        },
        {
          q: "Clothes shopping feelings?",
          type: "choice",
          options: ["Love shopping", "Stressful experience", "Neutral feelings", "Depends on mood", "Dressing room anxiety", "Online only", "Sizing issues", "Enjoyable usually", "With support", "Hate it"]
        },
        {
          q: "Social media effect?",
          type: "choice",
          options: ["Doesn't affect me", "Sometimes affects me", "Very affected", "Avoiding comparisons", "Curate my feed", "Limiting use", "Body positive follows", "Triggering sometimes", "Unfollowed models", "Working on it"]
        },
        {
          q: "Comparison habits?",
          type: "choice",
          options: ["Compare often", "Sometimes compare", "Rarely compare", "Working on not comparing", "Triggers insecurity", "Everyone's different", "Stopped comparing", "Learning acceptance", "It's a struggle", "Getting better"]
        },
        {
          q: "Body parts you love?",
          type: "choice",
          options: ["Love everything", "Love some parts", "Working on loving all", "Insecure about most", "Love my eyes", "Love my smile", "Love my hair", "Love my curves", "Growing appreciation", "Body positive journey"]
        },
        {
          q: "Weight thoughts?",
          type: "choice",
          options: ["Comfortable weight", "Want to lose", "Want to gain", "Doesn't matter", "Health focused", "Number doesn't define me", "Fluctuates", "Working on acceptance", "It's complicated", "Happy where I am"]
        },
        {
          q: "Compliment receiving?",
          type: "choice",
          options: ["Accept easily", "Feel awkward", "Don't believe them", "Working on accepting", "Depends who from", "Smile and thanks", "Deflect compliments", "Learning to receive", "Appreciate them", "Still uncomfortable"]
        },
        {
          q: "Fitness motivation?",
          type: "choice",
          options: ["Health focused", "Appearance focused", "Both equally", "Enjoy movement", "Struggle with it", "Building habits", "Not priority", "Love being active", "Working on it", "Complicated relationship"]
        },
        {
          q: "Self-love practices?",
          type: "choice",
          options: ["Practice regularly", "Trying to practice", "Need to start", "Don't know how", "Affirmations daily", "Therapy helping", "Reading books", "Learning journey", "Want to improve", "Growing practice"]
        }
      ]
    },
    {
      name: "Emotional & Mental Health",
      icon: "🧠",
      gradient: "from-indigo-500 to-purple-500",
      questions: [
        {
          q: "Anxiety levels?",
          type: "choice",
          options: ["High anxiety", "Moderate anxiety", "Low anxiety", "Varies greatly", "Diagnosed anxiety", "Social anxiety", "Manageable", "Getting help", "Undiagnosed", "Working on it", "Prefer not to share"]
        },
        {
          q: "Depression experience?",
          type: "choice",
          options: ["Currently dealing", "Past experience", "Never experienced", "Diagnosed depression", "Undiagnosed", "Seasonal", "Managing it", "In therapy", "Medication helps", "Getting better", "Prefer not to share"]
        },
        {
          q: "Therapy?",
          type: "choice",
          options: ["In therapy now", "Have been before", "Considering it", "Not interested", "Want to start", "Can't afford", "Bad experience", "Very helpful", "Off and on", "Starting soon", "Prefer not to share"]
        },
        {
          q: "Coping mechanisms?",
          type: "choice",
          options: ["Healthy coping", "Some unhealthy habits", "Working on better ones", "Need better coping", "Therapy taught me", "Exercise helps", "Creative outlets", "Talk it out", "Isolate myself", "Learning new ways"]
        },
        {
          q: "Stress management?",
          type: "choice",
          options: ["Handle well", "Get overwhelmed", "Need support", "Varies", "Meditation helps", "Exercise relieves", "Talk to friends", "Bottle it up", "Cry it out", "Working on it"]
        },
        {
          q: "Emotional expression?",
          type: "choice",
          options: ["Very expressive", "Moderately expressive", "Bottle up feelings", "Learning to express", "Comfortable crying", "Hide emotions", "Depends on person", "Working on it", "Therapy helping", "Natural expresser"]
        },
        {
          q: "Crying frequency?",
          type: "choice",
          options: ["Cry easily", "Occasionally cry", "Rarely cry", "Can't cry", "Healthy crying", "Cry alone", "Comfortable crying", "Hold back tears", "Depends on situation", "Release through crying"]
        },
        {
          q: "Mental health priority?",
          type: "choice",
          options: ["Top priority", "Working on making it priority", "Not enough priority", "Learning importance", "Improving focus", "Struggle to prioritize", "Getting better", "Balancing", "Growing awareness", "Need support"]
        },
        {
          q: "Support system?",
          type: "choice",
          options: ["Strong support", "Few people", "Alone", "Building one", "Family support", "Friends support", "Partner support", "Therapist support", "Need more support", "Grateful for mine"]
        },
        {
          q: "Self-compassion?",
          type: "choice",
          options: ["Very kind to self", "Working on it", "Harsh on self", "Learning self-compassion", "Therapy teaching me", "Critical voice", "Improving", "Struggle with it", "Getting better", "Natural self-love"]
        }
      ]
    },
    {
      name: "Career & Ambitions",
      icon: "💼",
      gradient: "from-blue-500 to-cyan-500",
      questions: [
        {
          q: "Current career satisfaction?",
          type: "choice",
          options: ["Love my job", "It's okay", "Not happy", "Transitioning", "Dream job", "Pays bills", "Growing in it", "Want change", "Still figuring out", "Building career"]
        },
        {
          q: "Dream job?",
          type: "choice",
          options: ["Have it now", "Working toward it", "Figuring it out", "Many dreams", "Creative field", "Entrepreneurship", "Corporate ladder", "Helping people", "Still exploring", "Money vs passion"]
        },
        {
          q: "Work stress?",
          type: "choice",
          options: ["Manageable stress", "High stress", "Low stress job", "Varies", "Burnout risk", "Love the challenge", "Too much pressure", "Balanced", "Need change", "Growing with it"]
        },
        {
          q: "Career ambition?",
          type: "choice",
          options: ["Very ambitious", "Moderately ambitious", "Content current level", "Not sure yet", "Climbing ladder", "Work-life balance matters", "Passion over position", "Building empire", "Taking time", "Flexible goals"]
        },
        {
          q: "Further education?",
          type: "choice",
          options: ["Planning it", "Considering it", "Not interested", "Currently pursuing", "Master's degree", "Certifications", "Skills training", "Maybe someday", "Finished education", "Life learning"]
        },
        {
          q: "Leadership aspirations?",
          type: "choice",
          options: ["Want to lead", "Happy contributing", "Not sure", "Natural leader", "Learning leadership", "Prefer supporting", "Building skills", "Opportunity-based", "Growing into it", "Not my style"]
        },
        {
          q: "Work from home preference?",
          type: "choice",
          options: ["WFH always", "Office preferred", "Hybrid is best", "Flexible", "Remote forever", "Miss office", "Depends on job", "Love WFH", "Need office structure", "Either works"]
        },
        {
          q: "Career vs personal life?",
          type: "choice",
          options: ["Career focused", "Personal life priority", "Balanced both", "Varies by phase", "Building career now", "Relationship matters more", "Both equally", "Figuring balance", "Depends on day", "Growing balance"]
        }
      ]
    },
    {
      name: "Family Dynamics",
      icon: "👨‍👩‍👧‍👦",
      gradient: "from-green-500 to-teal-500",
      questions: [
        {
          q: "Family closeness?",
          type: "choice",
          options: ["Very close family", "Moderately close", "Not close", "Complicated", "Chosen family", "Close to some", "Working on relationships", "Healing dynamics", "Distant", "Growing closeness"]
        },
        {
          q: "Parental relationship?",
          type: "choice",
          options: ["Great relationship", "Okay relationship", "Strained", "No contact", "Healing", "One parent close", "Both close", "Complicated", "Working on it", "Prefer not to share"]
        },
        {
          q: "Sibling dynamics?",
          type: "choice",
          options: ["Close siblings", "Okay relationship", "Not close", "Only child", "Complicated", "Best friends", "Growing apart", "Different lives", "Love them", "It's complex"]
        },
        {
          q: "Family gatherings?",
          type: "choice",
          options: ["Love them", "Tolerate them", "Avoid them", "Depends on family", "Look forward to", "Stressful", "Small doses", "Enjoy most", "Complicated feelings", "Miss them"]
        },
        {
          q: "Family expectations?",
          type: "choice",
          options: ["Meet them", "Some pressure", "Don't meet them", "Rejected them", "Living for me", "Balancing", "Traditional family", "Modern family", "Creating own path", "It's complicated"]
        },
        {
          q: "Family traditions?",
          type: "choice",
          options: ["Follow many", "Some traditions", "Creating own", "Not traditional", "Love traditions", "Mixed feelings", "Religious traditions", "Cultural traditions", "New traditions", "Flexible"]
        },
        {
          q: "Future family vision?",
          type: "choice",
          options: ["Traditional family", "Modern family", "Unique structure", "Not sure yet", "Big family", "Small family", "Chosen family", "Creating own", "Open to possibilities", "Still deciding"]
        }
      ]
    },
    {
      name: "Intimacy & Desires",
      icon: "💋",
      gradient: "from-rose-500 to-pink-500",
      questions: [
        {
          q: "Physical intimacy importance?",
          type: "choice",
          options: ["Very important", "Moderately important", "Not priority", "Depends on connection", "After emotional bond", "Important part", "Takes time", "Open to discussing", "Still learning", "Growing comfort", "Prefer not to share"]
        },
        {
          q: "Initiation comfort?",
          type: "choice",
          options: ["Comfortable initiating", "Shy about it", "Wait for him", "Learning confidence", "Depends on mood", "Direct about it", "Subtle hints", "Building confidence", "Prefer he initiates", "Either way works"]
        },
        {
          q: "Physical touch needs?",
          type: "choice",
          options: ["Need lots of touch", "Moderate touch", "Not very touchy", "Depends on mood", "Love cuddling", "Personal space matters", "Affectionate", "Touch is love language", "Growing comfort", "Balanced"]
        },
        {
          q: "Expressing desires?",
          type: "choice",
          options: ["Comfortable expressing", "Working on it", "Shy about it", "Indirect hints", "Direct communication", "Learning to express", "Building confidence", "Depends on partner", "Still figuring out", "Growing openness"]
        },
        {
          q: "Boundaries?",
          type: "choice",
          options: ["Clear boundaries", "Figuring out", "Flexible boundaries", "Still learning", "Know my limits", "Communicating them", "Growing awareness", "Depends on trust", "Setting boundaries", "Working on it"]
        },
        {
          q: "Past experiences impact?",
          type: "choice",
          options: ["Learned from them", "Still healing", "Good experiences", "No past", "Shaped preferences", "Working through", "Positive impact", "Some trauma", "Growing from it", "Prefer not to share"]
        },
        {
          q: "Communication about needs?",
          type: "choice",
          options: ["Very open", "Getting better", "Struggle with it", "Learning to communicate", "Direct about needs", "Shy sharing", "Building openness", "Depends on partner", "Working on it", "Growing confidence"]
        },
        {
          q: "Experimentation openness?",
          type: "choice",
          options: ["Very open", "Somewhat open", "Prefer comfort zone", "Depends on trust", "Curious", "Need discussion", "Slow pace", "Open with right person", "Setting boundaries", "Still learning"]
        },
        {
          q: "Intimacy frequency ideal?",
          type: "choice",
          options: ["Very often", "Regularly", "Occasionally", "When feels right", "Depends on mood", "Connection matters", "Quality over quantity", "Spontaneous", "Varies", "Growing needs"]
        }
      ]
    },
    {
      name: "Insecurities & Vulnerabilities",
      icon: "💔",
      gradient: "from-purple-500 to-indigo-500",
      questions: [
        {
          q: "Biggest insecurity?",
          type: "choice",
          options: ["Physical appearance", "Mental/emotional", "Career/success", "Relationships", "Multiple things", "Intelligence", "Worthiness", "Being enough", "Comparison", "Working on it", "Prefer not to share"]
        },
        {
          q: "Sharing insecurities?",
          type: "choice",
          options: ["Share openly", "With close ones", "Keep private", "Working on sharing", "Depends on person", "Therapy helping", "Difficult for me", "Building trust", "Selective sharing", "Growing openness"]
        },
        {
          q: "Comparison triggers?",
          type: "choice",
          options: ["Social media", "Friends' lives", "Strangers", "Specific situations", "Celebrities", "Success stories", "Relationship posts", "Body images", "Everything", "Working on it"]
        },
        {
          q: "Vulnerability comfort?",
          type: "choice",
          options: ["Comfortable being vulnerable", "Working on it", "Struggle with it", "Depends on person", "Building safety", "Therapy helping", "Takes time", "Learning", "Growing comfort", "Still scary"]
        },
        {
          q: "Fear of judgment?",
          type: "choice",
          options: ["Very afraid", "Somewhat afraid", "Not much", "Depends on who", "Working through it", "Therapy addressing", "People pleaser", "Growing confidence", "Less afraid now", "Still struggle"]
        },
        {
          q: "Impostor syndrome?",
          type: "choice",
          options: ["Struggle with it", "Sometimes feel it", "Not really", "In specific areas", "Career related", "Relationships", "Everything", "Working on it", "Growing through it", "Rare"]
        },
        {
          q: "Rejection fear?",
          type: "choice",
          options: ["Very afraid", "Manageable fear", "Not much", "Working on it", "Past trauma", "Building resilience", "Growing strength", "Depends on situation", "Learning from it", "Getting better"]
        },
        {
          q: "Opening up pace?",
          type: "choice",
          options: ["Open up quickly", "Takes time", "Very guarded", "Depends on trust", "Slow process", "Once safe", "Building trust", "Learning", "Past hurt affects", "Growing openness"]
        },
        {
          q: "Asking for help?",
          type: "choice",
          options: ["Comfortable asking", "Struggle with it", "Very independent", "Learning to ask", "Depends on what", "Building comfort", "Pride issue", "Working on it", "Getting better", "Still hard"]
        }
      ]
    },
    {
      name: "Daily Habits & Quirks",
      icon: "🌅",
      gradient: "from-orange-500 to-yellow-500",
      questions: [
        {
          q: "Wake up mood?",
          type: "choice",
          options: ["Morning person", "Grumpy morning", "Depends on sleep", "Need coffee first", "Cheerful", "Slow waker", "Energetic", "Need time", "Mood varies", "Hit snooze"]
        },
        {
          q: "Breakfast habits?",
          type: "choice",
          options: ["Must eat breakfast", "Skip breakfast", "Coffee only", "Sometimes eat", "Big breakfast", "Light breakfast", "Brunch person", "On-the-go", "Sit-down meal", "Varies"]
        },
        {
          q: "Getting ready time?",
          type: "choice",
          options: ["Quick 15 min", "30-45 minutes", "1+ hour", "Depends on day", "Rushed always", "Planned routine", "Lazy days faster", "Special occasions longer", "Varies greatly", "No set time"]
        },
        {
          q: "Snooze button usage?",
          type: "choice",
          options: ["Never snooze", "Once", "Multiple times", "Depends on day", "5 more minutes", "Set multiple alarms", "Jump up", "Struggle to wake", "Getting better", "Always snooze"]
        },
        {
          q: "Bedtime routine?",
          type: "choice",
          options: ["Structured routine", "Relaxed routine", "No routine", "Varies", "Skincare focus", "Phone scrolling", "Reading", "TV watching", "Wind down", "Falls asleep anywhere"]
        },
        {
          q: "Phone checking?",
          type: "choice",
          options: ["Constantly checking", "Regular checks", "Occasionally", "Barely check", "First thing morning", "Last thing night", "Trying less", "Addicted", "Balanced", "Minimal use"]
        },
        {
          q: "Procrastination?",
          type: "choice",
          options: ["Major procrastinator", "Sometimes", "Rarely procrastinate", "Very disciplined", "Work on it", "Last minute", "Plan ahead", "Depends on task", "Getting better", "Varies"]
        },
        {
          q: "Multitasking ability?",
          type: "choice",
          options: ["Great multitasker", "Terrible at it", "Depends on task", "One thing focus", "Can juggle", "Gets overwhelmed", "Prefer focus", "Music helps", "Need silence", "Learning"]
        },
        {
          q: "Organization style?",
          type: "choice",
          options: ["Very organized", "Organized chaos", "Messy", "Trying to improve", "Color-coded", "Lists everything", "Wing it", "Depends on area", "Getting better", "Natural organizer"]
        },
        {
          q: "Decision making?",
          type: "choice",
          options: ["Quick decisions", "Takes forever", "Overthinks", "Depends on importance", "Impulsive", "Research first", "Ask opinions", "Trust gut", "Anxiety inducing", "Growing confidence"]
        }
      ]
    },
    {
      name: "Wardrobe & Style Details",
      icon: "👗",
      gradient: "from-pink-500 to-purple-500",
      questions: [
        {
          q: "Wardrobe size?",
          type: "choice",
          options: ["Minimal capsule", "Small wardrobe", "Medium size", "Large wardrobe", "Massive closet", "Too much", "Too little", "Perfect amount", "Need to declutter", "Building", "Seasonal rotation"]
        },
        {
          q: "Jeans owned?",
          type: "choice",
          options: ["1-2 pairs", "3-5 pairs", "6-10 pairs", "10+ pairs", "Don't wear jeans", "Every wash", "Specific favorites", "Rotate few", "Many options", "Collector", "Just enough"]
        },
        {
          q: "Dresses owned?",
          type: "choice",
          options: ["None/Few", "5-10 dresses", "10-20 dresses", "20+ dresses", "Love dresses", "Rarely wear", "Occasion only", "Casual dresses", "Formal collection", "All types", "Growing collection"]
        },
        {
          q: "Shoes owned?",
          type: "choice",
          options: ["Under 10 pairs", "10-20 pairs", "20-30 pairs", "30-50 pairs", "50+ pairs", "Sneaker collection", "Heels collection", "All types", "Too many", "Need more", "Just enough"]
        },
        {
          q: "Bags owned?",
          type: "choice",
          options: ["1-3 bags", "4-7 bags", "8-15 bags", "15+ bags", "Practical one", "Different occasions", "Handbag collection", "All types", "Investment pieces", "Need more", "Perfect amount"]
        },
        {
          q: "Favorite clothing item?",
          type: "choice",
          options: ["Jeans", "Dresses", "Tops", "Skirts", "Leggings", "Sweaters", "Jackets", "Shoes", "Accessories", "Everything", "Depends mood"]
        },
        {
          q: "Shopping frequency?",
          type: "choice",
          options: ["Weekly shopper", "Monthly", "Seasonal", "Rarely shop", "When needed", "Love shopping", "Hate shopping", "Online only", "Window shopper", "Sales only", "Impulse buyer"]
        },
        {
          q: "Style consistency?",
          type: "choice",
          options: ["Consistent style", "Varies greatly", "Mood-based", "Experimenting", "Found my style", "Still figuring out", "Many styles", "Classic", "Trendy", "Unique", "Evolving"]
        },
        {
          q: "Laundry pile situation?",
          type: "choice",
          options: ["Always caught up", "Small pile", "Medium pile", "Large pile", "Overwhelming", "Organized", "Chaos", "Gets done eventually", "Hate laundry", "Very on top of it"]
        }
      ]
    },
    {
      name: "Food Ultra-Detailed",
      icon: "🍕",
      gradient: "from-red-500 to-orange-500",
      questions: [
        {
          q: "Spice tolerance exact?",
          type: "choice",
          options: ["Can't handle any", "Mild only 1-2/10", "Moderate 3-4/10", "Medium 5-6/10", "Medium-high 7-8/10", "Very spicy 9/10", "Extreme 10/10", "Indian level", "Thai level", "Growing tolerance", "Varies by dish"]
        },
        {
          q: "Coffee order exactly?",
          type: "choice",
          options: ["Black coffee", "Espresso", "Americano", "Latte", "Cappuccino", "Mocha", "Macchiato", "Flat white", "Iced coffee", "Cold brew", "Frappuccino", "Specific order", "Don't drink"]
        },
        {
          q: "Tea preference?",
          type: "choice",
          options: ["Don't drink tea", "Black tea", "Green tea", "Herbal tea", "Chai/Masala", "Earl Grey", "Chamomile", "Peppermint", "Oolong", "Bubble tea", "Milk tea", "All types", "Specific brand"]
        },
        {
          q: "Pizza order exactly?",
          type: "choice",
          options: ["Margherita", "Pepperoni", "Veggie supreme", "BBQ chicken", "Hawaiian", "Meat lovers", "Custom order", "Cheese only", "Thin crust", "Thick crust", "Stuffed crust", "Specific place"]
        },
        {
          q: "Ice cream favorite?",
          type: "choice",
          options: ["Vanilla", "Chocolate", "Strawberry", "Cookie dough", "Mint chip", "Coffee", "Pistachio", "Mango", "Butterscotch", "Rocky road", "Ben & Jerry's specific", "Local favorite", "Multiple favorites"]
        },
        {
          q: "Breakfast go-to?",
          type: "choice",
          options: ["Eggs & toast", "Cereal", "Oatmeal", "Smoothie", "Pancakes/Waffles", "Avocado toast", "Fruit", "Yogurt", "Skip breakfast", "Coffee only", "Big breakfast", "Varies", "Whatever's there"]
        },
        {
          q: "Snack preference?",
          type: "choice",
          options: ["Sweet snacks", "Salty snacks", "Healthy snacks", "Chips", "Chocolate", "Fruit", "Nuts", "Cookies", "Whatever's there", "Don't snack much", "Constant snacker", "Mood-based"]
        },
        {
          q: "Cooking at home?",
          type: "choice",
          options: ["Cook daily", "Few times week", "Weekends only", "Rarely cook", "Never cook", "Love cooking", "Hate cooking", "Learning", "Meal prep", "Order out", "Depends on mood"]
        },
        {
          q: "Dietary preferences?",
          type: "choice",
          options: ["No restrictions", "Vegetarian", "Vegan", "Pescatarian", "Gluten-free", "Dairy-free", "Keto", "Paleo", "Intermittent fasting", "Flexible", "Health-focused", "Trying different"]
        },
        {
          q: "Restaurant type favorite?",
          type: "choice",
          options: ["Fine dining", "Casual dining", "Fast food", "Street food", "Ethnic cuisine", "Cafes", "Food trucks", "Home cooking best", "Try everything", "Specific favorites", "Mood-dependent"]
        }
      ]
    },
    {
      name: "Social Media & Online",
      icon: "📱",
      gradient: "from-blue-500 to-purple-500",
      questions: [
        {
          q: "Most used platform?",
          type: "choice",
          options: ["Instagram", "Snapchat", "TikTok", "Twitter/X", "Facebook", "Pinterest", "LinkedIn", "YouTube", "Multiple", "Not active", "Depends on day"]
        },
        {
          q: "Posting frequency?",
          type: "choice",
          options: ["Daily posts", "Few times week", "Weekly", "Monthly", "Rarely post", "Story person", "Grid person", "Both", "Lurker", "Private account", "Not active"]
        },
        {
          q: "Content you post?",
          type: "choice",
          options: ["Selfies", "Food pics", "Lifestyle", "Travel", "Friends", "Aesthetic", "Random", "Quotes", "Mix everything", "Professional", "Personal", "Don't post"]
        },
        {
          q: "Followers count?",
          type: "choice",
          options: ["Under 100", "100-500", "500-1000", "1000-5000", "5000+", "Don't count", "Private small", "Growing", "Depends on platform", "Quality not quantity"]
        },
        {
          q: "Screen time daily?",
          type: "choice",
          options: ["1-2 hours", "3-4 hours", "5-6 hours", "7+ hours", "Too much", "Trying to reduce", "Don't track", "Varies greatly", "Mindful of it", "No phone much"]
        },
        {
          q: "Online shopping?",
          type: "choice",
          options: ["Shop online often", "Sometimes", "Rarely", "Prefer in-store", "Amazon addict", "Window shop online", "Reviews first", "Impulse buyer", "Careful buyer", "Avoid online"]
        },
        {
          q: "Messaging preference?",
          type: "choice",
          options: ["WhatsApp", "Instagram DM", "Snapchat", "iMessage", "Text messages", "Calls preferred", "Video calls", "Voice notes", "Mix of all", "Don't message much"]
        }
      ]
    },
    {
      name: "Dreams, Hopes & Fears",
      icon: "⭐",
      gradient: "from-yellow-500 to-orange-500",
      questions: [
        {
          q: "Biggest dream?",
          type: "choice",
          options: ["Career success", "Happy relationship", "Family goals", "Travel world", "Financial freedom", "Make a difference", "Personal growth", "Help others", "Multiple dreams", "Still discovering", "Prefer not to share"]
        },
        {
          q: "Greatest fear?",
          type: "choice",
          options: ["Loneliness", "Failure", "Not being enough", "Rejection", "Loss of loved ones", "Never finding love", "Health issues", "Financial struggles", "Wasting life", "Multiple fears", "Prefer not to share"]
        },
        {
          q: "5-year vision?",
          type: "choice",
          options: ["Clear plan", "General idea", "Living in present", "Many possibilities", "Married & settled", "Career focused", "Traveling", "Building life", "Open to anything", "Still figuring out"]
        },
        {
          q: "10-year vision?",
          type: "choice",
          options: ["Very clear", "Somewhat clear", "No idea", "Flexible vision", "Family life", "Career peak", "Retired early", "Successful", "Happy & content", "Many paths possible"]
        },
        {
          q: "Legacy desire?",
          type: "choice",
          options: ["Being remembered", "Making impact", "Helping others", "Raising good humans", "Career achievements", "Personal fulfillment", "Loved well", "Made difference", "Don't think about it", "Living fully now"]
        },
        {
          q: "Regrets?",
          type: "choice",
          options: ["Have some regrets", "Learning from them", "No regrets", "Working through them", "Past mistakes", "Wish things different", "Acceptance", "Growing from them", "Can't change past", "Prefer not to share"]
        },
        {
          q: "Life satisfaction currently?",
          type: "choice",
          options: ["Very satisfied", "Mostly satisfied", "Working on it", "Not satisfied", "Growing satisfaction", "Up and down", "Getting better", "Need changes", "Grateful", "Still building"]
        },
        {
          q: "Happiness source?",
          type: "choice",
          options: ["Relationships", "Career", "Self-love", "Multiple things", "Still searching", "Family", "Friends", "Achievements", "Simple moments", "Inner peace", "Everything"]
        },
        {
          q: "Purpose feeling?",
          type: "choice",
          options: ["Have clear purpose", "Finding purpose", "Not sure yet", "Multiple purposes", "Career is purpose", "Relationships", "Helping others", "Personal growth", "Still exploring", "Don't need purpose"]
        },
        {
          q: "Ultimate life goal?",
          type: "choice",
          options: ["Specific goal", "General happiness", "Still figuring out", "Multiple goals", "Financial freedom", "Happy family", "Make impact", "Travel world", "Inner peace", "Love well", "Leave legacy"]
        }
      ]
    },
    {
      name: "Random Personal Details",
      icon: "🎲",
      gradient: "from-purple-500 to-pink-500",
      questions: [
        {
          q: "Superstition believer?",
          type: "choice",
          options: ["Very superstitious", "Somewhat believe", "Not superstitious", "Depends on what", "Cultural superstitions", "Just for fun", "Rational person", "Open-minded", "It varies"]
        },
        {
          q: "Horoscope reader?",
          type: "choice",
          options: ["Read daily", "Sometimes read", "Just for fun", "Believe in it", "Skeptical", "Don't read", "Entertainment only", "Accurate sometimes", "Depends"]
        },
        {
          q: "Dream recorder?",
          type: "choice",
          options: ["Remember dreams", "Forget immediately", "Sometimes remember", "Keep dream journal", "Vivid dreamer", "Rarely dream", "Nightmares", "Lucid dreams", "Don't remember"]
        },
        {
          q: "Singing alone?",
          type: "choice",
          options: ["Full concerts", "Sometimes sing", "Shower singer", "Car singer", "Never sing", "Love singing", "Terrible singer", "When happy", "Mood-based"]
        },
        {
          q: "Dancing alone?",
          type: "choice",
          options: ["Dance always", "Sometimes", "Never", "Shower dancer", "Kitchen dancer", "When happy", "Terrible dancer", "Love it", "Self-conscious"]
        },
        {
          q: "Talking to yourself?",
          type: "choice",
          options: ["All the time", "Sometimes out loud", "In my head", "Never", "Planning things", "Processing thoughts", "It helps me", "Depends"]
        },
        {
          q: "Planner or spontaneous life?",
          type: "choice",
          options: ["Plan everything", "Mix of both", "Very spontaneous", "Go with flow", "Like structure", "Organized chaos", "Depends on what", "Growing flexibility"]
        },
        {
          q: "Risk taker?",
          type: "choice",
          options: ["Take risks", "Calculated risks", "Play it safe", "Depends on area", "Growing bolder", "Too cautious", "Adventurous", "Learning balance"]
        },
        {
          q: "Change adapter?",
          type: "choice",
          options: ["Embrace change", "Resist change", "Depends on change", "Growing flexibility", "Struggle with it", "Love change", "Need stability", "Getting better"]
        },
        {
          q: "Uniqueness level?",
          type: "choice",
          options: ["Very unique person", "Somewhat unique", "Pretty normal", "Quirky", "One of a kind", "Blend in", "Stand out", "Complicated person", "Still discovering me"]
        }
      ]
    },
    {
      name: "What Would You Do",
      icon: "🤔",
      gradient: "from-purple-600 to-pink-500",
      questions: [
        {
          q: "If I'm upset, would you...",
          type: "choice",
          options: ["Ask what's wrong", "Give me space", "Try to cheer me up", "Just hug me", "Listen silently", "Fix the problem", "Make me laugh", "Be there however I need"]
        },
        {
          q: "If we disagree on something, would you...",
          type: "choice",
          options: ["Argue your point", "Hear me out fully", "Find middle ground", "Give in easily", "Stand your ground", "Discuss rationally", "Need time to think", "Prioritize our relationship"]
        },
        {
          q: "If I surprise you with a gift, would you...",
          type: "choice",
          options: ["Love it regardless", "Be honest if not your style", "Appreciate the thought", "Feel overwhelmed", "Love surprises", "Prefer to know beforehand", "Cry happy tears", "Make a big deal of it"]
        },
        {
          q: "If I forget an important date, would you...",
          type: "choice",
          options: ["Be hurt", "Forgive easily", "Remind you gently", "Make a joke of it", "Expect you remember", "Understand if genuine", "Need apology", "Not take it personally"]
        },
        {
          q: "If we're lost somewhere, would you...",
          type: "choice",
          options: ["Use GPS immediately", "Ask for directions", "Try to figure it out", "Let me navigate", "Adventure time!", "Get stressed", "Stay calm", "Work together"]
        },
        {
          q: "If I cook for you, would you...",
          type: "choice",
          options: ["Eat even if bad", "Be honest kindly", "Appreciate effort", "Help improve it", "Love it always", "Prefer we cook together", "Give feedback", "So grateful"]
        },
        {
          q: "If you see me crying, would you...",
          type: "choice",
          options: ["Cry with me", "Hold me tight", "Ask what happened", "Give tissues", "Stay quiet", "Try to fix it", "Just be present", "Panic a bit"]
        },
        {
          q: "If someone insults me, would you...",
          type: "choice",
          options: ["Defend immediately", "Want to fight them", "Comfort me after", "Let me handle it", "Stand up for me", "Address it calmly", "Get protective", "Support however needed"]
        },
        {
          q: "If I'm sick, would you...",
          type: "choice",
          options: ["Take care of me", "Give me space to rest", "Bring medicine/food", "Stay by my side", "Check in frequently", "Do everything for me", "Let me tell you what I need", "Balance care and rest"]
        },
        {
          q: "If I achieve something big, would you...",
          type: "choice",
          options: ["Celebrate grandly", "Be my biggest cheerleader", "Proud cry", "Tell everyone", "Intimate celebration", "Whatever I want", "Post about it", "Make it special"]
        },
        {
          q: "If I want to try something new, would you...",
          type: "choice",
          options: ["Support immediately", "Ask if I'm sure", "Try it with me", "Excited for me", "Want details first", "Encourage me", "Slight worry but support", "Full support"]
        },
        {
          q: "If I need space, would you...",
          type: "choice",
          options: ["Give it readily", "Feel hurt", "Check in occasionally", "Trust the process", "Ask how long", "Respect but miss me", "Available when ready", "Understand completely"]
        },
        {
          q: "If I'm stressed about work/school, would you...",
          type: "choice",
          options: ["Listen without fixing", "Help if possible", "Distract me", "Give advice", "Just be there", "Take some load off", "Motivate me", "Whatever helps"]
        },
        {
          q: "If we fight, would you...",
          type: "choice",
          options: ["Never go to bed angry", "Need time to cool off", "Apologize if wrong", "Want to resolve immediately", "Silent treatment", "Talk it through", "Text if can't talk", "Mature discussion"]
        },
        {
          q: "If I'm insecure about something, would you...",
          type: "choice",
          options: ["Reassure constantly", "Help build confidence", "Never joke about it", "Take it seriously", "Show me I'm enough", "Address root cause", "Extra love", "Make me feel beautiful"]
        },
        {
          q: "If you meet my ex, would you...",
          type: "choice",
          options: ["Be polite", "Show you're mine", "Not care", "Be confident", "Friendly but clear", "Trust me fully", "Slightly protective", "Handle maturely"]
        },
        {
          q: "If I'm working late, would you...",
          type: "choice",
          options: ["Wait for me", "Bring me food", "Understand", "Miss me but okay", "Video call break", "Support my work", "Regular check-ins", "Give me space to focus"]
        },
        {
          q: "If your friends don't like me, would you...",
          type: "choice",
          options: ["You're priority", "Try to bridge gap", "Trust your judgment", "Work on it together", "Doesn't affect us", "Want them to know me better", "Stand by me", "Your choice"]
        },
        {
          q: "If I look bad in an outfit, would you...",
          type: "choice",
          options: ["Tell me nicely", "Say I look good anyway", "Help me choose better", "Honest feedback", "You look good in anything", "Tactfully suggest change", "Love whatever you wear", "Supportive honesty"]
        },
        {
          q: "If I'm embarrassed publicly, would you...",
          type: "choice",
          options: ["Make light of it", "Comfort me after", "Join in to make it less awkward", "Stand by me", "Deflect attention", "Laugh with me not at me", "Support immediately", "Help me through it"]
        },
        {
          q: "If I want to adopt a pet, would you...",
          type: "choice",
          options: ["Love the idea!", "Discuss practically", "If you're happy", "Concerned but open", "Need convincing", "Excited!", "Want to think about it", "Your wish"]
        },
        {
          q: "If I'm angry at you, would you...",
          type: "choice",
          options: ["Give space then talk", "Apologize immediately", "Hear me out", "Try to fix it", "Patient with me", "Not defensive", "Work through it", "Mature approach"]
        },
        {
          q: "If families don't approve, would you...",
          type: "choice",
          options: ["Fight for us", "Work to win them", "Priority is us", "Try to understand why", "Give time", "Convince them", "Stand with me", "Patient approach"]
        },
        {
          q: "If I want to change something about myself, would you...",
          type: "choice",
          options: ["Support my choice", "Love me as I am", "Help if I want", "Make sure it's for me", "Encourage healthy changes", "You're perfect already", "Whatever makes me happy", "Thoughtful support"]
        },
        {
          q: "If I'm having a bad day, would you...",
          type: "choice",
          options: ["Listen to me vent", "Try to cheer me up", "Give space if needed", "Distract with fun", "Just be present", "Solve if possible", "Extra affection", "Whatever I need"]
        },
        {
          q: "If I make a big mistake, would you...",
          type: "choice",
          options: ["Forgive easily", "Need time", "Talk through it", "Support learning from it", "Depends on mistake", "Growth focused", "Understanding", "Work through together"]
        },
        {
          q: "If I want to go out with friends, would you...",
          type: "choice",
          options: ["Have fun!", "Miss me but happy for me", "Want details", "Completely okay", "Join sometimes", "Trust fully", "Check in", "Your social life is important"]
        },
        {
          q: "If I'm jealous, would you...",
          type: "choice",
          options: ["Reassure immediately", "Never give reason to be", "Understand it", "Address concern", "Show I'm yours", "Make me priority", "Patient with feelings", "Prove loyalty"]
        },
        {
          q: "If someone flirts with you, would you...",
          type: "choice",
          options: ["Shut it down immediately", "Mention me", "Not notice/care", "Uncomfortable", "Politely decline", "Walk away", "Make clear I'm taken", "Handle appropriately"]
        },
        {
          q: "If I need you at 3 AM, would you...",
          type: "choice",
          options: ["Answer immediately", "Wake up for me", "Emergency or can wait?", "Always available", "There for me", "No questions asked", "Priority", "Depends on situation"]
        },
        {
          q: "If I'm overthinking, would you...",
          type: "choice",
          options: ["Calm me down", "Logical perspective", "Just listen", "Distract me", "Work through it with me", "Reassure", "Be patient", "Whatever helps"]
        },
        {
          q: "If I want to change career/path, would you...",
          type: "choice",
          options: ["Support fully", "Discuss pros/cons", "Whatever makes you happy", "Help you decide", "Back you up", "Excited for change", "Practical discussion", "Your dreams matter"]
        },
        {
          q: "If I gain/lose weight, would you...",
          type: "choice",
          options: ["Love you same", "Support if you want change", "Attraction unchanged", "Health is priority", "Beautiful always", "Never judge", "Encourage healthy", "You're perfect"]
        },
        {
          q: "If I need motivation, would you...",
          type: "choice",
          options: ["Be my cheerleader", "Tough love approach", "Gentle encouragement", "Believe in me loudly", "Whatever style you need", "Push when needed", "Support always", "Your biggest fan"]
        },
        {
          q: "If I tell you my deep secret, would you...",
          type: "choice",
          options: ["Take it to grave", "Never judge", "Support you", "Grateful you trust me", "Love you more", "Understand", "Nothing changes", "Always safe with me"]
        },
        {
          q: "If I'm being unreasonable, would you...",
          type: "choice",
          options: ["Call it out gently", "Let it slide", "Talk when calm", "Patient with me", "Firm but kind", "Depends on situation", "Loving honesty", "Balance patience and honesty"]
        },
        {
          q: "If you have to move away, would you...",
          type: "choice",
          options: ["Long distance work", "Find solution together", "Prioritize us", "Consider my situation", "Visit constantly", "Eventually same city", "Make it work", "Us first"]
        },
        {
          q: "If I'm celebrating something, would you...",
          type: "choice",
          options: ["Celebrate with me", "Plan surprise", "Proudest person", "Make it special", "Share my joy", "Whatever I want", "Go all out", "Show you're happy for me"]
        },
        {
          q: "If I'm quiet/withdrawn, would you...",
          type: "choice",
          options: ["Ask what's wrong", "Give me space", "Be present silently", "Try to cheer up", "Patient until I open up", "Gently probe", "Respect my process", "Available when ready"]
        },
        {
          q: "If future gets uncertain, would you...",
          type: "choice",
          options: ["Face it together", "Stay committed", "Work through it", "Trust in us", "Find solutions", "Never give up", "Support each other", "Stronger together"]
        }
      ]
    }
  ];

  const handleAnswer = (questionIndex: number, answer: string) => {
    const key = `${currentCategory}-${questionIndex}`;
    setAnswers(prev => ({ ...prev, [key]: answer }));
  };

  const totalQuestions = categories.reduce((acc, cat) => acc + cat.questions.length, 0);
  const answeredQuestions = Object.keys(answers).length;
  const progress = (answeredQuestions / totalQuestions) * 100;

  return (
    <SectionInner>
      <GlowOrb color="pink" className="top-20 left-10" />
      <GlowOrb color="rose" className="bottom-20 right-10" />
      
      <div className="max-w-5xl mx-auto relative z-10">
        <SectionHeader 
          emoji="💝" 
          title="Let Me Know You" 
          subtitle="Every little detail, every preference, everything that makes you YOU"
        />
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-10"
        >
          <p className="text-white/40 text-base max-w-3xl mx-auto leading-relaxed mb-4" style={{ fontFamily: "'Playfair Display', serif" }}>
            I want to know you deeper than anyone ever has. Your favorite foods, your dreams, your quirks, 
            your preferences — everything. Don't skip anything, even the smallest details matter to me. 
            Because knowing you is how I learn to love you better.
          </p>
          <p className="text-pink-400/60 text-sm italic">
            {totalQuestions} questions across {categories.length} categories
          </p>
        </motion.div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-white/30 text-sm">Progress</span>
            <span className="text-pink-400 text-sm font-medium">{answeredQuestions}/{totalQuestions}</span>
          </div>
          <div className="h-2 bg-white/5 rounded-full overflow-hidden">
            <motion.div 
              className="h-full bg-gradient-to-r from-pink-500 to-rose-500"
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.5 }}
            />
          </div>
        </div>

        {/* Category Navigation */}
          {/* Notes and Submit Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="mt-12 p-8 rounded-2xl bg-gradient-to-br from-blue-500/10 to-purple-500/10 border border-blue-500/20"
          >
            <h3 className="text-2xl font-bold text-white mb-4">Anything Else?</h3>
            <p className="text-white/60 mb-4">
              Any additional thoughts you want to share? Anything I should know about you?
            </p>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Share anything else you'd like me to know..."
              className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-white/30 focus:outline-none focus:border-blue-500/50 transition-colors resize-none"
              rows={4}
            />
            
            <button
              onClick={handleSubmit}
              disabled={submitted}
              className={`w-full mt-6 px-8 py-4 rounded-xl font-semibold text-lg transition-all ${
                submitted
                  ? "bg-green-500/20 text-green-400 cursor-not-allowed"
                  : "bg-gradient-to-r from-blue-500 to-purple-500 text-white hover:shadow-[0_0_30px_rgba(59,130,246,0.5)]"
              }`}
            >
              {submitted ? "✓ Answers Sent! Thank you 💕" : "Send All My Answers"}
            </button>
            <p className="text-white/40 text-sm mt-4 text-center">
              You can select multiple options for each question. Your answers will be sent to my email.
            </p>
          </motion.div>

          {/* Category Navigation */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-10">
          {categories.map((cat, idx) => (
            <motion.button
              key={idx}
              onClick={() => setCurrentCategory(idx)}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className={`p-4 rounded-2xl border transition-all duration-300 ${
                currentCategory === idx
                  ? `bg-gradient-to-br ${cat.gradient} border-white/20 shadow-[0_0_30px_rgba(255,45,138,0.2)]`
                  : "bg-white/[0.02] border-white/[0.06] hover:border-white/[0.12]"
              }`}
            >
              <div className="text-3xl mb-2">{cat.icon}</div>
              <div className="text-xs font-medium text-white/70">{cat.name}</div>
              <div className="text-[10px] text-white/40 mt-1">
                {categories[idx].questions.filter((_, qIdx) => answers[`${idx}-${qIdx}`]).length}/{categories[idx].questions.length}
              </div>
            </motion.button>
          ))}
        </div>

        {/* Questions */}
        <div className="space-y-6">
          <motion.div
            key={currentCategory}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3 }}
          >
            <h3 className={`text-2xl font-bold mb-8 bg-gradient-to-r ${categories[currentCategory].gradient} bg-clip-text text-transparent`}>
              {categories[currentCategory].icon} {categories[currentCategory].name}
            </h3>
            
            {categories[currentCategory].questions.map((question, qIdx) => (
              <motion.div
                key={qIdx}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: qIdx * 0.05 }}
                className="mb-8 p-6 rounded-2xl bg-white/[0.02] border border-white/[0.06] hover:border-white/[0.12] transition-all"
              >
                <h4 className="text-white/90 font-medium mb-4 text-lg">
                  {qIdx + 1}. {question.q}
                </h4>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {question.options.map((option, oIdx) => {
                    const key = `${currentCategory}-${qIdx}`;
                    const isSelected = answers[key] === option;
                    
                    return (
                      <motion.button
                        key={oIdx}
                        onClick={() => handleAnswer(qIdx, option)}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        className={`p-4 rounded-xl text-left transition-all duration-300 ${
                          isSelected
                            ? `bg-gradient-to-r ${categories[currentCategory].gradient} text-white shadow-[0_0_20px_rgba(255,45,138,0.3)]`
                            : "bg-white/[0.03] border border-white/[0.08] text-white/60 hover:bg-white/[0.06] hover:border-white/[0.15] hover:text-white/80"
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${
                            isSelected ? "border-white" : "border-white/20"
                          }`}>
                            {isSelected && (
                              <motion.div
                                initial={{ scale: 0 }}
                                animate={{ scale: 1 }}
                                className="w-3 h-3 rounded-full bg-white"
                              />
                            )}
                          </div>
                          <span className="text-sm font-medium">{option}</span>
                        </div>
                      </motion.button>
                    );
                  })}
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between mt-10">
          <button
            onClick={() => setCurrentCategory(Math.max(0, currentCategory - 1))}
            disabled={currentCategory === 0}
            className="px-6 py-3 rounded-xl bg-white/[0.05] border border-white/[0.1] text-white/60 disabled:opacity-30 disabled:cursor-not-allowed hover:bg-white/[0.08] transition-all"
          >
            ← Previous
          </button>
          
          <button
            onClick={() => {
              if (currentCategory < categories.length - 1) {
                setCurrentCategory(currentCategory + 1);
              } else {
                setShowResults(true);
              }
            }}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-pink-500 to-rose-500 text-white font-medium shadow-[0_0_30px_rgba(255,45,138,0.3)] hover:shadow-[0_0_40px_rgba(255,45,138,0.5)] transition-all"
          >
            {currentCategory < categories.length - 1 ? "Next →" : "Complete"}
          </button>
        </div>

        {/* Results Modal */}
        <AnimatePresence>
          {showResults && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-dark-950/95 backdrop-blur-xl"
              onClick={() => setShowResults(false)}
            >
              <motion.div
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.9, y: 20 }}
                onClick={(e) => e.stopPropagation()}
                className="max-w-2xl w-full bg-gradient-to-br from-dark-900 to-dark-950 rounded-3xl p-8 border border-white/10 max-h-[80vh] overflow-y-auto"
              >
                <div className="text-center mb-6">
                  <div className="text-6xl mb-4">💖</div>
                  <h3 className="text-3xl font-bold bg-gradient-to-r from-pink-400 to-rose-400 bg-clip-text text-transparent mb-2">
                    I Know You Better Now
                  </h3>
                  <p className="text-white/50">
                    You've shared {answeredQuestions} things about yourself
                  </p>
                </div>
                
                <div className="space-y-4 mb-6">
                  <p className="text-white/70 leading-relaxed" style={{ fontFamily: "'Playfair Display', serif" }}>
                    Thank you for opening up to me. Every answer you gave is a piece of the puzzle that is you. 
                    I feel closer to you now, like I understand your heart a little better. 
                    This means the world to me. 💕
                  </p>
                  <p className="text-pink-400/70 text-sm italic text-center">
                    "The more I know you, the more I fall for you"
                  </p>
                </div>
                
                <button
                  onClick={() => setShowResults(false)}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-pink-500 to-rose-500 text-white font-medium"
                >
                  Close
                </button>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </SectionInner>
  );
}

function ForeverContent() {  const [showMessage, setShowMessage] = useState(false);
  const [clickCount, setClickCount] = useState(0);

  const handleClick = () => { setClickCount((c) => c + 1); setShowMessage(true); };

  return (
    <SectionInner className="min-h-[80vh] flex items-center justify-center">
      <GlowOrb color="pink" className="top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
      <GlowOrb color="purple" className="top-10 right-10" />
      <GlowOrb color="magenta" className="bottom-10 left-10" />
      <div className="text-center max-w-3xl mx-auto relative z-10">
        <motion.div initial={{ scale: 0, rotate: -180 }} animate={{ scale: 1, rotate: 0 }} transition={{ type: "spring", stiffness: 60, delay: 0.3 }} className="mb-10">
          <InfinityIcon className="w-20 h-20 text-pink-500 mx-auto drop-shadow-[0_0_30px_rgba(255,45,138,0.5)]" />
        </motion.div>
        <motion.h2 initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="text-5xl md:text-6xl lg:text-7xl font-extrabold text-glow bg-gradient-to-r from-pink-400 via-rose-400 to-purple-400 bg-clip-text text-transparent mb-6" style={{ fontFamily: "'Poppins', sans-serif" }}>
          Forever & Always
        </motion.h2>
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.7 }} className="text-white/30 text-lg md:text-xl leading-relaxed mb-10 max-w-2xl mx-auto">
          No matter what life throws at us, no matter where the road takes us, I will always find my way back to you. Because you are my home, my heart, and my forever.
        </motion.p>
        <motion.button initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.9 }} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} onClick={handleClick} className="relative px-10 py-5 rounded-2xl bg-gradient-to-r from-pink-500 via-fuchsia-500 to-purple-500 text-white font-semibold text-lg shadow-[0_0_40px_rgba(255,45,138,0.3)] hover:shadow-[0_0_60px_rgba(255,45,138,0.5)] transition-all inline-flex items-center gap-3 overflow-hidden group">
          <div className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/10 to-white/0 translate-x-[-200%] group-hover:translate-x-[200%] transition-transform duration-700" />
          <Heart className="w-5 h-5 fill-white animate-heartbeat relative z-10" />
          <span className="relative z-10">{clickCount === 0 ? "Click If You Love Me Too" : `Clicked ${clickCount} time${clickCount > 1 ? "s" : ""}! 💕`}</span>
          <Heart className="w-5 h-5 fill-white animate-heartbeat relative z-10" />
        </motion.button>
        <AnimatePresence>
          {showMessage && (
            <motion.div initial={{ opacity: 0, y: 40, scale: 0.9 }} animate={{ opacity: 1, y: 0, scale: 1 }} className="mt-14">
              <div className="relative">
                <div className="absolute -inset-2 bg-gradient-to-br from-pink-500/15 via-transparent to-purple-500/15 rounded-[32px] blur-xl" />
                <div className="relative glass-strong rounded-[24px] p-8 md:p-10 gradient-border">
                  <div className="text-6xl mb-6">🥺💖</div>
                  <h3 className="text-3xl md:text-4xl font-extrabold text-pink-400 text-glow mb-5" style={{ fontFamily: "'Poppins', sans-serif" }}>I LOVE YOU SO MUCH!</h3>
                  <div className="text-white/40 text-base md:text-lg leading-relaxed space-y-2 max-w-lg mx-auto">
                    <p>You just made my heart explode! 💕</p>
                    <p>You are the best thing that has ever happened to me.</p>
                    <p>Never forget that. Never forget how special you are.</p>
                    <p className="text-pink-400/70 font-semibold pt-2">You are loved. You are cherished. You are mine. 💖</p>
                  </div>
                  <div className="flex items-center justify-center gap-2 mt-8">
                    {["💖", "💕", "💗", "💓", "💝", "💘", "💞", "❤️‍🔥"].map((e, i) => (
                      <motion.span key={i} initial={{ y: 30, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: i * 0.08, type: "spring" }} className="text-xl md:text-2xl">{e}</motion.span>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>


    </SectionInner>
  );
}

// =============================================
// VALENTINE'S WEEK SECTIONS
// =============================================

function RoseDayContent() {  const [selectedRose, setSelectedRose] = useState<number | null>(null);
  const [showFacts, setShowFacts] = useState(false);
  const [activeTab, setActiveTab] = useState<'roses' | 'facts' | 'meanings'>('roses');

  const roses = [
    { color: "Purple", hex: "#9333ea", meaning: "Love at first sight & enchantment", message: "Your favorite color, and you're my favorite everything. Purple roses are rare and precious — just like you. This represents the magical moment I first saw you and knew my life would never be the same. The rarity of purple roses mirrors how rare you are — one in a billion. 💜", icon: "🟣", rarity: "Rare", symbolism: "Royalty, enchantment, eternal love" },
    { color: "Deep Purple", hex: "#6b21a8", meaning: "Majesty & dignity", message: "You carry yourself with grace and strength. Deep purple represents the queen you are — commanding respect while remaining gentle. Your dignity inspires me to be better.", icon: "💜", rarity: "Very Rare", symbolism: "Royal love, sophistication" },
    { color: "Red", hex: "#dc2626", meaning: "Deep passionate love", message: "The classic symbol of romance. Every time I see red roses, I think of the fire you've ignited in my heart. Burning, passionate, eternal love. This is the rose that says 'I'm madly in love with you.' ❤️", icon: "🔴", rarity: "Common", symbolism: "True love, desire, courage" },
    { color: "Dark Red", hex: "#991b1b", meaning: "Unconscious beauty & intense passion", message: "You don't even realize how stunning you are. Dark red roses represent the deep, almost obsessive passion I have for you. This love runs deeper than surface attraction.", icon: "❤️", rarity: "Uncommon", symbolism: "Deep longing, mourning lost love" },
    { color: "Burgundy", hex: "#881337", meaning: "Intense passion & commitment", message: "Deep, mature love that's chosen every day. This isn't just a feeling — it's a conscious decision to love you forever. Burgundy roses symbolize love that has aged like fine wine. 🍷", icon: "🔴", rarity: "Rare", symbolism: "Unconscious beauty, deep passion" },
    { color: "Pink", hex: "#ec4899", meaning: "Admiration & appreciation", message: "I admire everything about you — your strength, your kindness, your beautiful soul. Pink roses say 'I'm grateful you exist.' You deserve to be appreciated every single day. 💗", icon: "🌸", rarity: "Common", symbolism: "Grace, joy, admiration" },
    { color: "Light Pink", hex: "#fbcfe8", meaning: "Sweetness & innocence", message: "The gentle, pure side of our love. Light pink roses represent the innocent joy I feel with you — like a teenager falling in love for the first time.", icon: "🩷", rarity: "Common", symbolism: "Young love, joy, gentleness" },
    { color: "Hot Pink", hex: "#db2777", meaning: "Gratitude & appreciation", message: "Thank you for being mine. Hot pink screams 'I'm so grateful for you!' This is the rose that says you're appreciated, valued, and cherished.", icon: "💗", rarity: "Uncommon", symbolism: "Appreciation, grace" },
    { color: "White", hex: "#f5f5f5", meaning: "Pure love & new beginnings", message: "Our love is pure, honest, and true. White roses represent the fresh start we can have together, building something beautiful. They symbolize 'my love is pure and eternal.' 🤍", icon: "⚪", rarity: "Common", symbolism: "Purity, innocence, unity" },
    { color: "Ivory", hex: "#fef3c7", meaning: "Charm & thoughtfulness", message: "I think about you constantly. Ivory roses are more thoughtful than white — they say 'I'm always thinking of you, always caring about your happiness.'", icon: "🤍", rarity: "Uncommon", symbolism: "Grace, elegance" },
    { color: "Yellow", hex: "#eab308", meaning: "Friendship & joy", message: "You're not just someone I love — you're my best friend. You bring sunshine and happiness into my darkest days. Yellow roses celebrate the friendship that makes our love unbreakable. 💛", icon: "🟡", rarity: "Common", symbolism: "Friendship, joy, new beginnings" },
    { color: "Pale Yellow", hex: "#fef08a", meaning: "Caring & concern", message: "I care about you deeply. Not just romantic love — genuine concern for your wellbeing, your happiness, your dreams. Pale yellow shows protective caring.", icon: "💛", rarity: "Uncommon", symbolism: "Sympathy, jealousy (historical)" },
    { color: "Orange", hex: "#f97316", meaning: "Enthusiasm & desire", message: "The intensity of my feelings for you. Orange represents the passionate desire and excitement I feel every time I think about our future. This is burning fascination. 🧡", icon: "🟠", rarity: "Uncommon", symbolism: "Desire, enthusiasm, fascination" },
    { color: "Coral", hex: "#fb7185", meaning: "Desire & fascination", message: "I'm fascinated by you. The way you think, the way you smile, the way you exist. Every detail about you draws me in deeper. Coral is softer than orange but equally passionate. 🌺", icon: "🩷", rarity: "Rare", symbolism: "Desire, passion" },
    { color: "Lavender", hex: "#c084fc", meaning: "Enchantment & wonder", message: "You've enchanted me completely. There's wonder in every moment with you, magic in your laugh, mystery in your eyes. Lavender roses are for falling in love at first sight. ✨", icon: "💜", rarity: "Rare", symbolism: "Love at first sight, enchantment" },
    { color: "Peach", hex: "#fdba74", meaning: "Sincerity & gratitude", message: "Thank you for existing. Thank you for being you. My gratitude for having you in my life is beyond words. Peach roses close deals and celebrate partnerships. 🍑", icon: "🟤", rarity: "Uncommon", symbolism: "Modesty, sincerity, gratitude" },
    { color: "Green", hex: "#16a34a", meaning: "Harmony & fertility", message: "Together, we create perfect balance. Green roses represent growth — our love growing deeper, our future growing brighter. They symbolize hope and renewal. 💚", icon: "🟢", rarity: "Very Rare", symbolism: "Fertility, renewal, harmony" },
    { color: "Blue", hex: "#3b82f6", meaning: "Mystery & the impossible", message: "They say blue roses don't exist naturally. But neither does a love like ours. We're the impossible made real. You're my blue rose — the miracle I never thought I'd find. 💙", icon: "🔵", rarity: "Impossible (Dyed)", symbolism: "Mystery, the impossible" },
    { color: "Black", hex: "#1f2937", meaning: "Rebirth & farewell", message: "Black roses aren't about death — they're about transformation. The death of who I was before you, and rebirth as someone better. Our love killed my old self and created someone worthy of you. 🖤", icon: "⚫", rarity: "Very Rare", symbolism: "Rebirth, farewell, new beginnings" },
    { color: "Rainbow", hex: "linear-gradient", meaning: "All emotions at once", message: "One rose, infinite colors. That's how I feel about you — every emotion, all at once. Joy, passion, peace, excitement, safety, desire... everything. You're my rainbow. 🌈", icon: "🌈", rarity: "Artificial", symbolism: "Diversity, joy, pride" },
    { color: "Gold", hex: "#ca8a04", meaning: "Achievement & perfection", message: "You're my greatest achievement and my definition of perfection. Gold roses are for accomplishment — and loving you is the greatest thing I've ever done. 🏆", icon: "🟡", rarity: "Rare (Spray)", symbolism: "Perfection, achievement" },
    { color: "Silver", hex: "#94a3b8", meaning: "Grace & elegance", message: "The way you move through the world — graceful, elegant, effortless. Silver roses represent sophisticated beauty and feminine strength.", icon: "⚪", rarity: "Rare (Spray)", symbolism: "Elegance, grace" },
    { color: "Champagne", hex: "#fbbf24", meaning: "Thoughtfulness & luxury", message: "Like champagne, you make everything feel celebratory. This color represents the luxury of being with you — every moment feels special. 🥂", icon: "🟡", rarity: "Uncommon", symbolism: "Thoughtfulness, consideration" },
    { color: "Cream", hex: "#fef9c3", meaning: "Thoughtful & charming", message: "You're both thoughtful and charming — a rare combination. Cream roses are for the person who makes life softer, gentler, warmer.", icon: "🤍", rarity: "Uncommon", symbolism: "Thoughtfulness, charm" },
    { color: "Bi-Color", hex: "#ec4899", meaning: "Harmony in differences", message: "Two colors, one rose. That's us — different but perfect together. Bi-color roses celebrate unity in diversity. We're two halves of one whole. 💕", icon: "🌸", rarity: "Uncommon", symbolism: "Unity, harmony" },
  ];

  const roseFacts = [
    { fact: "Red roses were sacred to Aphrodite, the Greek goddess of love, because they were said to have sprouted from the ground where her tears and her lover's blood mixed.", category: "Mythology", spicy: false },
    { fact: "In the Victorian era, sending yellow roses to someone meant you were accusing them of infidelity. Now they mean friendship — language evolves!", category: "History", spicy: false },
    { fact: "The scent of roses is scientifically proven to reduce stress hormones and increase feelings of happiness and relaxation.", category: "Science", spicy: false },
    { fact: "Roses have been used as aphrodisiacs for centuries. Rose oil is said to increase libido and enhance romantic feelings.", category: "Spicy", spicy: true },
    { fact: "The rose is the only flower that's simultaneously named for the color. The color is named after the flower, not the other way around.", category: "Trivia", spicy: false },
    { fact: "Ancient Egyptians used rose petals to seduce lovers. Cleopatra supposedly filled her bedroom knee-deep in rose petals to seduce Mark Antony.", category: "History", spicy: true },
    { fact: "There are over 300 species of roses and thousands of rose hybrids. Your love deserves all of them.", category: "Botany", spicy: false },
    { fact: "Roses can live for hundreds of years. The oldest living rose bush is over 1,000 years old in Germany. Just like my love for you — eternal.", category: "Trivia", spicy: false },
    { fact: "The world's most expensive rose ever sold was valued at $15.8 million — but you're priceless.", category: "Trivia", spicy: false },
    { fact: "Roses are edible! Rose petals, rose water, and rose oil are used in cooking. In the Middle East, rose water is added to romantic dinners as an aphrodisiac.", category: "Culinary", spicy: true },
    { fact: "Red roses increase heart rate when received by someone in love. Your brain literally responds to roses when you're attracted to the giver.", category: "Science", spicy: true },
    { fact: "In Roman times, rose petals were scattered on wedding beds. Roses were believed to inspire passion and ensure a happy marriage.", category: "History", spicy: true },
    { fact: "The tradition of giving roses on Valentine's Day dates back to the 1700s when Charles II of Sweden introduced the 'language of flowers' to Europe.", category: "History", spicy: false },
    { fact: "Purple roses were created through cross-breeding and don't occur naturally in the wild. They're as rare and special as true love.", category: "Botany", spicy: false },
    { fact: "Roses have thorns to protect their beauty. It's a metaphor for relationships — the most beautiful things require protection and care.", category: "Philosophy", spicy: false },
    { fact: "The phrase 'sub rosa' (under the rose) means 'in secret.' Romans hung roses over meeting tables to indicate confidential discussions. Your secrets are safe with me.", category: "Trivia", spicy: false },
    { fact: "Smelling roses during intimacy is said to heighten sensitivity and increase pleasure. The scent triggers the same brain regions as physical touch.", category: "Spicy", spicy: true },
    { fact: "A single rose means 'love at first sight.' Two roses symbolize mutual love. A dozen roses say 'be mine.' 25 roses say 'congratulations.' I'd give you infinite.", category: "Symbolism", spicy: false },
    { fact: "Blue roses symbolize 'the impossible' because they don't exist in nature. Achieving love with your soulmate is the beautiful impossible.", category: "Symbolism", spicy: false },
    { fact: "In Japan, white roses are given at funerals, but in Western culture they mean new beginnings. Context matters — and with you, every day is a new beginning.", category: "Culture", spicy: false },
  ];

  const roseMeanings = [
    { count: "1 Rose", meaning: "Love at first sight", message: "One is all it takes to say everything." },
    { count: "2 Roses", meaning: "Mutual love & affection", message: "We're in this together." },
    { count: "3 Roses", meaning: "I love you", message: "The classic declaration." },
    { count: "6 Roses", meaning: "I want to be yours", message: "Infatuation and need to be loved back." },
    { count: "9 Roses", meaning: "Eternal love", message: "Together forever, no matter what." },
    { count: "10 Roses", meaning: "You're perfect", message: "No flaws, only beauty." },
    { count: "11 Roses", meaning: "You're my treasured one", message: "Most special person in my life." },
    { count: "12 Roses", meaning: "Be mine / Marry me", message: "The proposal number." },
    { count: "13 Roses", meaning: "Secret admirer", message: "Mystery and hidden love." },
    { count: "15 Roses", meaning: "I'm sorry", message: "Apology and regret." },
    { count: "20 Roses", meaning: "Sincere feelings", message: "My feelings are genuine." },
    { count: "21 Roses", meaning: "Commitment", message: "I'm dedicated to you." },
    { count: "24 Roses", meaning: "Yours forever (24 hours)", message: "Every hour of every day." },
    { count: "25 Roses", meaning: "Congratulations", message: "Celebrating your achievements." },
    { count: "33 Roses", meaning: "Deep affection", message: "The depth of my love." },
    { count: "50 Roses", meaning: "Unconditional love", message: "No conditions, no limits." },
    { count: "99 Roses", meaning: "I'll love you forever", message: "Till death do us part." },
    { count: "100 Roses", meaning: "Devoted love", message: "Complete devotion to you." },
    { count: "108 Roses", meaning: "Will you marry me?", message: "The grand proposal." },
    { count: "365 Roses", meaning: "I love you every day", message: "Every single day of the year." },
    { count: "999 Roses", meaning: "Love without end", message: "Love that never dies." },
  ];

  return (
    <SectionInner>
      <GlowOrb color="rose" className="top-10 right-10" />
      <GlowOrb color="pink" className="bottom-20 left-20" />
      <div className="max-w-6xl mx-auto relative z-10">
        <SectionHeader 
          emoji="🌹" 
          title="Rose Day - Complete Guide" 
          subtitle="25 colors, 20 facts, infinite meanings — all for you"
        />
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <p className="text-white/40 text-base max-w-3xl mx-auto leading-relaxed" style={{ fontFamily: "'Playfair Display', serif" }}>
            Roses are the universal language of love. Every color speaks, every count matters, every petal tells a story.
            <span className="block mt-3 text-purple-400/60">💜 Purple is your favorite — so it comes first, always 💜</span>
          </p>
        </motion.div>

        {/* Tab Navigation */}
        <div className="flex justify-center gap-3 mb-8">
          {(['roses', 'facts', 'meanings'] as const).map((tab) => (
            <motion.button
              key={tab}
              onClick={() => setActiveTab(tab)}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className={`px-6 py-3 rounded-xl font-medium transition-all duration-300 ${
                activeTab === tab
                  ? "bg-gradient-to-r from-rose-500 to-pink-500 text-white shadow-[0_0_30px_rgba(244,63,94,0.3)]"
                  : "bg-white/[0.03] border border-white/[0.08] text-white/40 hover:text-white/60"
              }`}
            >
              {tab === 'roses' && '🌹 25 Rose Colors'}
              {tab === 'facts' && '📚 20 Rose Facts'}
              {tab === 'meanings' && '💝 Rose Numbers'}
            </motion.button>
          ))}
        </div>

        {/* Roses Tab */}
        {activeTab === 'roses' && (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
            {roses.map((rose, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.03 * i }}
                onClick={() => setSelectedRose(selectedRose === i ? null : i)}
                className="glass-card rounded-2xl p-6 cursor-pointer hover:shadow-[0_0_40px_rgba(147,51,234,0.15)] transition-all duration-500 group border border-white/[0.06] hover:border-purple-500/30"
              >
                <div className="flex items-start gap-4 mb-4">
                  <motion.div 
                    className="w-16 h-16 rounded-2xl flex items-center justify-center text-3xl"
                    style={{ 
                      background: rose.hex.includes('gradient') 
                        ? rose.hex 
                        : `linear-gradient(135deg, ${rose.hex}20, ${rose.hex}40)`,
                      border: `2px solid ${rose.hex}30`
                    }}
                    whileHover={{ scale: 1.1, rotate: 5 }}
                  >
                    {rose.icon}
                  </motion.div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold mb-1" style={{ color: rose.hex.includes('gradient') ? '#ec4899' : rose.hex }}>
                      {rose.color} Rose
                    </h3>
                    <p className="text-white/40 text-sm font-medium mb-1">
                      {rose.meaning}
                    </p>
                    <div className="flex gap-2 flex-wrap">
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/5 text-white/30">
                        {rose.rarity}
                      </span>
                    </div>
                  </div>
                </div>
                
                <AnimatePresence>
                  {selectedRose === i && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="overflow-hidden"
                    >
                      <div className="pt-4 border-t border-white/[0.06] mt-4 space-y-3">
                        <p className="text-white/60 leading-relaxed text-sm" style={{ fontFamily: "'Playfair Display', serif" }}>
                          {rose.message}
                        </p>
                        <div className="pt-3 border-t border-white/[0.04]">
                          <p className="text-white/30 text-xs mb-1">Symbolism:</p>
                          <p className="text-white/50 text-xs italic">{rose.symbolism}</p>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
                
                <div className="mt-4 text-center">
                  <span className="text-white/30 text-xs">
                    {selectedRose === i ? "↑ Click to close" : "↓ Click for message"}
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* Facts Tab */}
        {activeTab === 'facts' && (
          <div className="max-w-4xl mx-auto space-y-4">
            {roseFacts.map((fact, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.05 * i }}
                className="glass-card rounded-xl p-5 border border-white/[0.06] hover:border-rose-500/30 transition-all duration-300"
              >
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-rose-500/20 to-pink-500/20 flex items-center justify-center flex-shrink-0 border border-rose-500/20">
                    <span className="text-rose-400 text-sm font-bold">{i + 1}</span>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-xs px-2 py-1 rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/20">
                        {fact.category}
                      </span>
                      {fact.spicy && (
                        <span className="text-xs px-2 py-1 rounded-full bg-red-500/10 text-red-400 border border-red-500/20">
                          🔥 Spicy
                        </span>
                      )}
                    </div>
                    <p className="text-white/70 leading-relaxed" style={{ fontFamily: "'Playfair Display', serif" }}>
                      {fact.fact}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* Meanings Tab */}
        {activeTab === 'meanings' && (
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-8">
              <p className="text-white/40 text-sm" style={{ fontFamily: "'Playfair Display', serif" }}>
                The number of roses you give carries deep meaning. Here's what each count says:
              </p>
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              {roseMeanings.map((item, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.03 * i }}
                  className="glass-card rounded-xl p-4 border border-white/[0.06] hover:border-rose-500/30 transition-all duration-300"
                >
                  <div className="flex items-start gap-3">
                    <div className="text-2xl">🌹</div>
                    <div className="flex-1">
                      <h4 className="text-rose-400 font-bold mb-1">{item.count}</h4>
                      <p className="text-white/60 text-sm font-medium mb-1">{item.meaning}</p>
                      <p className="text-white/40 text-xs italic">{item.message}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-12 text-center"
        >
          <div className="inline-block px-8 py-4 rounded-2xl bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/20">
            <p className="text-purple-400/80 text-lg italic mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
              "Every rose I'd give you carries the weight of my love... 🌹"
            </p>
            <p className="text-white/40 text-sm">
              25 colors × Infinite meanings = One perfect love story
            </p>
          </div>
        </motion.div>
      </div>


    </SectionInner>
  );
}

function ProposeDayContent() {  const [activeTab, setActiveTab] = useState<'proposals' | 'facts' | 'guide'>('proposals');

  const proposals = [
    { title: "Under the Stars", desc: "I'd take you to a secluded hilltop, blankets spread under endless stars. As you point out constellations, I'd interrupt: 'There's something brighter than all these stars combined — it's the thought of spending forever with you. Will you marry me?'", icon: "✨", gradient: "from-indigo-500 to-purple-500", type: "Romantic", location: "Outdoor" },
    { title: "Through a Letter", desc: "I'd write you a 10-page letter, every page chronicling a reason I love you. On page 10, pressed between the papers, a ring would fall out with the words: 'Turn this page if your answer is yes.'", icon: "💌", gradient: "from-pink-500 to-rose-500", type: "Intimate", location: "Home" },
    { title: "Childhood Photos", desc: "I'd create a photo album — your baby photos, my baby photos, then empty pages labeled 'Our Future.' The last page: 'Let's fill these together. Marry me?'", icon: "📸", gradient: "from-amber-500 to-orange-500", type: "Sentimental", location: "Home" },
    { title: "Puzzle Pieces", desc: "I'd give you a custom puzzle. As you put it together, it forms a picture of us, with the words 'Will You Marry Me?' appearing piece by piece. The final piece — I'd be holding it with the ring.", icon: "🧩", gradient: "from-teal-500 to-cyan-500", type: "Creative", location: "Home" },
    { title: "Your Favorite Song", desc: "I'd learn to play your favorite song on guitar (badly, but with love). Mid-song, I'd stop and say: 'I forgot the words... oh wait, I remember: Will. You. Marry. Me?'", icon: "🎸", gradient: "from-violet-500 to-purple-500", type: "Musical", location: "Home" },
    { title: "Breakfast in Bed", desc: "I'd bring you breakfast in bed. The pancakes arranged to spell 'MARRY ME?' The ring balanced on top of your coffee mug. Your first sight of the day = my proposal.", icon: "🥞", gradient: "from-yellow-500 to-amber-500", type: "Sweet", location: "Home" },
    { title: "Beach Message", desc: "I'd take you for a beach walk. 'I need to tie my shoe,' I'd say, kneeling in the sand. You'd look ahead to see 'MARRY ME' written in stones and shells. You'd turn around — I'd still be kneeling with the ring.", icon: "🏖️", gradient: "from-blue-500 to-cyan-500", type: "Romantic", location: "Beach" },
    { title: "Through Our Story", desc: "I'd recreate our first date exactly. Same place, same outfits, same conversations. But this time, when you laugh at the same joke, I'd say: 'You know what would make this story even better? If it never ended. Marry me?'", icon: "📖", gradient: "from-purple-500 to-pink-500", type: "Nostalgic", location: "Special Place" },
    { title: "Scavenger Hunt", desc: "I'd send you on a scavenger hunt to all our special places — where we first met, first kissed, first said 'I love you.' Each spot has a note about that memory. The final spot: me, with the ring, with forever.", icon: "🗺️", gradient: "from-green-500 to-teal-500", type: "Adventure", location: "Multiple" },
    { title: "Movie Theater", desc: "I'd rent out a theater. 'We're watching a new movie,' I'd say. The screen shows a compilation of our videos, photos, voice notes. The final slide: 'Will you give this story a happy ending?' I'd be kneeling in the aisle.", icon: "🎬", gradient: "from-red-500 to-pink-500", type: "Grand", location: "Theater" },
    { title: "Fortune Cookie", desc: "During a casual dinner, your fortune cookie would say: 'Look under the table.' Taped underneath: 'Turn around.' I'd be kneeling behind your chair. The real fortune: spending life together.", icon: "🥠", gradient: "from-orange-500 to-red-500", type: "Surprise", location: "Restaurant" },
    { title: "Hot Air Balloon", desc: "I'd surprise you with a hot air balloon ride. As we float above the world, everything small below, I'd say: 'From up here, I can see our whole future. And in every version, you're my wife. What do you think?'", icon: "🎈", gradient: "from-pink-500 to-purple-500", type: "Adventure", location: "Sky" },
    { title: "Family Dinner", desc: "During a family dinner (both families), I'd stand up to make a toast. 'I want to thank everyone here... especially one person who might not know yet that she's about to become family permanently. [Your name], will you marry me?'", icon: "👨‍👩‍👧‍👦", gradient: "from-emerald-500 to-green-500", type: "Public", location: "Family Event" },
    { title: "First Snow", desc: "I'd wait for the first snowfall. We'd go outside to catch snowflakes, and you'd notice I'm writing something in the fresh snow with my feet: 'MARRY ME?' You'd turn around to laugh — I'd be kneeling, ring in hand, snow in my hair.", icon: "❄️", gradient: "from-cyan-500 to-blue-500", type: "Seasonal", location: "Outdoor" },
    { title: "Simple & Perfect", desc: "No grand gesture. Just us, in our favorite spot, in our most comfortable clothes. I'd hold your hands, look in your eyes, and simply say: 'I don't want to spend another day without knowing you're mine forever. Will you marry me?' Sometimes simple is everything.", icon: "💕", gradient: "from-rose-500 to-pink-500", type: "Intimate", location: "Anywhere" },
    { title: "Virtual Reality Proposal", desc: "I'd create a custom VR experience — a virtual world of our memories. At the end, the VR fades and you remove the headset to find me kneeling in the real world with a real ring.", icon: "🥽", gradient: "from-purple-500 to-indigo-500", type: "Tech", location: "Home" },
    { title: "Drone Light Show", desc: "I'd hire drones to create a light show in the night sky spelling out your name, then 'WILL YOU MARRY ME?' As you watch in amazement, I'd take your hand with the ring already on it.", icon: "🚁", gradient: "from-blue-500 to-purple-500", type: "Grand", location: "Outdoor" },
    { title: "Mountain Peak Sunrise", desc: "I'd wake you up at 3 AM for a 'surprise adventure.' We'd hike to a mountain peak and arrive just before sunrise. As the sun rises, painting the sky in gold and pink, I'd say: 'Every sunrise from now on, I want it to be with you.'", icon: "⛰️", gradient: "from-orange-500 to-yellow-500", type: "Adventure", location: "Mountain" },
    { title: "Bookstore Proposal", desc: "If you love reading, I'd take you to your favorite bookstore. 'They got a new release you'd love,' I'd say, leading you to a custom book I had made titled 'Our Forever Story' — the last page asks 'Will you marry me?'", icon: "📚", gradient: "from-amber-500 to-brown-500", type: "Literary", location: "Bookstore" },
    { title: "Cooking Together", desc: "During a regular night cooking dinner together, I'd ask you to get something from the fridge. Inside, you'd find a note: 'Turn around.' When you do, I'd be kneeling with the ring, saying 'Let's cook up a lifetime together.'", icon: "👨‍🍳", gradient: "from-red-500 to-orange-500", type: "Casual", location: "Home" },
    { title: "Concert Surprise", desc: "At your favorite artist's concert, I'd have arranged for them to call you on stage (or just point you out). They'd say: 'Someone here has a question for you.' Spotlight on me as I kneel.", icon: "🎤", gradient: "from-purple-500 to-pink-500", type: "Grand", location: "Concert" },
    { title: "Museum of Us", desc: "I'd rent a small gallery space and fill it with photos, tickets, souvenirs from our relationship — a literal museum of our love. The last exhibit: 'The Future' with a single frame containing the ring and the question.", icon: "🖼️", gradient: "from-teal-500 to-blue-500", type: "Creative", location: "Gallery" },
    { title: "Game Night Proposal", desc: "During a game night at home, I'd create a custom card game or board game where the final 'card' or 'space' reveals the proposal. You'd win the game and win my heart forever.", icon: "🎮", gradient: "from-green-500 to-teal-500", type: "Playful", location: "Home" },
    { title: "Airport Reunion", desc: "If we're long distance, I'd fly to surprise you. At the airport arrival, I'd be holding a sign that says 'Will you marry me?' instead of your name. Your shock turning to tears turning to 'yes.'", icon: "✈️", gradient: "from-blue-500 to-cyan-500", type: "Surprise", location: "Airport" },
    { title: "Christmas Morning", desc: "On Christmas morning, among all the presents under the tree, there'd be one special small box. You'd open it last. Inside: the ring. Me kneeling beside the tree. The perfect gift.", icon: "🎄", gradient: "from-green-500 to-red-500", type: "Holiday", location: "Home" },
    { title: "Underwater Proposal", desc: "If you scuba dive, I'd propose underwater with a waterproof 'Will You Marry Me?' sign. In complete silence, in a different world, the most important question.", icon: "🤿", gradient: "from-blue-500 to-teal-500", type: "Adventure", location: "Ocean" },
    { title: "Flash Mob Proposal", desc: "In a public square, seemingly random people would start dancing. They'd form a circle around you, and the choreography would spell 'MARRY ME.' Then they'd part, and I'd be there kneeling.", icon: "💃", gradient: "from-pink-500 to-purple-500", type: "Public", location: "Public Square" },
    { title: "Video Call Surprise", desc: "If long distance, during a regular video call, I'd say 'I got you something.' Your doorbell rings. You open it to find me kneeling there with the ring, phone still in hand.", icon: "📱", gradient: "from-purple-500 to-pink-500", type: "Surprise", location: "Home" },
    { title: "Garden Proposal", desc: "I'd plant a flower garden months in advance. When it blooms, the flowers would spell 'MARRY ME' visible from your window. You'd see it and rush outside to find me waiting with the ring.", icon: "🌷", gradient: "from-pink-500 to-green-500", type: "Romantic", location: "Garden" },
    { title: "Anniversary Dinner", desc: "At our anniversary dinner, instead of ordering dessert, the waiter brings a covered dish. You lift the lid — it's the ring on a bed of rose petals with a note: 'You're my favorite dessert. Will you marry me?'", icon: "🍽️", gradient: "from-red-500 to-pink-500", type: "Classic", location: "Restaurant" },
  ];

  const proposalFacts = [
    { fact: "The tradition of proposing on one knee dates back to medieval times when knights knelt before royalty. You're my queen, so I'd kneel.", category: "History", spicy: false },
    { fact: "In ancient Rome, the groom would give the bride a ring to wear on the fourth finger of her left hand, believed to have a vein directly connected to the heart.", category: "History", spicy: false },
    { fact: "The average person spends 3-6 months planning a proposal. Some spend years waiting for the perfect moment.", category: "Statistics", spicy: false },
    { fact: "83% of proposals are a complete surprise to the person being proposed to. The other 17% usually discussed it beforehand.", category: "Statistics", spicy: false },
    { fact: "December and the holiday season are the most popular times to propose, followed by Valentine's Day.", category: "Statistics", spicy: false },
    { fact: "The most expensive engagement ring ever sold was worth $71.2 million (Pink Star diamond). But your love? Priceless.", category: "Records", spicy: false },
    { fact: "In some cultures, the woman proposes to the man during leap years (Feb 29). It's called 'Ladies' Privilege.'", category: "Culture", spicy: false },
    { fact: "68% of couples have sex on the night of their engagement. It's a celebration of love and commitment.", category: "Spicy", spicy: true },
    { fact: "The 'proposal high' lasts an average of 3-6 months. Couples report feeling euphoric, energized, and more connected during this period.", category: "Psychology", spicy: false },
    { fact: "In Victorian times, flowers were used to propose — giving someone a red rose meant 'I love you passionately' and white meant 'let's be united.'", category: "History", spicy: false },
    { fact: "40% of people cry when they get proposed to. Happy tears are scientifically proven to release stress hormones.", category: "Psychology", spicy: false },
    { fact: "The engagement period releases oxytocin (the bonding hormone) at higher levels than any other relationship stage except new parent bonding.", category: "Science", spicy: true },
    { fact: "In Ireland, men who refused a woman's proposal on Leap Day were required to buy her 12 pairs of gloves so she could hide her shame of not having a ring.", category: "Culture", spicy: false },
    { fact: "75% of proposals happen in private or semi-private settings. Most people prefer intimate moments over public spectacles.", category: "Statistics", spicy: false },
    { fact: "The word 'bride' comes from an old Proto-Germanic word meaning 'to cook.' Times have changed!", category: "Trivia", spicy: false },
    { fact: "Ancient Egyptians believed the ring finger contained the 'vena amoris' (vein of love) directly connected to the heart. Modern science disproved this, but the romance remains.", category: "Science", spicy: false },
    { fact: "Couples who have a memorable, meaningful proposal report 33% higher long-term satisfaction in their marriages.", category: "Psychology", spicy: false },
    { fact: "The tradition of the diamond engagement ring only became popular in 1938 due to a De Beers marketing campaign. Before that, other gemstones were equally common.", category: "History", spicy: false },
    { fact: "In some Eastern European countries, couples get engaged twice — once in private, once in public — to honor both intimate and community bonds.", category: "Culture", spicy: false },
    { fact: "30% of proposals involve family or friends in some way — hidden photographers, secret planners, or witnesses to the moment.", category: "Statistics", spicy: false },
    { fact: "The average engagement lasts 13-18 months. This period is for wedding planning, but also for deepening commitment before marriage.", category: "Statistics", spicy: false },
    { fact: "In Japan, some couples propose at Tokyo Disneyland because it's considered the 'happiest place' — proposals there have increased 200% in the last decade.", category: "Culture", spicy: false },
    { fact: "Physiologically, being proposed to triggers the same brain chemicals as winning the lottery — dopamine, serotonin, and endorphins all spike.", category: "Science", spicy: true },
    { fact: "The longest engagement on record lasted 67 years. They finally married when both were in their 80s. Patience is a virtue!", category: "Records", spicy: false },
    { fact: "In Renaissance Italy, the engagement period included 'courtly love' rituals where couples would exchange romantic letters and poetry daily.", category: "History", spicy: false },
  ];

  const proposalGuide = [
    { title: "Know Her Style", tip: "Does she love public attention or private moments? Grand gestures or intimate simplicity? Match the proposal to HER personality, not yours." },
    { title: "Ring Size", tip: "Borrow one of her rings, trace it, or ask her friends/family. Wrong size can be resized, but right size shows attention to detail." },
    { title: "Timing Matters", tip: "Avoid stressful periods (exams, work deadlines). Choose a time when she's relaxed and can fully enjoy the moment." },
    { title: "Location Significance", tip: "Meaningful places make better proposals than random beautiful ones. Where you met > generic sunset spot." },
    { title: "Have a Backup Plan", tip: "Weather changes, places close, things go wrong. Have Plan B ready. The moment matters more than perfection." },
    { title: "Photographer?", tip: "Decide if you want the moment captured. Hire a hidden photographer or be present without cameras. Both are valid." },
    { title: "Words Matter", tip: "Practice what you'll say, but don't memorize a script. Speak from the heart. 'Will you marry me?' is enough." },
    { title: "Ring Alternatives", tip: "Can't afford the dream ring yet? Propose with a placeholder and upgrade later. The question matters more than the stone." },
    { title: "Include Family?", tip: "Some families expect to be asked first. Know her preferences. Modern couples often skip this, traditional families value it." },
    { title: "The Follow-Up", tip: "After she says yes, have a plan for the next hour. Champagne? Dinner reservation? Call parents? Don't wing the afterglow." },
  ];

  return (
    <SectionInner>
      <GlowOrb color="yellow" className="top-20 right-20" />
      <GlowOrb color="amber" className="bottom-10 left-10" />
      <div className="max-w-5xl mx-auto relative z-10">
        <SectionHeader 
          emoji="💍" 
          title="Propose Day - Complete Guide" 
          subtitle="30 proposals, 25 facts, expert tips — all roads lead to 'yes'"
        />
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <p className="text-white/40 text-base max-w-3xl mx-auto leading-relaxed" style={{ fontFamily: "'Playfair Display', serif" }}>
            I've imagined proposing to you a thousand different ways. Each one from the heart, each one real.
            <span className="block mt-3 text-yellow-400/60">Here are 30 of my favorites... 💍</span>
          </p>
        </motion.div>

        {/* Tab Navigation */}
        <div className="flex justify-center gap-3 mb-8">
          {(['proposals', 'facts', 'guide'] as const).map((tab) => (
            <motion.button
              key={tab}
              onClick={() => setActiveTab(tab)}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className={`px-6 py-3 rounded-xl font-medium transition-all duration-300 ${
                activeTab === tab
                  ? "bg-gradient-to-r from-yellow-500 to-amber-500 text-white shadow-[0_0_30px_rgba(234,179,8,0.3)]"
                  : "bg-white/[0.03] border border-white/[0.08] text-white/40 hover:text-white/60"
              }`}
            >
              {tab === 'proposals' && '💍 30 Proposals'}
              {tab === 'facts' && '📚 25 Facts'}
              {tab === 'guide' && '📖 Expert Tips'}
            </motion.button>
          ))}
        </div>

        {/* Proposals Tab */}
        {activeTab === 'proposals' && (
          <div className="space-y-4">
            {proposals.map((prop, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.03 * i }}
                whileHover={{ x: 8 }}
                className={`glass-card rounded-2xl p-6 group border border-white/[0.06] hover:border-yellow-500/30 transition-all duration-500 hover:shadow-[0_0_30px_rgba(234,179,8,0.15)]`}
              >
                <div className="flex items-start gap-4">
                  <motion.div 
                    className={`w-14 h-14 rounded-xl bg-gradient-to-br ${prop.gradient} flex items-center justify-center text-2xl flex-shrink-0 shadow-lg`}
                    whileHover={{ scale: 1.1, rotate: 5 }}
                  >
                    {prop.icon}
                  </motion.div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className={`text-xl font-bold bg-gradient-to-r ${prop.gradient} bg-clip-text text-transparent`}>
                        {prop.title}
                      </h3>
                      <div className="flex gap-2">
                        <span className="text-xs px-2 py-1 rounded-full bg-yellow-500/10 text-yellow-400 border border-yellow-500/20">
                          {prop.type}
                        </span>
                        <span className="text-xs px-2 py-1 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">
                          {prop.location}
                        </span>
                      </div>
                    </div>
                    <p className="text-white/60 leading-relaxed" style={{ fontFamily: "'Playfair Display', serif" }}>
                      {prop.desc}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* Facts Tab */}
        {activeTab === 'facts' && (
          <div className="max-w-4xl mx-auto space-y-4">
            {proposalFacts.map((fact, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.05 * i }}
                className="glass-card rounded-xl p-5 border border-white/[0.06] hover:border-yellow-500/30 transition-all duration-300"
              >
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-yellow-500/20 to-amber-500/20 flex items-center justify-center flex-shrink-0 border border-yellow-500/20">
                    <span className="text-yellow-400 text-sm font-bold">{i + 1}</span>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-xs px-2 py-1 rounded-full bg-yellow-500/10 text-yellow-400 border border-yellow-500/20">
                        {fact.category}
                      </span>
                      {fact.spicy && (
                        <span className="text-xs px-2 py-1 rounded-full bg-red-500/10 text-red-400 border border-red-500/20">
                          🔥 Spicy
                        </span>
                      )}
                    </div>
                    <p className="text-white/70 leading-relaxed" style={{ fontFamily: "'Playfair Display', serif" }}>
                      {fact.fact}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* Guide Tab */}
        {activeTab === 'guide' && (
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-8">
              <p className="text-white/40 text-sm" style={{ fontFamily: "'Playfair Display', serif" }}>
                Expert tips for planning the perfect proposal:
              </p>
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              {proposalGuide.map((item, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.05 * i }}
                  className="glass-card rounded-xl p-5 border border-white/[0.06] hover:border-yellow-500/30 transition-all duration-300"
                >
                  <div className="flex items-start gap-3">
                    <div className="text-2xl">💡</div>
                    <div className="flex-1">
                      <h4 className="text-yellow-400 font-bold mb-2">{item.title}</h4>
                      <p className="text-white/60 text-sm leading-relaxed">{item.tip}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-12 text-center"
        >
          <div className="inline-block px-8 py-4 rounded-2xl bg-gradient-to-r from-yellow-500/10 to-pink-500/10 border border-yellow-500/20">
            <p className="text-yellow-400/80 text-lg italic mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
              "But honestly? Any way I ask, the answer I'm hoping for is always the same... 💍"
            </p>
            <p className="text-white/40 text-sm">
              30 proposals × 25 facts × 10 tips = One perfect 'yes'
            </p>
          </div>
        </motion.div>
      </div>


    </SectionInner>
  );
}

function ChocolateDayContent() {  const [selectedChocolates, setSelectedChocolates] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState<'chocolates' | 'facts' | 'science'>('chocolates');
  
  const chocolates = [
    { name: "Dark Chocolate Hearts", type: "dark", icon: "🖤", taste: "Rich & Intense", origin: "Belgium", cacao: "70-85%", mood: "Sophisticated" },
    { name: "Milk Chocolate Kisses", type: "milk", icon: "🤎", taste: "Smooth & Creamy", origin: "Switzerland", cacao: "30-40%", mood: "Classic" },
    { name: "White Chocolate Truffles", type: "white", icon: "🤍", taste: "Sweet & Delicate", origin: "France", cacao: "0%", mood: "Gentle" },
    { name: "Caramel-Filled Delights", type: "caramel", icon: "🟤", taste: "Gooey & Sweet", origin: "USA", cacao: "40%", mood: "Indulgent" },
    { name: "Hazelnut Pralines", type: "hazelnut", icon: "🌰", taste: "Nutty & Rich", origin: "Italy", cacao: "50%", mood: "Elegant" },
    { name: "Strawberry Cream", type: "fruit", icon: "🍓", taste: "Fruity & Light", origin: "France", cacao: "35%", mood: "Romantic" },
    { name: "Mint Chocolate", type: "mint", icon: "🌿", taste: "Fresh & Cool", origin: "UK", cacao: "60%", mood: "Refreshing" },
    { name: "Coconut Dreams", type: "coconut", icon: "🥥", taste: "Tropical & Smooth", origin: "Caribbean", cacao: "45%", mood: "Exotic" },
    { name: "Coffee Infused", type: "coffee", icon: "☕", taste: "Bold & Energizing", origin: "Ethiopia", cacao: "65%", mood: "Awakening" },
    { name: "Raspberry Swirl", type: "fruit", icon: "🫐", taste: "Tangy & Sweet", origin: "France", cacao: "50%", mood: "Playful" },
    { name: "Salted Caramel", type: "caramel", icon: "🧂", taste: "Sweet & Salty", origin: "France", cacao: "55%", mood: "Addictive" },
    { name: "Orange Zest", type: "fruit", icon: "🍊", taste: "Citrus & Bright", origin: "Spain", cacao: "60%", mood: "Vibrant" },
    { name: "Cherry Liqueur", type: "alcohol", icon: "🍒", taste: "Boozy & Sweet", origin: "Germany", cacao: "50%", mood: "Naughty" },
    { name: "Champagne Truffle", type: "alcohol", icon: "🥂", taste: "Bubbly & Luxe", origin: "France", cacao: "45%", mood: "Celebratory" },
    { name: "Chili Dark Chocolate", type: "spicy", icon: "🌶️", taste: "Spicy & Bold", origin: "Mexico", cacao: "75%", mood: "Adventurous" },
    { name: "Sea Salt Dark", type: "dark", icon: "🌊", taste: "Savory & Deep", origin: "Ecuador", cacao: "80%", mood: "Sophisticated" },
    { name: "Rose Petal Ganache", type: "floral", icon: "🌹", taste: "Floral & Romantic", origin: "Turkey", cacao: "55%", mood: "Poetic" },
    { name: "Lavender Honey", type: "floral", icon: "💜", taste: "Herbal & Sweet", origin: "Provence", cacao: "40%", mood: "Dreamy" },
    { name: "Pistachio Cream", type: "nut", icon: "🥜", taste: "Smooth & Nutty", origin: "Sicily", cacao: "35%", mood: "Luxurious" },
    { name: "Almond Butter", type: "nut", icon: "🥜", taste: "Rich & Smooth", origin: "California", cacao: "50%", mood: "Wholesome" },
    { name: "Peanut Butter Cup", type: "nut", icon: "🥜", taste: "Salty & Sweet", origin: "USA", cacao: "40%", mood: "Comfort" },
    { name: "Tiramisu Truffle", type: "dessert", icon: "☕", taste: "Coffee & Cream", origin: "Italy", cacao: "45%", mood: "Decadent" },
    { name: "Cheesecake Bite", type: "dessert", icon: "🍰", taste: "Creamy & Tangy", origin: "USA", cacao: "30%", mood: "Indulgent" },
    { name: "Matcha Green Tea", type: "tea", icon: "🍵", taste: "Earthy & Smooth", origin: "Japan", cacao: "40%", mood: "Zen" },
    { name: "Earl Grey Infused", type: "tea", icon: "☕", taste: "Bergamot & Elegant", origin: "UK", cacao: "55%", mood: "Refined" },
    { name: "Maple Walnut", type: "nut", icon: "🍁", taste: "Sweet & Crunchy", origin: "Canada", cacao: "45%", mood: "Cozy" },
    { name: "Ginger Spice", type: "spicy", icon: "🌶️", taste: "Warming & Zesty", origin: "India", cacao: "60%", mood: "Energizing" },
    { name: "Cardamom Rose", type: "floral", icon: "🌸", taste: "Exotic & Aromatic", origin: "Middle East", cacao: "50%", mood: "Mysterious" },
    { name: "Amaretto Kiss", type: "alcohol", icon: "🥃", taste: "Almond Liqueur", origin: "Italy", cacao: "55%", mood: "Romantic" },
    { name: "Rum Raisin", type: "alcohol", icon: "🍷", taste: "Boozy & Rich", origin: "Caribbean", cacao: "60%", mood: "Warm" },
  ];

  const chocolateFacts = [
    { fact: "Chocolate contains phenylethylamine (PEA), the same chemical your brain creates when you fall in love. That's why chocolate makes you feel romantic!", category: "Science", spicy: true },
    { fact: "Ancient Aztecs believed chocolate was an aphrodisiac. Montezuma II reportedly drank 50 cups of chocolate daily before visiting his harem.", category: "History", spicy: true },
    { fact: "Dark chocolate increases blood flow throughout the body, including to the brain and... other important areas. 😏", category: "Spicy", spicy: true },
    { fact: "Casanova, the famous lover, preferred chocolate to champagne as his aphrodisiac of choice. He called it the 'elixir of love.'", category: "History", spicy: true },
    { fact: "Eating chocolate releases the same endorphins as kissing. No wonder it's the perfect Valentine's gift!", category: "Science", spicy: true },
    { fact: "Chocolate was once so valuable that ancient Mayans used cacao beans as currency. You were literally worth your weight in chocolate.", category: "History", spicy: false },
    { fact: "It takes 400 cacao beans to make one pound of chocolate. That's a lot of love in every bite!", category: "Production", spicy: false },
    { fact: "White chocolate isn't technically chocolate — it contains no cacao solids, only cocoa butter. But it's still delicious!", category: "Trivia", spicy: false },
    { fact: "The smell of chocolate increases theta brain waves, triggering relaxation. That's why chocolate shops smell so good!", category: "Science", spicy: false },
    { fact: "Dark chocolate (70%+ cacao) can improve heart health by lowering blood pressure and improving blood flow.", category: "Health", spicy: false },
    { fact: "Chocolate melts at 93°F — just below human body temperature. That's why it melts perfectly in your mouth... or on your skin. 😉", category: "Spicy", spicy: true },
    { fact: "Switzerland has the highest per capita chocolate consumption: 22 pounds per person per year!", category: "Statistics", spicy: false },
    { fact: "The most expensive chocolate ever sold was worth $250 per piece — the 'Le Chocolate Box' with edible gold.", category: "Records", spicy: false },
    { fact: "Chocolate contains over 300 chemicals including anandamide, the 'bliss molecule' that creates feelings of euphoria.", category: "Science", spicy: true },
    { fact: "In the Victorian era, doctors prescribed chocolate for 'female complaints' and broken hearts. Chocolate therapy!", category: "History", spicy: false },
    { fact: "M&Ms were created for soldiers in WWII — chocolate that wouldn't melt in their hands or pockets.", category: "History", spicy: false },
    { fact: "The world's largest chocolate bar weighed 12,770 pounds. That's a lot of Valentine's Days!", category: "Records", spicy: false },
    { fact: "Cacao trees can live for 200 years but only produce quality beans for 25 years. Quality over quantity!", category: "Production", spicy: false },
    { fact: "In Japan, women give chocolate to men on Valentine's Day, and men return the favor on 'White Day' (March 14).", category: "Culture", spicy: false },
    { fact: "Body chocolate and edible body paint are billion-dollar industries. Chocolate isn't just for eating! 🔥", category: "Spicy", spicy: true },
    { fact: "Chocolate releases serotonin in the brain — the 'happy chemical.' That's why it's literally mood-boosting!", category: "Science", spicy: false },
    { fact: "The word 'chocolate' comes from the Aztec word 'xocolatl' meaning 'bitter water.' Ancient chocolate was unsweetened!", category: "Etymology", spicy: false },
    { fact: "Chocolate fountains at weddings symbolize flowing love and sweet beginnings. Plus, everyone loves chocolate-dipped strawberries!", category: "Romance", spicy: true },
    { fact: "Studies show that couples who share chocolate have more passionate relationships. Sharing is caring... and sexy!", category: "Spicy", spicy: true },
    { fact: "Napoleon carried chocolate on his military campaigns for quick energy. Conquering hearts... and countries!", category: "History", spicy: false },
  ];

  const chocolateScience = [
    { title: "Why Chocolate = Love", desc: "Chocolate contains tryptophan, which helps produce serotonin (happiness) and phenylethylamine (PEA), which creates the same feeling as falling in love. Your brain can't tell the difference between chocolate and romance!" },
    { title: "The Aphrodisiac Effect", desc: "Dark chocolate increases blood flow, releases endorphins, and contains compounds that mimic the feeling of attraction. Ancient cultures knew what modern science confirmed — chocolate makes you feel sexy! 🔥" },
    { title: "Chocolate & Mood", desc: "Eating chocolate triggers your brain to release dopamine and serotonin — the 'feel good' chemicals. That's why chocolate is the ultimate comfort food for heartbreak or celebration!" },
    { title: "The Perfect Gift", desc: "Gifting chocolate activates the same reward centers in the giver's brain as receiving it. It's literally win-win. Plus, it shows thoughtfulness and indulgence." },
    { title: "Body Chocolate Guide", desc: "Edible body chocolate melts at body temperature (98.6°F). Choose dark chocolate for slower melting. Pro tip: Heat it slightly first for smooth application. Always test temperature first! 🔥" },
    { title: "Pairing Perfection", desc: "Dark chocolate + red wine = romance. Milk chocolate + champagne = celebration. White chocolate + berries = seduction. The right pairing enhances both flavors and the mood!" },
    { title: "Chocolate Massage", desc: "Cocoa butter (the fat in chocolate) is incredibly moisturizing. Chocolate body oils and massage bars combine sensory pleasure with skin benefits. Spa-level romance at home! 💆" },
    { title: "Making It Together", desc: "Couples who make chocolate fondue or truffles together report increased bonding. The shared experience, the mess, the tasting — it's foreplay for the soul (and sometimes more 😉)." },
  ];

  const toggleChocolate = (name: string) => {
    if (selectedChocolates.includes(name)) {
      setSelectedChocolates(selectedChocolates.filter(c => c !== name));
    } else {
      setSelectedChocolates([...selectedChocolates, name]);
    }
  };

  return (
    <SectionInner>
      <GlowOrb color="orange" className="top-10 left-10" />
      <GlowOrb color="amber" className="bottom-20 right-20" />
      <div className="max-w-5xl mx-auto relative z-10">
        <SectionHeader 
          emoji="🍫" 
          title="Chocolate Day - Complete Guide" 
          subtitle="30 chocolates, 25 facts, romance science — sweet & spicy"
        />
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <p className="text-white/40 text-base max-w-3xl mx-auto leading-relaxed" style={{ fontFamily: "'Playfair Display', serif" }}>
            Chocolate is the edible language of love. Select your favorites and I'll remember every single one.
            <span className="block mt-3 text-amber-400/60">🍫 From sweet to spicy, every flavor tells our story 🍫</span>
          </p>
        </motion.div>

        {/* Tab Navigation */}
        <div className="flex justify-center gap-3 mb-8">
          {(['chocolates', 'facts', 'science'] as const).map((tab) => (
            <motion.button
              key={tab}
              onClick={() => setActiveTab(tab)}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className={`px-6 py-3 rounded-xl font-medium transition-all duration-300 ${
                activeTab === tab
                  ? "bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-[0_0_30px_rgba(251,146,60,0.3)]"
                  : "bg-white/[0.03] border border-white/[0.08] text-white/40 hover:text-white/60"
              }`}
            >
              {tab === 'chocolates' && '🍫 30 Chocolates'}
              {tab === 'facts' && '📚 25 Facts'}
              {tab === 'science' && '🔥 Romance Science'}
            </motion.button>
          ))}
        </div>

        {/* Chocolates Tab */}
        {activeTab === 'chocolates' && (
          <>
            <div className="text-center mb-6">
              <div className="inline-block px-6 py-3 rounded-full bg-amber-500/10 border border-amber-500/20">
                <p className="text-amber-400 font-medium">
                  Selected: {selectedChocolates.length} chocolates 🍫
                </p>
              </div>
            </div>

            <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-10">
              {chocolates.map((choc, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.03 * i }}
                  onClick={() => toggleChocolate(choc.name)}
                  className={`cursor-pointer rounded-2xl p-4 transition-all duration-300 ${
                    selectedChocolates.includes(choc.name)
                      ? "bg-gradient-to-br from-amber-500/20 to-orange-500/20 border-2 border-amber-500/50 shadow-[0_0_30px_rgba(245,158,11,0.3)]"
                      : "glass-card border border-white/[0.06] hover:border-amber-500/30"
                  }`}
                >
                  <div className="text-center">
                    <motion.div 
                      className="text-3xl mb-2"
                      animate={selectedChocolates.includes(choc.name) ? { scale: [1, 1.2, 1] } : {}}
                      transition={{ duration: 0.3 }}
                    >
                      {choc.icon}
                    </motion.div>
                    <h3 className="text-white font-semibold text-sm mb-1">{choc.name}</h3>
                    <p className="text-white/40 text-xs mb-1">{choc.taste}</p>
                    <div className="flex flex-col gap-1 mt-2">
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/5 text-white/30">
                        {choc.origin}
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400">
                        {choc.mood}
                      </span>
                    </div>
                    {selectedChocolates.includes(choc.name) && (
                      <motion.div 
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="mt-2 text-amber-400 text-xs font-medium"
                      >
                        ✓ In your box
                      </motion.div>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>

            {selectedChocolates.length > 0 && (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center"
              >
                <div className="inline-block px-8 py-4 rounded-2xl bg-gradient-to-r from-amber-500/10 to-orange-500/10 border border-amber-500/20">
                  <p className="text-amber-400/80 text-base italic mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
                    "Perfect! I'll remember that you love: {selectedChocolates.join(', ')}"
                  </p>
                  <p className="text-white/40 text-sm">
                    Now I know exactly what makes your heart (and taste buds) happy 💝
                  </p>
                </div>
              </motion.div>
            )}
          </>
        )}

        {/* Facts Tab */}
        {activeTab === 'facts' && (
          <div className="max-w-4xl mx-auto space-y-4">
            {chocolateFacts.map((fact, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.05 * i }}
                className="glass-card rounded-xl p-5 border border-white/[0.06] hover:border-amber-500/30 transition-all duration-300"
              >
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-amber-500/20 to-orange-500/20 flex items-center justify-center flex-shrink-0 border border-amber-500/20">
                    <span className="text-amber-400 text-sm font-bold">{i + 1}</span>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-xs px-2 py-1 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">
                        {fact.category}
                      </span>
                      {fact.spicy && (
                        <span className="text-xs px-2 py-1 rounded-full bg-red-500/10 text-red-400 border border-red-500/20">
                          🔥 Spicy
                        </span>
                      )}
                    </div>
                    <p className="text-white/70 leading-relaxed" style={{ fontFamily: "'Playfair Display', serif" }}>
                      {fact.fact}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* Science Tab */}
        {activeTab === 'science' && (
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-8">
              <p className="text-white/40 text-sm" style={{ fontFamily: "'Playfair Display', serif" }}>
                The science behind why chocolate is the ultimate aphrodisiac:
              </p>
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              {chocolateScience.map((item, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.05 * i }}
                  className="glass-card rounded-xl p-5 border border-white/[0.06] hover:border-amber-500/30 transition-all duration-300"
                >
                  <div className="flex items-start gap-3">
                    <div className="text-2xl">{item.title.includes('Body') || item.title.includes('Massage') || item.title.includes('Together') ? '🔥' : '💝'}</div>
                    <div className="flex-1">
                      <h4 className="text-amber-400 font-bold mb-2">{item.title}</h4>
                      <p className="text-white/60 text-sm leading-relaxed">{item.desc}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-12 text-center"
        >
          <div className="inline-block px-8 py-4 rounded-2xl bg-gradient-to-r from-amber-500/10 to-orange-500/10 border border-amber-500/20">
            <p className="text-amber-400/80 text-lg italic mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
              "Life is like a box of chocolates... and I want to share every flavor with you 🍫"
            </p>
            <p className="text-white/40 text-sm">
              30 chocolates × 25 facts × Romance science = Sweet love forever
            </p>
          </div>
        </motion.div>
      </div>


    </SectionInner>
  );
}

function TeddyDayContent() {  const [selectedTeddy, setSelectedTeddy] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState<'teddies' | 'facts' | 'science'>('teddies');

  const teddies = [
    { name: "Classic Teddy", desc: "The traditional brown bear that never goes out of style. Soft, cuddly, timeless — like our love.", icon: "🧸", size: "Medium (16\")", color: "Brown", material: "Plush", mood: "Traditional" },
    { name: "Giant Teddy", desc: "Almost as big as you! For those days when you need the biggest hug imaginable. Can't fit in a box, only in your arms.", icon: "🐻", size: "XXL (48\"+)", color: "Brown", material: "Ultra Soft", mood: "Overwhelming" },
    { name: "Tiny Pocket Bear", desc: "Small enough to carry everywhere. In your purse, in your pocket, always reminding you I'm thinking of you.", icon: "🧸", size: "Mini (4\")", color: "Beige", material: "Keychain", mood: "Portable" },
    { name: "White Polar Bear", desc: "Pure as snow, soft as clouds. This one represents the innocent, genuine love I have for you.", icon: "🐻‍❄️", size: "Large (24\")", color: "White", material: "Fluffy", mood: "Pure" },
    { name: "Pink Love Bear", desc: "Holding a heart that says 'I Love You.' Because sometimes the teddy should say what I'm always feeling.", icon: "💝", size: "Medium (18\")", color: "Pink", material: "Velvet", mood: "Romantic" },
    { name: "Couple Bears", desc: "Two bears holding hands — one for you, one for me. Never apart, always together, just like us.", icon: "🧸🧸", size: "Small (10\" each)", color: "Matching", material: "Pair Set", mood: "Together" },
    { name: "Sleeping Bear", desc: "With closed eyes and a peaceful smile. For those nights when I can't be there to help you fall asleep peacefully.", icon: "😴", size: "Medium (16\")", color: "Brown", material: "Soft", mood: "Peaceful" },
    { name: "Bear with Roses", desc: "Holding a bouquet of roses because this teddy knows what you deserve — flowers and love, always.", icon: "🌹", size: "Large (20\")", color: "Cream", material: "Premium", mood: "Elegant" },
    { name: "Purple Bear", desc: "Your favorite color! A special teddy in the exact shade you love most. Made just for you.", icon: "💜", size: "Medium (16\")", color: "Purple", material: "Velvet", mood: "Special" },
    { name: "Panda Bear", desc: "Black and white but completely colorful in personality. Rare, adorable, and impossible not to love — like you.", icon: "🐼", size: "Large (22\")", color: "Black & White", material: "Fluffy", mood: "Unique" },
    { name: "Weighted Teddy", desc: "Filled with calming weight, like a warm hug that helps with anxiety. Science-backed comfort when you need it most.", icon: "🧸", size: "Medium (15\")", color: "Gray", material: "Weighted", mood: "Calming" },
    { name: "Heated Bear", desc: "Microwave-safe bear that provides gentle warmth. Perfect for period cramps, cold nights, or when you need a warm hug.", icon: "🔥", size: "Small (12\")", color: "Brown", material: "Heating Gel", mood: "Soothing" },
    { name: "Cooling Bear", desc: "Keep in freezer for a cool cuddle buddy on hot summer nights or for headache relief. Refreshing comfort!", icon: "❄️", size: "Small (12\")", color: "Blue", material: "Cooling Gel", mood: "Refreshing" },
    { name: "Voice Recording Bear", desc: "Record a message, I love you, or even your heartbeat. When you squeeze it, you hear me even when I'm far away.", icon: "🎤", size: "Medium (18\")", color: "Brown", material: "Recording", mood: "Personal" },
    { name: "Musical Teddy", desc: "Plays a lullaby or our special song when you wind it up. Music box magic combined with cuddles.", icon: "🎵", size: "Small (10\")", color: "White", material: "Music Box", mood: "Melodic" },
    { name: "Scented Bear", desc: "Infused with lavender or vanilla scent for aromatherapy benefits. Calming smell + soft cuddles = perfect relaxation.", icon: "🌸", size: "Medium (14\")", color: "Purple", material: "Scented", mood: "Aromatic" },
    { name: "Light-Up Bear", desc: "Glows gently in the dark, perfect nightlight for peaceful sleep. No more scary darkness, just soft bear hugs and light.", icon: "✨", size: "Medium (16\")", color: "White", material: "LED Lights", mood: "Glowing" },
    { name: "Customized Photo Bear", desc: "Print our photo on the bear's chest. Literally hugging our memories every time you hold it.", icon: "📸", size: "Large (20\")", color: "White", material: "Photo Print", mood: "Memorial" },
    { name: "Vintage Teddy", desc: "Classic 1960s style teddy bear with jointed limbs and button eyes. Nostalgic, timeless, heirloom-quality love.", icon: "🧸", size: "Medium (18\")", color: "Tan", material: "Mohair", mood: "Nostalgic" },
    { name: "Memory Foam Bear", desc: "Filled with memory foam that molds to your body. Ergonomic comfort meets adorable cuddles.", icon: "🧸", size: "Large (24\")", color: "Gray", material: "Memory Foam", mood: "Adaptive" },
    { name: "Heartbeat Bear", desc: "Has a realistic heartbeat sound that mimics human pulse. Scientifically proven to reduce anxiety and help sleep.", icon: "💓", size: "Medium (16\")", color: "Brown", material: "Heartbeat", mood: "Lifelike" },
    { name: "Build-A-Bear Style", desc: "Customizable teddy where you choose everything — stuffing level, scent, sound, outfit. Built with love, just for you.", icon: "🎨", size: "Medium (16\")", color: "Custom", material: "Customizable", mood: "Personal" },
    { name: "Character Bear", desc: "Your favorite character as a teddy — Disney, anime, movie character. Fandom meets cuddles!", icon: "🎭", size: "Medium (14\")", color: "Various", material: "Licensed", mood: "Fandom" },
    { name: "Long-Distance Bear", desc: "Set of 2 bears that light up when the other is squeezed. When you hug yours, mine lights up. Technology connecting our cuddles.", icon: "💡", size: "Small (10\" each)", color: "Matching", material: "LED Tech", mood: "Connected" },
    { name: "Anniversary Bear", desc: "Commemorating our special date with embroidered details. The bear that remembers when we became forever.", icon: "💍", size: "Large (18\")", color: "Gold", material: "Embroidered", mood: "Celebratory" },
  ];

  const teddyFacts = [
    { fact: "Teddy bears are named after President Theodore 'Teddy' Roosevelt who refused to shoot a bear cub during a hunting trip in 1902. Romance born from compassion!", category: "History", spicy: false },
    { fact: "Psychologists confirm that adults who sleep with stuffed animals often have better sleep quality and lower anxiety levels. It's not childish — it's self-care!", category: "Psychology", spicy: false },
    { fact: "Hugging a teddy bear releases oxytocin (the 'love hormone') in your brain — the same chemical released when hugging a real person.", category: "Science", spicy: true },
    { fact: "70% of adults admit to keeping a childhood teddy bear. Some even sleep with them secretly. You're not alone!", category: "Statistics", spicy: false },
    { fact: "During WWII, teddy bears were given to soldiers for emotional comfort. The tradition continues today in hospitals and crisis situations.", category: "History", spicy: false },
    { fact: "The world's most expensive teddy bear sold for $2.1 million. It was made with gold, sapphires, and diamonds. But yours would be priceless to me!", category: "Records", spicy: false },
    { fact: "Studies show that cuddling a stuffed animal can reduce cortisol (stress hormone) by up to 68% — nearly as effective as cuddling a partner.", category: "Science", spicy: true },
    { fact: "In Japan, there are 'cuddle cafes' where adults pay to hug stuffed animals in a peaceful setting. Therapeutic teddy time!", category: "Culture", spicy: false },
    { fact: "Teddy bears are used in therapy for trauma, anxiety, and PTSD. They're called 'transitional objects' and provide genuine comfort.", category: "Psychology", spicy: false },
    { fact: "The average teddy bear is hugged 3,000+ times in its lifetime. Each hug leaves behind your scent, making it even more comforting over time.", category: "Trivia", spicy: false },
    { fact: "Some couples use 'surrogate cuddling' bears when apart. The scent of your partner on the bear can reduce longing and improve sleep quality.", category: "Spicy", spicy: true },
    { fact: "Weighted teddy bears (like weighted blankets) use 'deep pressure stimulation' which calms the nervous system. Science meets cuddles!", category: "Science", spicy: false },
    { fact: "In Victorian England, teddy bears were given as romantic gifts, symbolizing protection and comfort. The tradition of 'teddy bear love' is over 100 years old!", category: "History", spicy: false },
    { fact: "The tactile sensation of soft fur triggers the same brain regions as gentle human touch. Your brain literally thinks you're being held.", category: "Science", spicy: true },
    { fact: "Adults who cuddle teddy bears report 45% less loneliness during long-distance relationships. It's a proven coping mechanism!", category: "Statistics", spicy: true },
    { fact: "In some cultures, couples exchange 'love bears' instead of rings during engagements. The bear symbolizes lifelong comfort and companionship.", category: "Culture", spicy: false },
    { fact: "The 'teddy bear effect' is real: holding a soft object while discussing difficult emotions makes people 34% more likely to open up.", category: "Psychology", spicy: false },
    { fact: "Astronauts take teddy bears to space! The floating bear indicates zero gravity. Even in space, we need teddy bear comfort!", category: "Trivia", spicy: false },
    { fact: "Couples who gift personalized teddy bears report stronger emotional bonds. The thoughtfulness of customization deepens connection.", category: "Spicy", spicy: true },
    { fact: "Build-A-Bear has created over 200 million teddy bears since 1997. Each one built with love, hugged with joy, cherished forever.", category: "Statistics", spicy: false },
  ];

  const cuddleScience = [
    { title: "Why Teddy Bears Work", desc: "Soft textures activate oxytocin release in the brain — the same bonding hormone released during hugs with loved ones. Your brain literally can't tell the difference between teddy fur and human warmth in terms of chemical response!" },
    { title: "The Comfort Object Phenomenon", desc: "Psychologists call them 'transitional objects.' They represent safety, love, and comfort. For adults, they're not childish — they're emotional regulation tools. Having a teddy bear reduces anxiety by 68% in stressful situations." },
    { title: "Sleep Science & Teddies", desc: "Studies show adults who sleep with stuffed animals fall asleep 23% faster and wake less frequently. The weight and warmth simulate human presence, triggering relaxation responses. Better sleep = better life!" },
    { title: "Long-Distance Cuddle Substitutes", desc: "When physically apart, scent-infused teddy bears (with your partner's cologne/perfume) activate memory centers and reduce stress. Brain scans show similar patterns to actually being held by your loved one. Science proves teddy bears bridge the distance! 🔥" },
    { title: "Weighted Bears & Anxiety", desc: "Weighted stuffed animals (3-5 lbs) provide 'deep pressure stimulation' which increases serotonin and dopamine while decreasing cortisol. The effect is immediate and measurable — perfect for anxiety, panic attacks, or period discomfort." },
    { title: "The Heartbeat Effect", desc: "Teddy bears with heartbeat sounds reduce anxiety by 71% in clinical studies. The rhythmic beat mimics being held against someone's chest — your nervous system instinctively relaxes. It's biology!" },
    { title: "Scent & Memory Connection", desc: "The olfactory system (smell) is directly linked to emotional memory. A teddy bear that smells like your partner triggers the same neural pathways as their actual presence. Keep his shirt on the bear for maximum effect! 🔥" },
    { title: "Touch Therapy Benefits", desc: "The simple act of stroking soft fur releases endorphins and reduces blood pressure. 20 minutes of teddy cuddling = 1 hour of meditation in terms of stress reduction. Therapeutic cuddles backed by science!" },
  ];

  return (
    <SectionInner>
      <GlowOrb color="orange" className="top-20 left-10" />
      <GlowOrb color="pink" className="bottom-10 right-20" />
      <div className="max-w-5xl mx-auto relative z-10">
        <SectionHeader 
          emoji="🧸" 
          title="Teddy Day - Complete Guide" 
          subtitle="25 teddies, 20 facts, cuddle science — comfort in every form"
        />
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <p className="text-white/40 text-base max-w-3xl mx-auto leading-relaxed" style={{ fontFamily: "'Playfair Display', serif" }}>
            For those moments when I can't be there to hold you, let these teddies do it for me. Each one carries a piece of my love.
            <span className="block mt-3 text-pink-400/60">🧸 From classic to high-tech, every bear is a hug waiting for you 🧸</span>
          </p>
        </motion.div>

        {/* Tab Navigation */}
        <div className="flex justify-center gap-3 mb-8">
          {(['teddies', 'facts', 'science'] as const).map((tab) => (
            <motion.button
              key={tab}
              onClick={() => setActiveTab(tab)}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className={`px-6 py-3 rounded-xl font-medium transition-all duration-300 ${
                activeTab === tab
                  ? "bg-gradient-to-r from-orange-500 to-pink-500 text-white shadow-[0_0_30px_rgba(251,146,60,0.3)]"
                  : "bg-white/[0.03] border border-white/[0.08] text-white/40 hover:text-white/60"
              }`}
            >
              {tab === 'teddies' && '🧸 25 Teddies'}
              {tab === 'facts' && '📚 20 Facts'}
              {tab === 'science' && '🔬 Cuddle Science'}
            </motion.button>
          ))}
        </div>

        {/* Teddies Tab */}
        {activeTab === 'teddies' && (
          <div className="grid md:grid-cols-2 gap-5">
            {teddies.map((teddy, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.03 * i }}
                onClick={() => setSelectedTeddy(selectedTeddy === i ? null : i)}
                className={`glass-card rounded-2xl p-6 cursor-pointer transition-all duration-500 border ${
                  selectedTeddy === i
                    ? "border-pink-500/50 shadow-[0_0_40px_rgba(236,72,153,0.2)]"
                    : "border-white/[0.06] hover:border-pink-500/30"
                }`}
              >
                <div className="flex items-start gap-4">
                  <motion.div 
                    className="w-20 h-20 rounded-2xl bg-gradient-to-br from-pink-500/10 to-orange-500/10 flex items-center justify-center text-4xl border border-pink-500/20"
                    whileHover={{ scale: 1.1, rotate: 5 }}
                    animate={selectedTeddy === i ? { scale: [1, 1.05, 1] } : {}}
                    transition={{ repeat: selectedTeddy === i ? Infinity : 0, duration: 2 }}
                  >
                    {teddy.icon}
                  </motion.div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-white mb-1">{teddy.name}</h3>
                    <div className="flex flex-wrap gap-2 mb-2">
                      <span className="text-xs px-2 py-1 rounded-full bg-pink-500/10 text-pink-400 border border-pink-500/20">
                        {teddy.size}
                      </span>
                      <span className="text-xs px-2 py-1 rounded-full bg-orange-500/10 text-orange-400 border border-orange-500/20">
                        {teddy.color}
                      </span>
                      <span className="text-xs px-2 py-1 rounded-full bg-purple-500/10 text-purple-400 border border-purple-500/20">
                        {teddy.mood}
                      </span>
                    </div>
                    <p className="text-white/60 text-sm leading-relaxed" style={{ fontFamily: "'Playfair Display', serif" }}>
                      {teddy.desc}
                    </p>
                    {selectedTeddy === i && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        className="mt-3 pt-3 border-t border-white/[0.06]"
                      >
                        <p className="text-white/40 text-xs">
                          <strong>Material:</strong> {teddy.material}
                        </p>
                      </motion.div>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* Facts Tab */}
        {activeTab === 'facts' && (
          <div className="max-w-4xl mx-auto space-y-4">
            {teddyFacts.map((fact, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.05 * i }}
                className="glass-card rounded-xl p-5 border border-white/[0.06] hover:border-orange-500/30 transition-all duration-300"
              >
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-orange-500/20 to-pink-500/20 flex items-center justify-center flex-shrink-0 border border-orange-500/20">
                    <span className="text-orange-400 text-sm font-bold">{i + 1}</span>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-xs px-2 py-1 rounded-full bg-orange-500/10 text-orange-400 border border-orange-500/20">
                        {fact.category}
                      </span>
                      {fact.spicy && (
                        <span className="text-xs px-2 py-1 rounded-full bg-red-500/10 text-red-400 border border-red-500/20">
                          🔥 Spicy
                        </span>
                      )}
                    </div>
                    <p className="text-white/70 leading-relaxed" style={{ fontFamily: "'Playfair Display', serif" }}>
                      {fact.fact}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* Science Tab */}
        {activeTab === 'science' && (
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-8">
              <p className="text-white/40 text-sm" style={{ fontFamily: "'Playfair Display', serif" }}>
                The scientific proof that teddy bears are therapeutic comfort objects:
              </p>
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              {cuddleScience.map((item, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.05 * i }}
                  className="glass-card rounded-xl p-5 border border-white/[0.06] hover:border-orange-500/30 transition-all duration-300"
                >
                  <div className="flex items-start gap-3">
                    <div className="text-2xl">{item.title.includes('Long-Distance') || item.title.includes('Scent') ? '🔥' : '💝'}</div>
                    <div className="flex-1">
                      <h4 className="text-orange-400 font-bold mb-2">{item.title}</h4>
                      <p className="text-white/60 text-sm leading-relaxed">{item.desc}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-12 text-center"
        >
          <div className="inline-block px-8 py-4 rounded-2xl bg-gradient-to-r from-orange-500/10 to-pink-500/10 border border-orange-500/20">
            <p className="text-orange-400/80 text-lg italic mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
              "When I can't hold you, let these bears do it for me... 🧸💕"
            </p>
            <p className="text-white/40 text-sm">
              25 teddies × 20 facts × Cuddle science = Comfort when you need it most
            </p>
          </div>
        </motion.div>
      </div>


    </SectionInner>
  );
}

function PromiseDayContent() {  const promises = [
    "I promise to love you on your worst days, not just your best ones",
    "I promise to never let you go to bed feeling unloved",
    "I promise to choose you, every single day, even when it's hard",
    "I promise to be your safe space, your home, your peace",
    "I promise to support your dreams like they're my own",
    "I promise to hold your hand through every storm",
    "I promise to make you laugh when you feel like crying",
    "I promise to remember the little things you tell me",
    "I promise to celebrate your wins as if they're mine",
    "I promise to be patient with your growth and healing",
    "I promise to communicate, even when I'm hurt or scared",
    "I promise to protect your heart like it's the most precious thing in the world",
    "I promise to be loyal — in my thoughts, words, and actions",
    "I promise to put you before my pride",
    "I promise to show up, consistently, not just when it's convenient",
    "I promise to make you feel beautiful, every single day",
    "I promise to comfort you during your period and never complain",
    "I promise to learn your love language and speak it fluently",
    "I promise to defend you when you're not in the room",
    "I promise to build a future with you, not just dream about it",
    "I promise to take care of you when you're sick",
    "I promise to respect your boundaries and never cross them",
    "I promise to be your biggest cheerleader",
    "I promise to notice when something's wrong, even when you don't say it",
    "I promise to make our house a home filled with love and laughter",
    "I promise to share my deepest fears and vulnerabilities with you",
    "I promise to grow with you, not apart from you",
    "I promise to prioritize our relationship over work, friends, and everything else",
    "I promise to keep dating you even after we're married",
    "I promise to forgive you, even when you hurt me",
    "I promise to be faithful — emotionally, physically, and mentally",
    "I promise to support your family like they're my own",
    "I promise to make you feel desired, not just loved",
    "I promise to remember important dates and make them special",
    "I promise to be your partner in parenting, 50/50, always",
    "I promise to keep learning how to love you better",
    "I promise to apologize when I'm wrong and mean it",
    "I promise to create new traditions and memories with you",
    "I promise to be proud of you, publicly and privately",
    "I promise to make you feel safe enough to be yourself completely",
    "I promise to handle your insecurities with gentleness",
    "I promise to fight FOR us, not WITH you",
    "I promise to respect your need for alone time",
    "I promise to keep pursuing you, always",
    "I promise to be romantic, spontaneous, and thoughtful",
    "I promise to share responsibilities and never keep score",
    "I promise to believe in you when you don't believe in yourself",
    "I promise to age with you gracefully and love every version of you",
    "I promise to make you my priority, not an option",
    "I promise to love you until my last breath — and beyond",
  ];

  const [visibleCount, setVisibleCount] = useState(10);

  return (
    <SectionInner>
      <GlowOrb color="emerald" className="top-10 right-10" />
      <GlowOrb color="teal" className="bottom-20 left-10" />
      <div className="max-w-4xl mx-auto relative z-10">
        <SectionHeader 
          emoji="🤞" 
          title="Promise Day" 
          subtitle="50 promises carved into my soul — forever and always"
        />
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <p className="text-white/40 text-base max-w-3xl mx-auto leading-relaxed" style={{ fontFamily: "'Playfair Display', serif" }}>
            These aren't just words. These are vows I'm making to you, promises I'll keep every single day.
            <span className="block mt-3 text-emerald-400/60">Each one is written on my heart ✨</span>
          </p>
        </motion.div>

        <div className="space-y-3">
          {promises.slice(0, visibleCount).map((promise, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.03 * i }}
              className="glass-card rounded-xl p-4 border border-white/[0.06] hover:border-emerald-500/30 transition-all duration-300 hover:shadow-[0_0_20px_rgba(16,185,129,0.1)]"
            >
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-500/20 to-teal-500/20 flex items-center justify-center flex-shrink-0 border border-emerald-500/20">
                  <span className="text-emerald-400 text-xs font-bold">{i + 1}</span>
                </div>
                <p className="text-white/70 leading-relaxed flex-1" style={{ fontFamily: "'Playfair Display', serif" }}>
                  {promise}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        {visibleCount < promises.length && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center mt-8"
          >
            <button
              onClick={() => setVisibleCount(prev => Math.min(prev + 10, promises.length))}
              className="px-8 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-medium shadow-[0_0_30px_rgba(16,185,129,0.3)] hover:shadow-[0_0_40px_rgba(16,185,129,0.5)] transition-all"
            >
              Show More Promises ({promises.length - visibleCount} remaining)
            </button>
          </motion.div>
        )}

        {visibleCount >= promises.length && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-12 text-center"
          >
            <div className="inline-block px-8 py-4 rounded-2xl bg-gradient-to-r from-emerald-500/10 to-teal-500/10 border border-emerald-500/20">
              <p className="text-emerald-400/80 text-lg italic mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
                "All 50 promises — each one a piece of forever with you"
              </p>
              <p className="text-white/40 text-sm">
                I'll keep every single one 💚
              </p>
            </div>
          </motion.div>
        )}
      </div>


    </SectionInner>
  );
}

function HugDayContent() {  const [selectedHug, setSelectedHug] = useState<string | null>(null);
  
  const hugs = [
    { type: "Bear Hug", desc: "Tight, warm, and all-encompassing. The kind that squeezes out all your worries and fills you with love instead.", duration: "As long as you need", icon: "🐻" },
    { type: "Comfort Hug", desc: "Gentle and soothing. For when you're sad, scared, or just need to feel safe. My arms are your home.", duration: "Forever if needed", icon: "💙" },
    { type: "Back Hug", desc: "Arms around your waist from behind, chin on your shoulder. While you cook, while you exist, while you're just being you.", duration: "Spontaneous", icon: "🫂" },
    { type: "Morning Hug", desc: "Still half-asleep, pulling you close before the day starts. The first thought in my head: holding you.", duration: "5-10 minutes", icon: "☀️" },
    { type: "Goodnight Hug", desc: "The last thing before sleep. Arms around you, heartbeats syncing, peaceful and perfect.", duration: "Until we drift off", icon: "🌙" },
    { type: "Celebration Hug", desc: "Lifting you up, spinning you around, laughing together. For your wins, your achievements, your joy!", duration: "Until we're dizzy", icon: "🎉" },
    { type: "I'm Sorry Hug", desc: "When words aren't enough. Holding you close, hoping you feel how much I mean it.", duration: "Until you smile", icon: "🥺" },
    { type: "Just Because Hug", desc: "No reason needed. Just walking past you and pulling you in. Because I can, because you're there, because I love you.", duration: "Random", icon: "💕" },
    { type: "Long Distance Hug", desc: "Through the screen, through the distance, through time zones. My arms stretched across miles, reaching for you.", duration: "Until we're together", icon: "📱" },
    { type: "Slow Dance Hug", desc: "Swaying together, no music needed. Your head on my chest, my chin on your head, the world disappearing.", duration: "One song (or five)", icon: "💃" },
  ];

  return (
    <SectionInner>
      <GlowOrb color="cyan" className="top-20 right-20" />
      <GlowOrb color="blue" className="bottom-10 left-10" />
      <div className="max-w-5xl mx-auto relative z-10">
        <SectionHeader 
          emoji="🤗" 
          title="Hug Day" 
          subtitle="Choose the hug you need right now"
        />
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <p className="text-white/40 text-base max-w-3xl mx-auto leading-relaxed" style={{ fontFamily: "'Playfair Display', serif" }}>
            Even though I can't physically hold you right now, pick the hug you need. 
            Close your eyes and feel my arms around you.
            <span className="block mt-3 text-cyan-400/60">I'm holding you, always 🤗</span>
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-5">
          {hugs.map((hug, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.05 * i }}
              onClick={() => setSelectedHug(selectedHug === hug.type ? null : hug.type)}
              className={`cursor-pointer rounded-2xl p-6 transition-all duration-500 ${
                selectedHug === hug.type
                  ? "bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border-2 border-cyan-500/50 shadow-[0_0_40px_rgba(6,182,212,0.3)]"
                  : "glass-card border border-white/[0.06] hover:border-cyan-500/30"
              }`}
            >
              <div className="text-center mb-4">
                <motion.div 
                  className="text-5xl mb-3"
                  animate={selectedHug === hug.type ? { scale: [1, 1.2, 1] } : {}}
                  transition={{ repeat: selectedHug === hug.type ? Infinity : 0, duration: 1.5 }}
                >
                  {hug.icon}
                </motion.div>
                <h3 className="text-xl font-bold text-white mb-1">{hug.type}</h3>
                <span className="text-xs px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                  {hug.duration}
                </span>
              </div>
              <p className="text-white/60 text-sm leading-relaxed text-center" style={{ fontFamily: "'Playfair Display', serif" }}>
                {hug.desc}
              </p>
              {selectedHug === hug.type && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="mt-4 pt-4 border-t border-cyan-500/20 text-center"
                >
                  <p className="text-cyan-400 text-sm italic">
                    *Sending you this hug right now* 🫂
                  </p>
                </motion.div>
              )}
            </motion.div>
          ))}
        </div>

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="mt-12 text-center"
        >
          <div className="inline-block px-8 py-4 rounded-2xl bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/20">
            <p className="text-cyan-400/80 text-lg italic" style={{ fontFamily: "'Playfair Display', serif" }}>
              "My arms are always open for you, no matter the distance... 🤗💙"
            </p>
          </div>
        </motion.div>
      </div>


    </SectionInner>
  );
}

function KissDayContent() {  const [selectedKiss, setSelectedKiss] = useState<number | null>(null);
  
  const kisses = [
    { type: "Forehead Kiss", desc: "Gentle, protective, pure. The 'I'll always keep you safe' kiss. The one that says 'you're precious to me.'", mood: "Tender", when: "Anytime you need comfort", spice: "🤍" },
    { type: "Cheek Kiss", desc: "Sweet, playful, affectionate. The quick kiss while passing by. The 'just because you're cute' kiss.", mood: "Playful", when: "Random moments", spice: "💛" },
    { type: "Nose Kiss", desc: "Adorable and intimate. That close, that personal. The kind that makes you giggle and scrunch your nose.", mood: "Cute", when: "Making you smile", spice: "🧡" },
    { type: "Soft Lip Kiss", desc: "Gentle, slow, sweet. Not rushing, just savoring the moment. The kind that makes time stop.", mood: "Romantic", when: "Looking into your eyes", spice: "💗" },
    { type: "Passionate Kiss", desc: "Deep, intense, breathless. The kind that makes the world disappear. All my desire for you in one moment.", mood: "Passionate", when: "When I can't hold back", spice: "❤️‍🔥" },
    { type: "Goodnight Kiss", desc: "Lingering on your lips as we drift to sleep. The last taste of you before dreams. Peaceful and perfect.", mood: "Peaceful", when: "Before sleep", spice: "💙" },
    { type: "Good Morning Kiss", desc: "Still half-asleep, finding your lips first thing. Morning breath? Don't care. You're the first thought I want to taste.", mood: "Sleepy", when: "First thing waking up", spice: "🧡" },
    { type: "Surprise Kiss", desc: "Out of nowhere while you're talking, cooking, existing. Because I couldn't wait another second.", mood: "Spontaneous", when: "Whenever I want", spice: "💕" },
    { type: "Make-Up Kiss", desc: "After a fight, saying sorry with my lips. The 'I'm sorry, I love you, let's fix this' kiss. Healing and genuine.", mood: "Apologetic", when: "After arguments", spice: "💚" },
    { type: "Slow Kiss", desc: "Taking our time, exploring, no rush. Your bottom lip between mine, my tongue teasing yours. The kind that builds slowly.", mood: "Sensual", when: "Private moments", spice: "❤️‍🔥" },
    { type: "Neck Kiss", desc: "Trailing from your jawline down. The sensitive spot behind your ear. The kind that makes you shiver.", mood: "Seductive", when: "Leading to more", spice: "🔥" },
    { type: "Shoulder Kiss", desc: "Gentle kisses across your shoulders. Bare skin, soft touches. The 'every inch of you is beautiful' kiss.", mood: "Adoring", when: "Intimate moments", spice: "❤️" },
    { type: "Hand Kiss", desc: "Old-fashioned, romantic, respectful. Lifting your hand to my lips like you're royalty. Because you are.", mood: "Gentleman", when: "Romantic gestures", spice: "💛" },
    { type: "Earlobe Kiss", desc: "Soft nibbles, whispers between kisses. The kind that makes you weak. The kind you feel everywhere.", mood: "Teasing", when: "Being playful", spice: "🔥" },
    { type: "Against the Wall Kiss", desc: "Pressing you against the wall, hands on either side of your face. Intensity, desire, need. The 'I want you right now' kiss.", mood: "Intense", when: "Lost in the moment", spice: "🔥🔥" },
    { type: "Pull You Back Kiss", desc: "You start to pull away, I pull you back in. The 'not done with you yet' kiss. One more, then another, then another.", mood: "Hungry", when: "Can't get enough", spice: "❤️‍🔥" },
    { type: "Rain Kiss", desc: "Soaking wet, laughing in the rain, pulling you close for a kiss. Movie-perfect, spontaneous, unforgettable.", mood: "Cinematic", when: "Rainy adventures", spice: "💙" },
    { type: "First Kiss of the Day", desc: "Still in bed, tangled in sheets, morning light streaming in. Soft, sleepy, perfect. The one that sets the tone for everything.", mood: "Dreamy", when: "Lazy mornings", spice: "💛" },
    { type: "Can't Wait Kiss", desc: "The second you walk through the door. I missed you too much. No words, just lips. The reunion kiss.", mood: "Eager", when: "Missing you", spice: "❤️" },
    { type: "Forever Kiss", desc: "The one that promises everything. Slow, deep, meaningful. The 'I choose you, always' kiss. The kiss that seals our forever.", mood: "Eternal", when: "Making promises", spice: "💍" },
  ];

  return (
    <SectionInner>
      <GlowOrb color="red" className="top-10 left-10" />
      <GlowOrb color="pink" className="bottom-20 right-20" />
      <div className="max-w-5xl mx-auto relative z-10">
        <SectionHeader 
          emoji="💋" 
          title="Kiss Day" 
          subtitle="20 different kisses — from sweet to passionate, all for you"
        />
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <p className="text-white/40 text-base max-w-3xl mx-auto leading-relaxed" style={{ fontFamily: "'Playfair Display', serif" }}>
            Every kiss tells a different story. Each one I'm saving for you.
            <span className="block mt-3 text-red-400/60">From gentle to intense — all of them yours 💋</span>
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-4">
          {kisses.map((kiss, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.03 * i }}
              onClick={() => setSelectedKiss(selectedKiss === i ? null : i)}
              className={`cursor-pointer rounded-2xl p-5 transition-all duration-500 ${
                selectedKiss === i
                  ? "bg-gradient-to-br from-red-500/20 to-pink-500/20 border-2 border-red-500/50 shadow-[0_0_40px_rgba(239,68,68,0.3)]"
                  : "glass-card border border-white/[0.06] hover:border-red-500/30"
              }`}
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="text-lg font-bold text-white mb-1">{kiss.type}</h3>
                  <div className="flex gap-2">
                    <span className="text-xs px-2 py-1 rounded-full bg-red-500/10 text-red-400 border border-red-500/20">
                      {kiss.mood}
                    </span>
                    <span className="text-base">{kiss.spice}</span>
                  </div>
                </div>
              </div>
              <p className="text-white/60 text-sm leading-relaxed mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
                {kiss.desc}
              </p>
              <p className="text-white/40 text-xs italic">
                Best moment: {kiss.when}
              </p>
              {selectedKiss === i && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="mt-4 pt-4 border-t border-red-500/20 text-center"
                >
                  <p className="text-red-400 text-sm italic">
                    *This kiss is waiting for you* 💋
                  </p>
                </motion.div>
              )}
            </motion.div>
          ))}
        </div>

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="mt-12 text-center"
        >
          <div className="inline-block px-8 py-4 rounded-2xl bg-gradient-to-r from-red-500/10 to-pink-500/10 border border-red-500/20">
            <p className="text-red-400/80 text-lg italic mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
              "20 different ways to kiss you, and I want to try them all..."
            </p>
            <p className="text-white/40 text-sm">
              Every single one is saved for your lips only 💋
            </p>
          </div>
        </motion.div>
      </div>


    </SectionInner>
  );
}

// =============================================
// REELS SECTION - 51 REELS WITH REACTIONS
// =============================================
function ReelsContent() {
  const [reactions, setReactions] = useState<{[key: number]: string}>({});
  const [submittedReels, setSubmittedReels] = useState<Set<number>>(new Set());
  const [email, setEmail] = useState("your-email@example.com"); // You'll replace this

  // 47 Reels data with actual Dropbox links and your reactions
  const reels = [
    { id: 1, dropboxLink: "https://www.dropbox.com/scl/fi/t3yb5igfmlq5uv30m7tc1/Snapchat-6026543.mp4?raw=1", myReaction: "ye bilkul sahi hai mera heartbreal kabhi iss vejeh se to nahi hua par phir bhi ye sach hai matlab yaar aapko hi dekhlo me aapko paane ke liye kitna desperate hu aapke liye kitni skills sikh raha hu taki aap muje reject na karo ha me janta hu last to aaphi ka decision hoga par phir bhi aapke liye hi to me best banne ki kosis kar raha hu" },
    { id: 2, dropboxLink: "https://www.dropbox.com/scl/fi/64bxdxi39h8jzn8ymmm0a/Snapchat-205538426.mp4?raw=1", myReaction: "great words par see me esi reels dekne lag gaya tha" },
    { id: 3, dropboxLink: "https://www.dropbox.com/scl/fi/bv3cajhzgkotg2s5xw61p/Snapchat-244028997.mp4?raw=1", myReaction: "actually these all are marvel heros who losted everything but still smiles for the world I was thinking that my face is also like that which still smiles after losting this much and still no one loves me" },
    { id: 4, dropboxLink: "https://www.dropbox.com/scl/fi/p01l57hlqrbtkf349al0z/Snapchat-292829113.mp4?raw=1", myReaction: "I've said earlier mine is only true love ❤ cuz I need you just like oxygen to live" },
    { id: 5, dropboxLink: "https://www.dropbox.com/scl/fi/nhdkqieqlf0mwifce9qnl/Snapchat-313487340.mp4?raw=1", myReaction: "actually jo bol raha hai na vo hi real lucifer hai the official devil he is so perfect that everyone wants to live with him but he just wants that one girl same like me that I love only u and I want you to choose me isliye hi me har chiz me itna perfect banna chahta hu" },
    { id: 6, dropboxLink: "https://www.dropbox.com/scl/fi/egdn5rsuf19jvdbwpsptd/Snapchat-338412963.mp4?raw=1", myReaction: "it's so much true my life is the best example of this" },
    { id: 7, dropboxLink: "https://www.dropbox.com/scl/fi/uokv8vi43wy4v2qn2ov4q/Snapchat-351387296.mp4?raw=1", myReaction: "is gaane ko sunke I immediately cried 😢😭 thinking for you why no one understands I'm just tired of explaining myself" },
    { id: 8, dropboxLink: "https://www.dropbox.com/scl/fi/d4zkrc1sqvjd743at1i5p/Snapchat-575448938.mp4?raw=1", myReaction: "kabhi kabhi esa hota hai rona to nahi aata par heart cries so badly, aapke sath bhi hota hai kya?" },
    { id: 9, dropboxLink: "https://www.dropbox.com/scl/fi/b0bn5g3llyba3hs5mz8ta/Snapchat-589391456.mp4?raw=1", myReaction: "ye mere saath tab hota hai jab me aapse nahi mitla sach me I'm not even lying me na kabhi kabhi to rone lagta hu jab me aapse school ke baad bhi nahi mil pata" },
    { id: 10, dropboxLink: "https://www.dropbox.com/scl/fi/07pygmbmaak7bd73xzhkq/Snapchat-616235812.mp4?raw=1", myReaction: "i don't want to make you a memory I want you in my destiny cuz I want to laugh with u and want to make you laugh every single second" },
    { id: 11, dropboxLink: "https://www.dropbox.com/scl/fi/yfisz580iqfyuqamc6yut/Snapchat-626740657.mp4?raw=1", myReaction: "isme to me kuch comments hi nahi kar sakta ye to bas yu hi attach kar di mene" },
    { id: 12, dropboxLink: "https://www.dropbox.com/scl/fi/o5axoedtyk8h5z1sknos0/Snapchat-662413489.mp4?raw=1", myReaction: "not birthday but everyday irrespective of what it is cuz you are not with me" },
    { id: 13, dropboxLink: "https://www.dropbox.com/scl/fi/es3ubskl7cjnm8pewmbqo/Snapchat-728936242.mp4?raw=1", myReaction: "me bhi try karta hu bas is hi tereh" },
    { id: 14, dropboxLink: "https://www.dropbox.com/scl/fi/mdoi3fcus9qxvju2vkge2/Snapchat-777044593.mp4?raw=1", myReaction: "I'll be yours irrespective ke aap muje chaho ya na" },
    { id: 15, dropboxLink: "https://www.dropbox.com/scl/fi/2e2doppx9rrz3lqz6kaz3/Snapchat-789371422.mp4?raw=1", myReaction: "Just watch and tell me your reaction 💕" },
    { id: 16, dropboxLink: "https://www.dropbox.com/scl/fi/2v5fig82c9okw6fd2khqd/Snapchat-855237096.mp4?raw=1", myReaction: "I'll also wait for you till my last breath" },
    { id: 17, dropboxLink: "https://www.dropbox.com/scl/fi/djsccg9mw1nt8j4mz0yaw/Snapchat-863114436.mp4?raw=1", myReaction: "aap ho par ab baat hi nahi ho pati 🥺😢" },
    { id: 18, dropboxLink: "https://www.dropbox.com/scl/fi/t8oawqbxx61qammov45j3/Snapchat-903255072.mp4?raw=1", myReaction: "it's true for every second of my life" },
    { id: 19, dropboxLink: "https://www.dropbox.com/scl/fi/wife2po1dal89b2we06h4/Snapchat-911811570.mp4?raw=1", myReaction: "is it true cuz from my side it's true" },
    { id: 20, dropboxLink: "https://www.dropbox.com/scl/fi/vbutrbf19mf7sqjtm60ai/Snapchat-929812628.mp4?raw=1", myReaction: "kitne cute hai so loving kaash esa mere saath bhi ho" },
    { id: 21, dropboxLink: "https://www.dropbox.com/scl/fi/b8cs77sgu5v4cn975zmaa/Snapchat-933301281.mp4?raw=1", myReaction: "this is called true love" },
    { id: 22, dropboxLink: "https://www.dropbox.com/scl/fi/x7czrgegdvzbx3p5v2gq7/Snapchat-968676474.mp4?raw=1", myReaction: "feel the lines mine life is same as this" },
    { id: 23, dropboxLink: "https://www.dropbox.com/scl/fi/jsl35hg22ebykt5ntirjw/Snapchat-1047264670.mp4?raw=1", myReaction: "what your take on this cuz I think it's partially true" },
    { id: 24, dropboxLink: "https://www.dropbox.com/scl/fi/9e6s1kjaaaj8lj56d4jnn/Snapchat-1089242929.mp4?raw=1", myReaction: "kya likhu aap hi likh do" },
    { id: 25, dropboxLink: "https://www.dropbox.com/scl/fi/bdn0q3y8pm18sljs5x0ws/Snapchat-1144204024-1.mp4?raw=1", myReaction: "Awwwwwww kitni cute hai ye but not more than you" },
    { id: 26, dropboxLink: "https://www.dropbox.com/scl/fi/lzz0rckx7h4pi4i60jte1/Snapchat-1148885324.mp4?raw=1", myReaction: "this is how easy life can end" },
    { id: 27, dropboxLink: "https://www.dropbox.com/scl/fi/tjxim7s02e6byn4ot1c8w/Snapchat-1223843941.mp4?raw=1", myReaction: "see that's the reason me aapko hamesha kush karne me laga rehta hamesa finally aapse hi poochta hu aapko kabhi force nahi karta cuz muje yaar aapko khone se darr lagta hai" },
    { id: 28, dropboxLink: "https://www.dropbox.com/scl/fi/u75sataqp5qws4qt32jh4/Snapchat-1236929752.mp4?raw=1", myReaction: "this much I also loves you agar muje kuch magne ka moka milta to me bhi ye hi karta sach me" },
    { id: 29, dropboxLink: "https://www.dropbox.com/scl/fi/qzz483qwf2d1evnglkogx/Snapchat-1273929246.mp4?raw=1", myReaction: "actually me kya bolu isme yaar me na jitni bhi reels save kar rakhi thi na vo saari bhej di to agar accha nahi laga to yaar I'm extremely so sorry" },
    { id: 30, dropboxLink: "https://www.dropbox.com/scl/fi/tzmd8oozfbc43jiz361xk/Snapchat-1284827347.mp4?raw=1", myReaction: "What's your take on this? Tell me your thoughts 💭" },
    { id: 31, dropboxLink: "https://www.dropbox.com/scl/fi/ptfm9blhimk8ohne4dnh5/Snapchat-1300477717.mp4?raw=1", myReaction: "it's true not for all but for me it's true agar aap mana bhi kar dogi to bhi me aapko kabhi harm nahi pohcha sakta" },
    { id: 32, dropboxLink: "https://www.dropbox.com/scl/fi/527vm4k5j1hogx78vlb1v/Snapchat-1330262864.mp4?raw=1", myReaction: "there is only you closest to my heart and I always think of you" },
    { id: 33, dropboxLink: "https://www.dropbox.com/scl/fi/0a4wnc6ur1q4rma6e0als/Snapchat-1441392391.mp4?raw=1", myReaction: "Watch this and share your feelings 💕" },
    { id: 34, dropboxLink: "https://www.dropbox.com/scl/fi/3hmwi1rcc0vyatj0mo0n3/Snapchat-1491986165.mp4?raw=1", myReaction: "yaar ise dekh kar rona aa gaya" },
    { id: 35, dropboxLink: "https://www.dropbox.com/scl/fi/92e5jb9ul98sgln57k70n/Snapchat-1581181057.mp4?raw=1", myReaction: "I'll wait for you till my last breath" },
    { id: 36, dropboxLink: "https://www.dropbox.com/scl/fi/x7pru4joi0b5iadh4w2ob/Snapchat-1627560076.mp4?raw=1", myReaction: "it hurts cuz I don't want to end my life without you" },
    { id: 37, dropboxLink: "https://www.dropbox.com/scl/fi/qwk8l6zblekxtedevsw6k/Snapchat-1658172603.mp4?raw=1", myReaction: "it's true" },
    { id: 38, dropboxLink: "https://www.dropbox.com/scl/fi/223dsohb9scmu3uirldnu/Snapchat-1659315791.mp4?raw=1", myReaction: "there is only you my first and the very first priority" },
    { id: 39, dropboxLink: "https://www.dropbox.com/scl/fi/xmwy5i0jqh1dbjdeu5ih4/Snapchat-1703866984.mp4?raw=1", myReaction: "what you think about that on me" },
    { id: 40, dropboxLink: "https://www.dropbox.com/scl/fi/b462zmybcdad8h907vpse/Snapchat-1707472744.mp4?raw=1", myReaction: "yaar it's so much true i really care for you" },
    { id: 41, dropboxLink: "https://www.dropbox.com/scl/fi/4xvupp0pb5gs3kw8zop9q/Snapchat-1716390810.mp4?raw=1", myReaction: "bas efforts aur jyada bada dunga" },
    { id: 42, dropboxLink: "https://www.dropbox.com/scl/fi/9xw8g3q8ig1l2xbtppb7x/Snapchat-1773571509.mp4?raw=1", myReaction: "I can't live without you isliye me hi sorry mang leta hu" },
    { id: 43, dropboxLink: "https://www.dropbox.com/scl/fi/bw3it9ftf4ydwa369z0m9/Snapchat-1792162785.mp4?raw=1", myReaction: "your behaviour matters for me more than anything" },
    { id: 44, dropboxLink: "https://www.dropbox.com/scl/fi/mugwc48ynrn2ffx3g40mk/Snapchat-1923462198.mp4?raw=1", myReaction: "just 3 option for me and nothing more" },
    { id: 45, dropboxLink: "https://www.dropbox.com/scl/fi/endiqzgz3w1ri2y5jdimd/Snapchat-2083953435.mp4?raw=1", myReaction: "isme to me kya hi bolu aap hi janti ho" },
    { id: 46, dropboxLink: "https://www.dropbox.com/scl/fi/l3kk50jux4m6qyn8otlc3/Snapchat-1177602929.mp4?raw=1", myReaction: "actually I'll always wait for you no matter how busy you will become or you are cuz there's no one to whom I can talk in that way that I talk to you" },
    { id: 47, dropboxLink: "https://www.dropbox.com/scl/fi/apdfa9e28ko789wiadyfz/Snapchat-1203671652.mp4?raw=1", myReaction: "actually Peter Parker lost his girlfriend during fight that's why it hurts and it hurts because I can't get you as it cuz I don't want to lost you cuz there is no one like you" },
  ];

  const handleReactionChange = (reelId: number, reaction: string) => {
    setReactions(prev => ({...prev, [reelId]: reaction}));
  };

  const submitReaction = async (reelId: number) => {
    const reaction = reactions[reelId];
    if (!reaction || !reaction.trim()) {
      alert("Please write your reaction first! 💕");
      return;
    }

    // Send reaction to email (using a simple mailto for now - you can integrate with an email service)
    const reelData = reels.find(r => r.id === reelId);
    const emailSubject = `Reel #${reelId} Reaction from Your Love 💕`;
    const emailBody = `
Reel Number: ${reelId}
Your Reaction: ${reelData?.myReaction}
Her Reaction: ${reaction}

Dropbox Link: ${reelData?.dropboxLink}
    `.trim();

    // For now using mailto - you can replace with actual email API
    window.location.href = `mailto:${email}?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;
    
    setSubmittedReels(prev => new Set([...prev, reelId]));
    alert("Reaction sent! Check your email 💖");
  };

  return (
    <SectionInner>
      <GlowOrb color="purple" className="top-20 right-10" />
      <GlowOrb color="pink" className="bottom-20 left-10" />
      
      <div className="max-w-6xl mx-auto relative z-10">
        <SectionHeader 
          emoji="🎬" 
          title="Our Reels Together" 
          subtitle="47 moments I wanted to share with you"
        />

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <p className="text-white/60 text-lg max-w-3xl mx-auto leading-relaxed" style={{ fontFamily: "'Playfair Display', serif" }}>
            Every reel made me think of you. Watch them, see my reaction, then tell me yours.
            <span className="block mt-3 text-purple-400/80">Your reaction will come straight to my heart (and my email) 💕</span>
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {reels.map((reel, index) => (
            <motion.div
              key={reel.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="bg-white/[0.02] backdrop-blur-sm border border-white/[0.05] rounded-2xl p-6 hover:border-purple-500/30 transition-all duration-300"
            >
              {/* Reel Number */}
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold text-white">Reel #{reel.id}</h3>
                {submittedReels.has(reel.id) && (
                  <span className="text-green-400 text-sm">✓ Sent!</span>
                )}
              </div>

              {/* Video Player */}
              <div className="aspect-video bg-black rounded-xl mb-4 overflow-hidden border border-purple-500/20">
                {reel.dropboxLink.startsWith('DROPBOX_LINK') ? (
                  <div className="text-white/40 text-center p-4 flex items-center justify-center h-full">
                    <div>
                      <p className="text-sm mb-2">Replace with actual Dropbox link</p>
                      <p className="text-xs">Link placeholder: {reel.dropboxLink}</p>
                    </div>
                  </div>
                ) : (
                  <div className="relative w-full h-full">
                    <video 
                      controls 
                      className="w-full h-full object-contain"
                      preload="metadata"
                      controlsList="nodownload"
                      onError={(e) => {
                        // If video fails to load, show fallback
                        const videoElement = e.target as HTMLVideoElement;
                        const parent = videoElement.parentElement;
                        if (parent) {
                          parent.innerHTML = `
                            <div class="flex flex-col items-center justify-center h-full bg-gradient-to-br from-purple-900/20 to-pink-900/20 p-8">
                              <div class="w-20 h-20 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center mb-4">
                                <svg class="w-10 h-10 text-white" fill="currentColor" viewBox="0 0 24 24">
                                  <path d="M8 5v14l11-7z"/>
                                </svg>
                              </div>
                              <p class="text-white text-lg font-semibold mb-2">Reel #${reel.id}</p>
                              <p class="text-white/60 text-sm mb-4 text-center">Video couldn't load directly.<br/>Click below to watch:</p>
                              <a
                                href="${reel.dropboxLink}"
                                target="_blank"
                                rel="noopener noreferrer"
                                class="px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-full font-semibold hover:shadow-[0_0_30px_rgba(168,85,247,0.5)] transition-all inline-block"
                              >
                                Watch Video 🎬
                              </a>
                            </div>
                          `;
                        }
                      }}
                    >
                      <source src={reel.dropboxLink} type="video/mp4" />
                      Your browser doesn't support video playback.
                    </video>
                  </div>
                )}
              </div>

              {/* My Reaction */}
              <div className="mb-4 p-4 bg-purple-500/10 rounded-xl border border-purple-500/20">
                <p className="text-purple-400 text-sm font-semibold mb-1">My Reaction:</p>
                <p className="text-white/80 text-sm italic">{reel.myReaction}</p>
              </div>

              {/* Her Reaction Input */}
              <div className="mb-4">
                <label className="text-pink-400 text-sm font-semibold mb-2 block">
                  Your Reaction: 💕
                </label>
                <textarea
                  value={reactions[reel.id] || ''}
                  onChange={(e) => handleReactionChange(reel.id, e.target.value)}
                  placeholder="Tell me what you think... 💭"
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder-white/30 focus:outline-none focus:border-pink-500/50 transition-all resize-none"
                  rows={3}
                  disabled={submittedReels.has(reel.id)}
                />
              </div>

              {/* Submit Button */}
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => submitReaction(reel.id)}
                disabled={submittedReels.has(reel.id)}
                className={`w-full py-3 rounded-xl font-medium transition-all ${
                  submittedReels.has(reel.id)
                    ? 'bg-green-500/20 text-green-400 cursor-not-allowed'
                    : 'bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:shadow-[0_0_30px_rgba(168,85,247,0.3)]'
                }`}
              >
                {submittedReels.has(reel.id) ? '✓ Reaction Sent!' : 'Send My Reaction 💕'}
              </motion.button>
            </motion.div>
          ))}
        </div>

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="mt-12 text-center"
        >
          <div className="inline-block px-8 py-4 rounded-2xl bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/20">
            <p className="text-purple-400/80 text-lg italic mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
              "51 reels, 51 moments I wanted to share with you..."
            </p>
            <p className="text-white/40 text-sm">
              Every reaction you send makes my heart skip a beat 💖
            </p>
          </div>
        </motion.div>
      </div>
    </SectionInner>
  );
}

// =============================================
// CHAT SCREENSHOTS SECTION
// =============================================
function ChatScreenshotsContent() {
  const [reactions, setReactions] = useState<Record<number, string>>({});
  const [submitted, setSubmitted] = useState(false);

  const handleSubmitReactions = async () => {
    const emailSubject = "My Reactions to Our Chat Screenshots 💬";
    const emailBody = `
My Reactions to Chat Screenshots
==================================

${Object.entries(reactions).map(([id, reaction]) => {
  const screenshot = chatScreenshots.find(s => s.id === parseInt(id));
  return `Screenshot #${id}:
My Caption: "${screenshot?.caption}"
My Reaction: ${reaction || "No reaction given"}
`;
}).join("

")}

---
Sent from: Our Chat Memories section
    `.trim();

    const success = await sendToSlack(emailBody);
    if (success) {
      setSubmitted(true);
    } else {
      alert("Failed to send. Check your webhook URL.");
    }
  };

  // 31 Real chat screenshots with personal reactions
  const chatScreenshots = [
    { id: 1, imageUrl: "https://www.dropbox.com/scl/fi/imacebma2yp06rfkf2n40/Screenshot_2026-02-20-18-40-23-203_com.snapchat.android.jpg?rlkey=qfivh4fokcbhofe35dgugnd5g&st=efv69q87&raw=1", caption: "iss message ko me lagbhag 100 se bhi jyada baar padh chuka hu sach me yaar ise padh ke to rona hi aa jata hai matlab yaar aapka kitna accha behavior that us time par I loved that behavior so much and missing it too and also esa nahi hai ki ab aapka behavior accha nahi hai par yaar ap apan mil hi nahi pate that's why but phir bhi thank so so so much for this message I'm also grateful for this that God gave me another God in my life" },
    { id: 2, imageUrl: "https://www.dropbox.com/scl/fi/ri2vlwgrwt1clvirzgxza/Screenshot_2026-02-20-18-40-39-540_com.snapchat.android.jpg?rlkey=sx0h9ml86i8sl6avp9owbsbh9&st=og2msdw4&raw=1", caption: "aapko lagwana hai - Ye to aapne tab bola tha jab bhai dhoj aayi thi to mene aapse tika lagwane ke bare me majak kiya tha and they you sended me a cute kitten reel (vo last wala message in this photo) phir aapne poocha tha ki ye cute lag rahi hai na then I said yes it is but not more than you" },
    { id: 3, imageUrl: "https://www.dropbox.com/scl/fi/2hnkr7o70xf34eh27k8in/Screenshot_2026-02-20-18-44-55-116_com.snapchat.android.jpg?rlkey=i2u8zxp029e7o92lwnpjq0miw&st=ue6zjmio&raw=1", caption: "phir aapne chemistry in love ki definition di thi but genuinely you are so great sach me vo defination bohot sahi thi but I also want to react with you and want to create most stable compound in this omniverse" },
    { id: 4, imageUrl: "https://www.dropbox.com/scl/fi/v3tmmxivthpux8x5ttfwf/Screenshot_2026-02-20-18-45-55-000_com.snapchat.android.jpg?rlkey=d1qnzxy4tbe78w5yat8hwztti&st=1mgop9zn&raw=1", caption: "and ye to some messages taht I keep doing you par yaar kewal itne se hi sved bache hai ab to" },
    { id: 5, imageUrl: "https://www.dropbox.com/scl/fi/73mdedoqcu646iw9lqee7/Screenshot_2026-02-20-18-46-29-729_com.snapchat.android.jpg?rlkey=rdyig06d25i0dk8siawmhke2s&st=83px4awf&raw=1", caption: "these are also missing your reaction animation that you gave me in thta message" },
    { id: 6, imageUrl: "https://www.dropbox.com/scl/fi/x4o0r1zf574344thmbfqa/Screenshot_2026-02-20-18-47-33-866_com.snapchat.android.jpg?rlkey=47h8hd6ymja1pziiz0of1jfbc&st=djyws95x&raw=1", caption: "the lyrics of night changes that I've sent you and these lines are still true that even though the night changes I won't change us and my love towards you" },
    { id: 7, imageUrl: "https://www.dropbox.com/scl/fi/7lfcyvqzsq6etn2l99lo7/Screenshot_2026-02-20-18-48-03-273_com.snapchat.android.jpg?rlkey=rwlatwav8rnnqrgktxwi6v3aa&st=rup1rct7&raw=1", caption: "just bigger coverage of that emoji like substance" },
    { id: 8, imageUrl: "https://www.dropbox.com/scl/fi/17c9lei1m1mhdyq3ubvsm/Screenshot_2026-02-20-18-48-21-460_com.snapchat.android.jpg?rlkey=udiedfhmq404hxag43n3reazi&st=to1vku3w&raw=1", caption: "pehle to muje aap best is universe me hi lagti thi par ab to aap poore omniverse me ho (above matrix) and also missing that 'same to you all to you back to you full stop' 😢😢" },
    { id: 9, imageUrl: "https://www.dropbox.com/scl/fi/ahcnzuv47tmahy2b5jz1v/Screenshot_2026-02-20-18-48-54-705_com.snapchat.android.jpg?rlkey=7idy8vdwx5z60dvo9bwea7zjz&st=bij5suo5&raw=1", caption: "yaar mera to aaj bhi good morning and goodnight messages karne ka mann karta hai par yaar aap ho hi nahi 😢😭 par koi baat nahi ab kar raha hu aap jab bhi dekh rahi ho good (the time happening like morning afternoon evening or night) and also enjoy your(breakfast brunch lunch dinner supper or midnight snack)" },
    { id: 10, imageUrl: "https://www.dropbox.com/scl/fi/6b60c0a1l8mt7kzkge4kj/Screenshot_2026-02-20-18-49-19-416_com.snapchat.android.jpg?rlkey=2q7iz95q1cneixn42dqpvaznz&st=6y1nobkk&raw=1", caption: "missing that fantasies that I sended you 😭😥🥺and those lines that I've only sended you in my life 😢" },
    { id: 11, imageUrl: "https://www.dropbox.com/scl/fi/oz1ip8kpj87mhwe2qyvga/Screenshot_2026-02-20-18-49-40-515_com.snapchat.android.jpg?rlkey=9pszgzpog3re4ni1x0sbu3q1v&st=syoqi24w&raw=1", caption: "those big messages that I've only written for you" },
    { id: 12, imageUrl: "https://www.dropbox.com/scl/fi/yelj0zc4rrfx0lcjxziih/Screenshot_2026-02-20-18-50-27-358_com.snapchat.android.jpg?rlkey=hckzf6x6e2qpkpiouwbk82lcq&st=rldrfzyy&raw=1", caption: "mann to abhi bhi likhne ka karta hai par kese to aapko batau mera hall" },
    { id: 13, imageUrl: "https://www.dropbox.com/scl/fi/v2zkoz5lbg5qplhdv7d9c/Screenshot_2026-02-20-18-50-40-613_com.snapchat.android.jpg?rlkey=wxywhe3flhyxdnl5dioaco726&st=qumewhku&raw=1", caption: "that blood mark vese ab to mene kai saare bana liye" },
    { id: 14, imageUrl: "https://www.dropbox.com/scl/fi/yj902w3qnacn9z5461jtp/Screenshot_2026-02-20-18-51-36-909_com.snapchat.android.jpg?rlkey=dkdgd8qyed2ue2i2xbvboc3n6&st=83a8qucs&raw=1", caption: "aapne jab muje block kar diya tha to pata nahi kese par me aapki chat abhi bhi khol sakta tha to me har din message likhta tha ye soch ke, ke ek na ek din to aap wapas aayogi par aap to aayi hi nahi ab tak matlab mujse baat karne ( not blaming you for ask this I'm just saying)" },
    { id: 15, imageUrl: "https://www.dropbox.com/scl/fi/hi17m06s87vzgcu04n3zl/Screenshot_2026-02-20-18-51-56-957_com.snapchat.android.jpg?rlkey=linluxcfztvlro9h3zwl83now&st=oqwsalhp&raw=1", caption: "ye bhi vahi bas ab me kai saare messages likhne lag gaya" },
    { id: 16, imageUrl: "https://www.dropbox.com/scl/fi/73je884p8pi04ocvhb5bn/Screenshot_2026-02-20-18-52-37-452_com.snapchat.android.jpg?rlkey=dwwillkcvjkiolydb1mefd6rj&st=63o4h1z2&raw=1", caption: "ye jab kai dino baad mene aapse pooch tha ki aap mujse naraj to nahi ho to aapne nahi kaha tha to bas yahi likha hai thank you so much" },
    { id: 17, imageUrl: "https://www.dropbox.com/scl/fi/ezf27hxncvm7muhwsde32/Screenshot_2026-02-20-18-53-36-230_com.snapchat.android.jpg?rlkey=miv7tg41lyonw9ut4bp78okfc&st=14r8gqct&raw=1", caption: "some more messages and ye to sach hai ki me aapko chahna kabhi nahi chodunga bas aap sahi samay par samjho" },
    { id: 18, imageUrl: "https://www.dropbox.com/scl/fi/4wvzmh3wa67ykeed8ceb9/Screenshot_2026-02-20-18-54-31-817_com.snapchat.android.jpg?rlkey=uf6vp3efnjbp6eyzf15omrfbq&st=4h96icoa&raw=1", caption: "ye to me bhagwan se pray kar raha tha aapse phir se milne ke liye kher vo to me har din hi karta hu and those lines are from a song that i listened during those times also still I listen to these songs" },
    { id: 19, imageUrl: "https://www.dropbox.com/scl/fi/6dsfx190pgi7che0vf56r/Screenshot_2026-02-20-18-55-35-936_com.snapchat.android.jpg?rlkey=qwb16b23dwspnjd7y8ow9zbxt&st=ie6s0k9w&raw=1", caption: "actually the link is this: https://www.psychologytoday.com/us/blog/bozo-sapiens/200904/what-are-the-odds-on-love - This is the article that proves that true love is so so so rare to me to aapko samjha raha tha bas. And vo behavior wali baat to muje kabhi kabhi lagta hai bas aap gussa mat ho na me to thoda emotional ho gaya tha us waqt" },
    { id: 20, imageUrl: "https://www.dropbox.com/scl/fi/gpm2j5bt04qlzvx7h3pi7/Screenshot_2026-02-20-18-55-52-323_com.snapchat.android.jpg?rlkey=vyepl5kcrx117677ezjlkyxmd&st=8qnl4sfe&raw=1", caption: "isme me jis surprize ki baat kar raha hu ye yahi website hai and ye jo niche Ke messages hai ye to mene aapka crachter assume karke khud hi khud se baat karta tha P. matlab aapka reply and rest is mine dekho me aapse baat karne ke liye kitna desperate rehta tha" },
    { id: 21, imageUrl: "https://www.dropbox.com/scl/fi/3ezzncqkkmbcln8auk604/Screenshot_2026-02-20-18-57-51-364_com.snapchat.android.jpg?rlkey=0k0coq3ne5x8c8t9lj3pl53ap&st=axz5mugw&raw=1", caption: "ye bhi wahi hai bas inme mene P nahi likha" },
    { id: 22, imageUrl: "https://www.dropbox.com/scl/fi/wrpvuwd8wgp1kxfl5qgji/Screenshot_2026-02-20-18-58-16-498_com.snapchat.android.jpg?rlkey=1j7fklz6lv8dft51ato8yg2wb&st=e6c3j7l0&raw=1", caption: "ye to iss website ke baare me baat kar raha hu" },
    { id: 23, imageUrl: "https://www.dropbox.com/scl/fi/i1oszm2h4of05za5paj3q/Screenshot_2026-02-20-18-58-52-049_com.snapchat.android.jpg?rlkey=4f5izuv0cbkp1cqolwrlj4ncu&st=flf5uvpc&raw=1", caption: "aap hi dedo" },
    { id: 24, imageUrl: "https://www.dropbox.com/scl/fi/kx36eosfid376glf2gfig/Screenshot_2026-02-20-19-00-21-209_com.snapchat.android.jpg?rlkey=g585aetmn4plvn18j4saanhsi&st=urjigec9&raw=1", caption: "no reaction it's you who would responds" },
    { id: 25, imageUrl: "https://www.dropbox.com/scl/fi/zbppkdks0ebf41uh51pzg/Screenshot_2026-02-20-19-01-10-929_com.snapchat.android.jpg?rlkey=hdli960svorqai7hscptuhrne&st=ihatr67v&raw=1", caption: "yaar sach me marne ka to mann karta hai cuz yaar sach me jisse chahta tha vo hi ab hai nahi mujse baat karne ke liye to jine ka kya fayda" },
    { id: 26, imageUrl: "https://www.dropbox.com/scl/fi/eyv3t4xbigblp0xjmm6ax/Screenshot_2026-02-20-19-02-35-043_com.snapchat.android.jpg?rlkey=u4froighfonv3fuimev5gczdc&st=dssk1eze&raw=1", caption: "your reaction" },
    { id: 27, imageUrl: "https://www.dropbox.com/scl/fi/8tdj5rq7syfi66zlnvbb6/Screenshot_2026-02-20-19-03-01-700_com.snapchat.android.jpg?rlkey=0ekyp6usyqqrv4xxkx6iyrryh&st=y94s6k5n&raw=1", caption: "😭😭😭😭" },
    { id: 28, imageUrl: "https://www.dropbox.com/scl/fi/ptiork49cnsmgjcf16u4v/Screenshot_2026-02-20-19-03-12-273_com.snapchat.android.jpg?rlkey=3d3j9pnyva9mus6aep10qcza3&st=y9i0o9g5&raw=1", caption: "you tell me what you think about this" },
    { id: 29, imageUrl: "https://www.dropbox.com/scl/fi/plte6l8ygd5edpzw8iaay/Screenshot_2026-02-20-19-04-03-852_com.snapchat.android.jpg?rlkey=957d966uzao9e2jthr0iaoxm7&st=g9u2pe4p&raw=1", caption: "your reaction" },
    { id: 30, imageUrl: "https://www.dropbox.com/scl/fi/zniy0c0gjirnew7mwshr6/Screenshot_2026-02-20-19-04-14-090_com.snapchat.android.jpg?rlkey=wx82lmuaozqaxs9xqv4241jzh&st=o19r7c45&raw=1", caption: "your reaction" },
    { id: 31, imageUrl: "https://www.dropbox.com/scl/fi/1umr1ga4o2pb92d6mcgqs/Screenshot_2026-02-20-19-04-29-624_com.snapchat.android.jpg?rlkey=43wxe5ew3epyr28viml4sqjo5&st=m3qhpwyk&raw=1", caption: "it's true you're still the most important for me not even my own parents are above more important than you and also I really really truly love you❤" },
  ];

  return (
    <SectionInner>
      <GlowOrb color="blue" className="top-20 right-10" />
      <GlowOrb color="purple" className="bottom-20 left-10" />
      
      <div className="max-w-5xl mx-auto relative z-10">
        <SectionHeader 
          emoji="💬" 
          title="Our Chat Memories" 
          subtitle="31 screenshots that hold pieces of us"
        />

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <p className="text-white/60 text-lg max-w-3xl mx-auto leading-relaxed" style={{ fontFamily: "'Playfair Display', serif" }}>
            Every conversation, every emoji, every late-night text.
            <span className="block mt-3 text-blue-400/80">These screenshots are proof of what we're building together 💕</span>
          </p>
        </motion.div>

        <div className="space-y-8">
          {chatScreenshots.map((screenshot, index) => (
            <motion.div
              key={screenshot.id}
              initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`flex ${index % 2 === 0 ? 'justify-start' : 'justify-end'}`}
            >
              <div className={`max-w-2xl ${index % 2 === 0 ? 'mr-auto' : 'ml-auto'}`}>
                {/* Screenshot Card */}
                <div className="bg-white/[0.02] backdrop-blur-sm border border-white/[0.05] rounded-2xl p-4 hover:border-blue-500/30 transition-all duration-300">
                  {/* Image */}
                  <div className="rounded-xl overflow-hidden bg-black/30 mb-3">
                    {screenshot.imageUrl.startsWith('SCREENSHOT_URL') ? (
                      <div className="aspect-[9/16] flex items-center justify-center text-white/40 text-center p-8">
                        <div>
                          <p className="text-sm mb-2">Replace with actual screenshot</p>
                          <p className="text-xs">Placeholder: {screenshot.imageUrl}</p>
                        </div>
                      </div>
                    ) : (
                      <img 
                        src={screenshot.imageUrl} 
                        alt={`Chat screenshot ${screenshot.id}`}
                        className="w-full h-auto"
                      />
                    )}
                  </div>

                  {/* Caption */}
                  <p className="text-white/80 text-sm italic px-2" style={{ fontFamily: "'Playfair Display', serif" }}>
                    {screenshot.caption}
                  </p>
                  {/* Timestamp */}
                  <p className="text-white/30 text-xs px-2 mt-1">
                    Screenshot #{screenshot.id}
                  </p>

                  {/* Her Reaction Box */}
                  <div className="mt-4 pt-4 border-t border-white/10">
                    <label className="block text-white/60 text-sm mb-2">
                      Your Reaction:
                    </label>
                    <textarea
                      value={reactions[screenshot.id] || ""}
                      onChange={(e) => setReactions({...reactions, [screenshot.id]: e.target.value})}
                      placeholder="What do you think about this screenshot...?"
                      className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-white placeholder-white/30 focus:outline-none focus:border-blue-500/50 transition-colors resize-none text-sm"
                      rows={2}
                    />
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="mt-12 text-center"
        >
          <div className="inline-block px-8 py-4 rounded-2xl bg-gradient-to-r from-blue-500/10 to-purple-500/10 border border-blue-500/20">
            <p className="text-blue-400/80 text-lg italic mb-2" style={{ fontFamily: "'Playfair Display', serif" }}>
              "Every screenshot is a memory frozen in time..."
            </p>
            <p className="text-white/40 text-sm">
              Our conversation, our connection, our story 💬
            </p>
          </div>
        </motion.div>
      </div>
    </SectionInner>
  );
}

// =============================================
// FINAL MESSAGE SECTION
// =============================================
function FinalMessageContent() {
  const [response, setResponse] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async () => {
    if (!response.trim()) {
      alert("Please write something if you'd like to respond 💕");
      return;
    }

    const emailSubject = "My Response After Seeing Everything 💝";
    const emailBody = `
My Response:

${response}

---
Sent from: My Message To You section
    `.trim();

    const success = await sendToSlack(emailBody);
    if (success) {
      setSubmitted(true);
    } else {
      alert("Failed to send. Check your webhook URL.");
    }
  };

  return (
    <SectionInner>
      <GlowOrb color="rose" className="top-20 right-10" />
      <GlowOrb color="purple" className="bottom-20 left-10" />
      
      <div className="max-w-4xl mx-auto relative z-10">
        <SectionHeader 
          emoji="💝" 
          title="My Message To You" 
          subtitle="Before you leave this universe I built..."
        />

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-8 text-white/70 leading-relaxed"
          style={{ fontFamily: "'Playfair Display', serif" }}
        >
          
          {/* Opening */}
          <div className="glass-card rounded-2xl p-8">
            <h3 className="text-2xl font-bold text-white mb-4">Hey,</h3>
            <p className="mb-4">
              So you made it here. To this final section. Honestly, main nahi janta tha ki aap actually poori website explore karogi, but if you're reading this right now, it means you went through everything.
            </p>
            <p className="mb-4">
              Har section. Har word. Har comparison. Har question. Har reel. Har screenshot. Sab kuch.
            </p>
            <p>
              Aur pehle to main bas ye kehna chahta hu - <strong className="text-pink-400">thank you</strong>. Thank you for giving this a chance. Thank you for your time.
            </p>
          </div>

          {/* The Real Story */}
          <div className="glass-card rounded-2xl p-8">
            <h3 className="text-2xl font-bold text-white mb-4">The REAL Story Behind This Website...</h3>
            <p className="mb-4">
              Main aapko sach batana chahta hu - <strong className="text-white">ye website kaise bana.</strong> Not the romantic version. The REAL version. Kyunki main chahta hu aap samjho ki ye casually nahi bana.
            </p>
            <p className="text-pink-400 font-semibold">
              Ye struggle tha. Pure struggle.
            </p>
          </div>

          {/* The Struggle */}
          <div className="glass-card rounded-2xl p-8">
            <h3 className="text-xl font-bold text-white mb-4">The Beginning: "I Have No Idea What I'm Doing..."</h3>
            <p className="mb-4">
              Maine socha tha - "ek website banaunga aapke liye." Simple. Basic.
            </p>
            <p className="mb-4">
              Par problem ye thi - <strong className="text-white">main coding properly nahi janta tha.</strong>
            </p>
            <div className="bg-white/5 rounded-xl p-4 my-4">
              <p className="mb-2">• YouTube par <strong>hours</strong> barbaad kiye - 30-40 videos dekhi</p>
              <p className="mb-2">• ChatGPT se <strong className="text-pink-400">800-1000+ messages</strong> exchange kiye</p>
              <p>• Same cheez <strong>10 baar poochi</strong> kyunki pehli 9 baar solution kaam nahi kiya</p>
            </div>
          </div>

          {/* Manual Labor */}
          <div className="glass-card rounded-2xl p-8">
            <h3 className="text-xl font-bold text-white mb-4">The Manual Labor: "This Is Taking Forever..."</h3>
            
            <div className="mb-6">
              <h4 className="text-lg font-semibold text-pink-400 mb-3">47 Reels - The Process:</h4>
              <ul className="space-y-2 list-disc list-inside">
                <li>Har reel ka Dropbox link copy kiya - <strong>47 baar</strong></li>
                <li>Har link ko test kiya, convert kiya (dl=0 to raw=1)</li>
                <li><strong className="text-white">Har reel ke liye apna genuine reaction likha</strong> - "ye bilkul sahi hai...", "is gaane ko sunke I immediately cried..."</li>
                <li>Sab ko code me organize kiya - <strong>15-20 baar code break hua</strong></li>
              </ul>
              <p className="text-purple-400 mt-3 font-semibold">Total time: 12-15 hours</p>
            </div>

            <div>
              <h4 className="text-lg font-semibold text-pink-400 mb-3">31 Screenshots - Same Hell:</h4>
              <ul className="space-y-2 list-disc list-inside">
                <li>Har screenshot upload ki, link copy kiya - <strong>31 baar</strong></li>
                <li>Har screenshot test kiya - kuch compress karni padi</li>
                <li><strong className="text-white">Har screenshot ke liye reaction likha</strong> - "iss message ko me 100+ baar padh chuka hu...", "aapne jab block kar diya tha..."</li>
              </ul>
              <p className="text-purple-400 mt-3 font-semibold">Total time: 10-12 hours</p>
            </div>
          </div>

          {/* The Numbers */}
          <div className="glass-card rounded-2xl p-8 border-2 border-pink-500/30">
            <h3 className="text-2xl font-bold text-white mb-4">The Real Numbers (Honest Truth):</h3>
            
            <div className="grid md:grid-cols-2 gap-4 mb-6">
              <div className="bg-gradient-to-br from-pink-500/10 to-purple-500/10 rounded-xl p-4">
                <div className="text-3xl font-bold text-pink-400 mb-1">30,000+</div>
                <div className="text-white/60 text-sm">Lines of Code</div>
              </div>
              <div className="bg-gradient-to-br from-purple-500/10 to-blue-500/10 rounded-xl p-4">
                <div className="text-3xl font-bold text-purple-400 mb-1">180-200+</div>
                <div className="text-white/60 text-sm">Hours of Work</div>
              </div>
              <div className="bg-gradient-to-br from-blue-500/10 to-cyan-500/10 rounded-xl p-4">
                <div className="text-3xl font-bold text-blue-400 mb-1">1000+</div>
                <div className="text-white/60 text-sm">ChatGPT Messages</div>
              </div>
              <div className="bg-gradient-to-br from-cyan-500/10 to-teal-500/10 rounded-xl p-4">
                <div className="text-3xl font-bold text-cyan-400 mb-1">78</div>
                <div className="text-white/60 text-sm">Manual Reactions Written</div>
              </div>
            </div>

            <p className="text-lg text-center text-white font-semibold">
              = Almost <span className="text-pink-400">8-9 FULL days</span> of continuous work spread across <span className="text-purple-400">5-6 weeks</span>
            </p>
          </div>

          {/* Why I'm Telling You This */}
          <div className="glass-card rounded-2xl p-8">
            <h3 className="text-2xl font-bold text-white mb-4">Why Am I Telling You All This?</h3>
            <p className="mb-4">
              Main aapko ye sab detail me isliye bata raha hu kyunki <strong className="text-white">I want you to understand something very clearly:</strong>
            </p>
            <p className="mb-4 text-lg">
              <strong className="text-pink-400">This wasn't casual.</strong>
            </p>
            <p className="mb-4">
              Agar ye casual hota, to maine 2-3 hours laga ke basic template liya hota.
            </p>
            <p className="mb-4">
              Agar ye time-pass hota, to maine itne errors face karte hue quit kar diya hota.
            </p>
            <p className="text-lg font-semibold text-white">
              <strong className="text-purple-400">Maine ye isliye banaya kyunki main chahta tha ki aap FEEL karo.</strong>
            </p>
          </div>

          {/* NOT FORCING - Most Important */}
          <div className="glass-card rounded-2xl p-8 border-2 border-purple-500/50 bg-purple-500/5">
            <h3 className="text-2xl font-bold text-white mb-4">⚠️ VERY IMPORTANT: I'm Not Forcing You</h3>
            <p className="mb-4 text-xl font-bold text-pink-400">
              MAIN AAPKO FORCE NAHI KAR RAHA HU KI AAP MUJE CHOOSE KARO.
            </p>
            <p className="mb-4">
              Read that again. <strong className="text-white">Not forcing you.</strong>
            </p>
            <div className="bg-white/5 rounded-xl p-6 my-4 space-y-3">
              <p>❌ Maine ye isliye NAHI banaya ki aap guilt feel karo</p>
              <p>❌ Maine ye isliye NAHI banaya ki aap pressure me aa jao</p>
              <p>❌ Maine ye isliye NAHI banaya ki ye koi deal ho</p>
              <p className="text-pink-400 font-semibold mt-4">✅ Maine ye isliye banaya - <strong className="text-white">taaki aap FEEL kar sako</strong></p>
            </div>
            <p className="text-lg">
              I don't want you to feel obligated. I don't want you to feel pressured. I don't want you to feel guilty.
            </p>
            <p className="text-lg mt-4 text-purple-400 font-semibold">
              Main bas chahta tha ki aap clearly feel kar sako - what I say is not empty words.
            </p>
          </div>

          {/* What I Want From You */}
          <div className="glass-card rounded-2xl p-8">
            <h3 className="text-2xl font-bold text-white mb-4">What I Actually Want From You:</h3>
            <div className="space-y-4">
              <div className="flex gap-3">
                <span className="text-2xl">1️⃣</span>
                <div>
                  <p className="font-semibold text-white">Just... feel it.</p>
                  <p>You don't have to say yes. Just feel the love behind it.</p>
                </div>
              </div>
              <div className="flex gap-3">
                <span className="text-2xl">2️⃣</span>
                <div>
                  <p className="font-semibold text-white">Be honest with yourself.</p>
                  <p>Answer questions for yourself, not for me.</p>
                </div>
              </div>
              <div className="flex gap-3">
                <span className="text-2xl">3️⃣</span>
                <div>
                  <p className="font-semibold text-white">Take all the time you need.</p>
                  <p>No deadline. No urgency. Your choice, your time.</p>
                </div>
              </div>
              <div className="flex gap-3">
                <span className="text-2xl">4️⃣</span>
                <div>
                  <p className="font-semibold text-white">Whatever you decide - it's okay.</p>
                  <p>Yes or no - I'll respect it.</p>
                </div>
              </div>
            </div>
          </div>

          {/* What I Promise */}
          <div className="glass-card rounded-2xl p-8">
            <h3 className="text-2xl font-bold text-white mb-4">What I Promise (If You Give Me A Chance):</h3>
            <div className="space-y-2">
              <p>✨ Main aapko kabhi jhoot nahi bolunga</p>
              <p>✨ Main aapko kabhi cheat nahi karunga</p>
              <p>✨ Main aapko priority dunga (genuinely)</p>
              <p>✨ Main aapko respect karunga always</p>
              <p>✨ Main improve karta rahunga as a person</p>
              <p>✨ Main aapko khush rakhne ki koshish karunga har din</p>
              <p className="text-pink-400 font-semibold text-lg mt-4">✨ Main aapko kabhi regret nahi hone dunga</p>
            </div>
            <p className="mt-4 text-white/60 italic">
              (Ye sirf IF aap choose karti ho. I'm not demanding this.)
            </p>
          </div>

          {/* What If You Don't */}
          <div className="glass-card rounded-2xl p-8">
            <h3 className="text-2xl font-bold text-white mb-4">What I'll Do (If You Don't Choose Me):</h3>
            <p className="mb-4">Aur agar aap decide karti ho ki no, this isn't for you:</p>
            <div className="space-y-2 mb-4">
              <p>• Main aapko force nahi karunga</p>
              <p>• Main guilt trip nahi dunga</p>
              <p>• <strong className="text-pink-400">Main respectfully accept karunga par move on nahi karunga</strong></p>
              <p>• Main khud ko improve karta rahunga - aapke liye best banne ki koshish karunga</p>
              <p>• Main hamesha aapko (from distance) khush dekhna chahunga</p>
              <p>• Agar kabhi zarurat pade, main hamesha available rahunga</p>
            </div>
            <p className="text-white/80">
              Will it hurt? <strong className="text-white">Yes. Like hell.</strong><br/>
              Will I be sad? <strong className="text-white">Yes. Very.</strong><br/>
              Will I regret this website? <strong className="text-pink-400">No. Never.</strong>
            </p>
            <p className="mt-4 text-purple-400 font-semibold">
              Par main aapko disturb nahi karunga. Promise. Main bas apne aap ko better banata rahunga.
            </p>
          </div>

          {/* Final Words */}
          <div className="glass-card rounded-2xl p-8 border-2 border-pink-500/50 bg-gradient-to-br from-pink-500/10 to-purple-500/10">
            <h3 className="text-2xl font-bold text-white mb-4">My Absolute Final Words...</h3>
            <p className="mb-4 text-lg">
              Main aapse ek question poochna chahta hu:
            </p>
            <p className="text-xl font-semibold text-white mb-4">
              <strong className="text-pink-400">Have you ever felt this?</strong>
            </p>
            <div className="space-y-2 mb-4">
              <p>Ke koi aapke liye 180-200+ hours spend kare?</p>
              <p>Ke koi aapke liye 1000+ AI messages likhe?</p>
              <p>Ke koi aapke liye 78 reactions manually type kare?</p>
              <p>Ke koi aapke liye raat raat bhar jagke code kare?</p>
              <p className="text-lg text-pink-400 font-semibold">Ke koi aapke liye ek poori universe build kare?</p>
            </div>
            <p className="text-lg mb-4">
              Main nahi keh raha ki aapko muje choose karna chahiye because of this.
            </p>
            <p className="text-xl font-semibold text-purple-400">
              Main sirf keh raha hu - this is real love. This is what it looks like when someone genuinely, deeply, infinitely loves you.
            </p>
          </div>

          {/* But Your Choice */}
          <div className="glass-card rounded-2xl p-8 bg-purple-500/10">
            <h3 className="text-2xl font-bold text-white mb-4 text-center">But Again - Your Choice</h3>
            <p className="text-center text-lg mb-4">
              I'm not forcing you. I'm not guilting you. I'm not demanding anything.
            </p>
            <p className="text-center text-xl font-semibold text-pink-400 mb-4">
              Main bas aapko dikha raha hu - this is my heart. This is what I feel.
            </p>
            <p className="text-center text-lg">
              I built you 17 worlds. All revolving around you.
            </p>
            <p className="text-center text-purple-400 font-semibold mt-2">
              Not to trap you. Not to pressure you.
            </p>
            <p className="text-center text-white text-xl mt-4">
              Just to show you - <strong>THIS is what it feels like to be loved by me.</strong>
            </p>
          </div>

          {/* Response Section */}
          <div className="glass-card rounded-2xl p-8 border-2 border-pink-500/50">
            <h3 className="text-2xl font-bold text-white mb-4 text-center">💝 Your Response (Completely Optional)</h3>
            <p className="text-center mb-6 text-white/70">
              If you want to share your thoughts, feelings, questions, or decision - you can write here. No pressure. Skip if you're not ready.
            </p>
            
            <textarea
              value={response}
              onChange={(e) => setResponse(e.target.value)}
              placeholder="You can write anything here - how you feel, questions you have, your decision, or nothing at all. It's completely your choice..."
              className="w-full h-48 px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-white/30 focus:outline-none focus:border-pink-500/50 transition-colors resize-none"
              style={{ fontFamily: "'Playfair Display', serif" }}
            />

            <button
              onClick={handleSubmit}
              disabled={submitted}
              className={`w-full mt-4 px-6 py-4 rounded-xl font-semibold text-lg transition-all ${
                submitted
                  ? "bg-green-500/20 text-green-400 cursor-not-allowed"
                  : "bg-gradient-to-r from-pink-500 to-purple-500 text-white hover:shadow-[0_0_30px_rgba(236,72,153,0.5)]"
              }`}
            >
              {submitted ? "✓ Sent! Thank you for your honesty 💕" : "Send My Response (Optional)"}
            </button>

            <p className="text-center text-white/40 text-sm mt-4">
              This will open your email app with your response. You can edit before sending.
            </p>
          </div>

          {/* Closing */}
          <div className="text-center py-8">
            <p className="text-xl mb-2">I'll be waiting.</p>
            <p className="text-white/60 mb-6">
              Not desperately. Not obsessively. Just... waiting.
            </p>
            <p className="text-lg text-pink-400 mb-2">
              Whatever happens - thank you for reading this. Thank you for seeing my heart.
            </p>
            <p className="text-white/70 mt-8 italic">
              Aapka (if you want to be) / Your friend (if that's all you want) / Someone who loves you (regardless of what you choose),
            </p>
            <p className="text-2xl font-bold text-white mt-2">[Your Name]</p>
          </div>

          {/* Stats Footer */}
          <div className="glass-card rounded-2xl p-6 bg-gradient-to-br from-purple-500/5 to-pink-500/5">
            <p className="text-center text-white/50 text-sm mb-4">This website represents:</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-center text-sm">
              <div>
                <div className="text-pink-400 font-bold">180-200+ hours</div>
                <div className="text-white/40">of work</div>
              </div>
              <div>
                <div className="text-purple-400 font-bold">30,000+ lines</div>
                <div className="text-white/40">of code</div>
              </div>
              <div>
                <div className="text-blue-400 font-bold">78 reactions</div>
                <div className="text-white/40">written by hand</div>
              </div>
              <div>
                <div className="text-cyan-400 font-bold">Infinite love</div>
                <div className="text-white/40">zero expectations</div>
              </div>
            </div>
            <p className="text-center text-white/60 text-xs mt-4 italic">
              NOT forcing. NOT demanding. JUST showing. JUST expressing. JUST hoping you feel it. 💕
            </p>
          </div>

        </motion.div>
      </div>
    </SectionInner>
  );
}

// =============================================
// SECTION RENDERER MAP
// =============================================
const sectionContentMap: Record<string, () => React.ReactNode> = {
  story: () => <StoryContent />,
  playlist: () => <PlaylistContent />,
  roseday: () => <RoseDayContent />,
  proposeday: () => <ProposeDayContent />,
  chocolateday: () => <ChocolateDayContent />,
  teddyday: () => <TeddyDayContent />,
  promiseday: () => <PromiseDayContent />,
  hugday: () => <HugDayContent />,
  kissday: () => <KissDayContent />,
  dreamboy: () => <DreamBoyContent />,
  knowyou: () => <KnowYouContent />,
  compliments: () => <ComplimentsContent />,
  lovefacts: () => <LoveFactsContent />,
  quotes: () => <QuotesContent />,
  forever: () => <ForeverContent />,
  reels: () => <ReelsContent />,
  chats: () => <ChatScreenshotsContent />,
  finalmessage: () => <FinalMessageContent />,
};

// =============================================
// MAIN SITE EXPORT
// =============================================
export default function MainSite() {
  const [activeSection, setActiveSection] = useState<string | null>(null);
  const activeTile = sectionTiles.find((t) => t.id === activeSection);

  return (
    <div className="bg-[#030306] min-h-screen relative">
      <AnimatePresence mode="wait">
        {activeSection === null ? (
          <motion.div key="home" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.3 }}>
            <TileHomepage onOpenSection={(id) => setActiveSection(id)} />
          </motion.div>
        ) : (
          <motion.div key={activeSection} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.3 }}>
            <SectionView
              id={activeSection}
              onBack={() => setActiveSection(null)}
              gradient={activeTile?.gradient || "from-pink-500 to-purple-500"}
              emoji={activeTile?.emoji || "💖"}
              title={activeTile?.title || ""}
            >
              {sectionContentMap[activeSection]?.()}
            </SectionView>
          </motion.div>
        )}
      </AnimatePresence>

      <FloatingNav
        onOpenSection={(id) => setActiveSection(id)}
        currentSection={activeSection}
        onBack={() => setActiveSection(null)}
      />
    </div>
  );
}
