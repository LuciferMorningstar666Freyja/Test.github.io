#!/bin/bash
echo "========================================"
echo "  Love Website - Starting Server"
echo "========================================"
echo ""
echo "Installing dependencies..."
npm install
echo ""
echo "Starting development server..."
echo ""
echo "The website will open at: http://localhost:5173"
echo "Press Ctrl+C to stop the server"
echo ""
npm run dev
